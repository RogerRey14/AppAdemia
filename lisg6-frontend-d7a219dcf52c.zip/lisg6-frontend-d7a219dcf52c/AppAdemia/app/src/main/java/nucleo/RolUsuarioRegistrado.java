package nucleo;

import java.io.File;

public class RolUsuarioRegistrado extends RolUsuario
{

    public void cerrarSesion()
    {

    }

    public void eliminarCuenta()
    {

    }

    public void unirseGrupo(String ID, String contrasena)
    {

    }

    public void salirGrupo(Grupo grupo)
    {

    }

    public void silenciarGrupo(Grupo grupo)
    {

    }

    public void desilenciarGrupo(Grupo grupo)
    {

    }

    public void crearNota(Evento evento, String titulo, String texto, Boolean esPublica, File[] ficheros)
    {

    }

    public void descargarNotificaciones()
    {

    }

    public void crearActividadExtra()
    {

    }
}
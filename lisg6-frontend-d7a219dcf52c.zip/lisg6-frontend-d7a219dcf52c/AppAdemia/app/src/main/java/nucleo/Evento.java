package nucleo;

import java.sql.Date;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


public class Evento
{

    private String ID;
    private String nombreEvento;
    private String descripcion;
    private String lugar;
    private Date fechaInicio;
    private Date fechaFin;
    private Time horaInicio;
    private Time horaFin;
    private Boolean esRecordatorio;

    private ArrayList<Nota> notas;
    private ArrayList<Grupo> grupos;

    public Evento()
    {
        notas = new ArrayList<Nota>();
        grupos = new ArrayList<Grupo>();
    }


    public void enviarNotificacion()
    {

    }

    public void addNota(Nota nota)
    {
        notas.add(nota);
    }

    public void addGrupo(Grupo grupo)
    {
        grupos.add(grupo);
    }

    public String getNombreEvento() {
        return nombreEvento;
    }

    public void setNombreEvento(String nombreEvento) {
        this.nombreEvento = nombreEvento;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public void setFechaInicio(String fechaInicio, String formato) throws ParseException {
        this.fechaInicio = new Date(new SimpleDateFormat(formato).parse(fechaInicio).getTime());
    }

    public Date getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Date fechaFin) {
        this.fechaFin = fechaFin;
    }

    public void setFechaFin(String fechaFin, String formato) throws ParseException {
        this.fechaFin = new Date(new SimpleDateFormat(formato).parse(fechaFin).getTime());
    }

    public Time getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(Time horaInicio) {
        this.horaInicio = horaInicio;
    }

    public void setHoraInicio(String horaInicio) throws ParseException {
        //this.horaInicio = new Time(new SimpleDateFormat(formato).parse(horaInicio).getTime());
        this.horaInicio = Time.valueOf(horaInicio);
    }

    public Time getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(Time horaFin) {
        this.horaFin = horaFin;
    }

    public void setHoraFin(String horaFin) throws ParseException {
        //this.horaFin = new Time(new SimpleDateFormat(formato).parse(horaFin).getTime());
        this.horaFin = Time.valueOf(horaFin);
    }

    public Boolean getEsRecordatorio() {
        return esRecordatorio;
    }

    public void setEsRecordatorio(Boolean esRecordatorio) {
        this.esRecordatorio = esRecordatorio;
    }

    public ArrayList<Nota> getNotas() {
        return notas;
    }

    public void setNotas(ArrayList<Nota> notas) {
        this.notas = notas;
    }

    public ArrayList<Grupo> getGrupos() {
        return grupos;
    }

    public void setGrupos(ArrayList<Grupo> grupos) {
        this.grupos = grupos;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
package nucleo;

public class VistaDia implements Vista
{
    public Calendario mostrar()
    {
		return null;
    }
}
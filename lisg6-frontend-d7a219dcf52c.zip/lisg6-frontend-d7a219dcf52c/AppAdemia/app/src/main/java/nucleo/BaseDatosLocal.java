package nucleo;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import androidx.annotation.Nullable;

import org.slf4j.helpers.Util;

import java.io.UTFDataFormatException;
import java.sql.Array;
import java.sql.Date;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.concurrent.ExecutionException;


public class BaseDatosLocal {
    private ConexionSQLiteHelper c;
    private Context context;
    private Date fechaUltimaModificacion;
    private String formatoFecha = Utilidades.FORMATO_FECHA;;
    private String formatoHora = Utilidades.FORMATO_HORA;
    private Usuario miUsuario;
    private DateFormat formatterFechaActualizacion = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION);


    public Usuario getMiUsuario()
    {
        return miUsuario;
    }

    public void setMiUsuario(Usuario miUsuario)
    {
        this.miUsuario = miUsuario;
    }


    public BaseDatosLocal(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        this.c = new ConexionSQLiteHelper(context, name, factory, version);
        this.context = context;
    }

    /*
    public BaseDatosLocal(ConexionSQLiteHelper c) {
        this.c = c;
    }
     */

    public void resetTablas() {
        resetNivelOrganizativo();
        resetActividad();
        resetCategoria();
        resetGrupo();
        resetRolUsuario();
        resetUsuario();
        resetNivelOrganizativoUsuario();
        resetActividadUsuario();
        resetUsuarioGrupo();
        resetNotificacion();
        resetCalendario();
        resetEvento();
        //resetCalendarioEvento();
        resetEventoGrupo();
        resetNota();
        resetFichero();
        resetFechaUltimaActualizacion();
        //resetUsuarioNotificacion();
    }

    private void resetUsuarioNotificacion()
    {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_USUARIONOTIFICACION + ";");
        db.execSQL(Utilidades.CREAR_TABLA_USUARIONOTIFICACION);
        db.close();
    }

    private void resetFichero() {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_FICHERO + ";");
        db.execSQL(Utilidades.CREAR_TABLA_FICHERO);
        db.close();
    }

    private void resetNota() {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_NOTA + ";");
        db.execSQL(Utilidades.CREAR_TABLA_NOTA);
        db.close();
    }

    private void resetCalendarioEvento() {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_CALENDARIOEVENTO + ";");
        db.execSQL(Utilidades.CREAR_TABLA_CALENDARIOEVENTO);
        db.close();
    }

    private void resetCalendario() {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_CALENDARIO + ";");
        db.execSQL(Utilidades.CREAR_TABLA_CALENDARIO);
        db.close();
    }

    private void resetNotificacion() {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_NOTIFICACION + ";");
        db.execSQL(Utilidades.CREAR_TABLA_NOTIFICACION);
        db.close();
    }

    private void resetUsuarioGrupo() {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_USUARIOGRUPO + ";");
        db.execSQL(Utilidades.CREAR_TABLA_USUARIOGRUPO);
        db.close();
    }

    private void resetActividadUsuario() {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_ACTIVIDADUSUARIO + ";");
        db.execSQL(Utilidades.CREAR_TABLA_ACTIVIDADUSUARIO);
        db.close();
    }

    private void resetNivelOrganizativoUsuario() {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_NIVELORGANIZATIVOUSUARIO + ";");
        db.execSQL(Utilidades.CREAR_TABLA_NIVELORGANIZATIVOUSUARIO);
        db.close();
    }

    private void resetUsuario() {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_USUARIO + ";");
        db.execSQL(Utilidades.CREAR_TABLA_USUARIO);
        db.close();
    }

    private void resetRolUsuario() {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_ROLUSUARIO + ";");
        db.execSQL(Utilidades.CREAR_TABLA_ROLUSUARIO);
        db.close();
    }

    public void resetNivelOrganizativo() {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_NIVELORGANIZATIVO + ";");
        db.execSQL(Utilidades.CREAR_TABLA_NIVELORGANIZATIVO);
        db.close();
    }

    public void resetActividad() {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_ACTIVIDAD + ";");
        db.execSQL(Utilidades.CREAR_TABLA_ACTIVIDAD);
        db.close();
    }

    public void resetCategoria() {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_CATEGORIA + ";");
        db.execSQL(Utilidades.CREAR_TABLA_CATEGORIA);
        db.close();
    }

    public void resetGrupo() {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_GRUPO + ";");
        db.execSQL(Utilidades.CREAR_TABLA_GRUPO);
        db.close();
    }

    public void resetEvento() {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_EVENTO + ";");
        db.execSQL(Utilidades.CREAR_TABLA_EVENTO);
        db.close();
    }

    public void resetEventoGrupo() {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_EVENTOGRUPO + ";");
        db.execSQL(Utilidades.CREAR_TABLA_EVENTOGRUPO);
        db.close();
    }

    public void resetFechaUltimaActualizacion() {
        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_FECHAULTIMAACTUALIZACION + ";");
        db.execSQL(Utilidades.CREAR_TABLA_FECHAULTIMAACTUALIZACION);
        db.close();
    }

    public void setNotificacionUsuario(int usuario, int notificacion, boolean leida)
    {
        int leidaInt = leida ? 1 : 0;
        String insert = "INSERT OR REPLACE INTO " + Utilidades.TABLA_USUARIONOTIFICACION + " ("
                + Utilidades.CAMPO_USUARIONOTIFICACION_USUARIO+", "+ Utilidades.CAMPO_USUARIONOTIFICACION_NOTIFICACION
                +", "+Utilidades.CAMPO_USUARIONOTIFICACION_LEIDA+ ") VALUES (" + usuario + ", "
                + notificacion + ", " + leidaInt + ");";

        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL(insert);
        db.close();
    }

    public boolean notificacionLeidaAnteriormente(int usuario, int notificacion)
    {
        String select = "SELECT "+Utilidades.CAMPO_USUARIONOTIFICACION_LEIDA+"  FROM "
                +Utilidades.TABLA_USUARIONOTIFICACION+" WHERE "+Utilidades.CAMPO_USUARIONOTIFICACION_USUARIO
                + " = ? AND "+Utilidades.CAMPO_USUARIONOTIFICACION_NOTIFICACION + " = ?;";

        SQLiteDatabase db = c.getReadableDatabase();
        String[] parametros = {Integer.toString(usuario), Integer.toString(notificacion)};
        Cursor cursor = db.rawQuery(select, parametros);

        if(cursor!=null && cursor.getCount()>0)
        {
            cursor.moveToFirst();
            return cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_USUARIONOTIFICACION_LEIDA)).equals("1");
        }
        else
        {
            return false;
        }

    }

    public void setDatosReales() throws ParseException, ExecutionException, InterruptedException {
        Conector conector = new Conector(this, Utilidades.URL);
        conector.getRequestNivelesOrganizativos();
        conector.get();

        conector = new Conector(this, Utilidades.URL);
        conector.getRequestActividades();
        conector.get();

        conector = new Conector(this, Utilidades.URL);
        conector.getRequestCategorias();
        conector.get();

        conector = new Conector(this, Utilidades.URL);
        conector.getRequestGrupos();
        conector.get();

        conector = new Conector(this, Utilidades.URL);
        conector.getRequestEventos();
        conector.get();
    }

    public void setNivelOrganizativo(int ID, String nombre, String descripcion, String tipo, int esOficial, int nivelPadre, String fechaUltimaMod) {
        String insert = "INSERT OR REPLACE INTO " + Utilidades.TABLA_NIVELORGANIZATIVO + " (" + Utilidades.CAMPO_NIVELORGANIZATIVO_ID
                + ", " + Utilidades.CAMPO_NIVELORGANIZATIVO_NOMBRE + ", "
                + Utilidades.CAMPO_NIVELORGANIZATIVO_DESCRIPCION + ", " + Utilidades.CAMPO_NIVELORGANIZATIVO_TIPO + ", "
                + Utilidades.CAMPO_NIVELORGANIZATIVO_ESOFICIAL + ", " + Utilidades.CAMPO_NIVELORGANIZATIVO_NIVELPADRE
                +", "+Utilidades.CAMPO_NIVELORGANIZATIVOUSUARIO_FECHAACTUALIZACION
                + ") VALUES (" + ID + ", '" + nombre + "', '" + descripcion + "', '" + tipo + "', "
                + esOficial + ", " + nivelPadre + ", '"+fechaUltimaMod+ "');";

        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL(insert);
        db.close();
    }

    public ArrayList<Componente> getNivelesOrganizativos(Usuario usuario) throws ExecutionException, InterruptedException, ParseException {
        System.out.println("Sincronizar");
        this.sincronizarBDLocal(usuario);
        System.out.println("Sincronizado");

        String select = "SELECT * FROM " + Utilidades.TABLA_NIVELORGANIZATIVO + ";";

        SQLiteDatabase db = c.getReadableDatabase();
        String[] parametros = {};
        Cursor cursor = db.rawQuery(select, parametros);
        cursor.moveToFirst();

        ArrayList<Componente> niveles = new ArrayList<Componente>();
        String idPadre = "";
        NivelOrganizativo nivel;

        while (!cursor.isAfterLast()) {
            nivel = new NivelOrganizativo();

            nivel.setID(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_NIVELORGANIZATIVO_ID)));
            nivel.setNombre(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_NIVELORGANIZATIVO_NOMBRE)));
            nivel.setDescripcion(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_NIVELORGANIZATIVO_DESCRIPCION)));
            ;
            nivel.setTipo(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_NIVELORGANIZATIVO_TIPO)));
            nivel.setOficialidad(Integer.parseInt(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_NIVELORGANIZATIVO_ID))));
            idPadre = cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_NIVELORGANIZATIVO_NIVELPADRE));
            addNivel(niveles, nivel, idPadre);

            cursor.moveToNext();
        }

        cursor.close();
        db.close();

        getActividades(niveles);

        return niveles;
    }

    private void addNivel(ArrayList<Componente> lista, Componente nivel, String padre) {
        Boolean tienePadre = false;
        ArrayList<Componente> hijos;
        int nivelProfundidad = 1;

        for (Componente componente : lista) {
            if (!tienePadre && componente.getID().equals(padre)) {
                tienePadre = true;
                //nivel.setNivel(nivelProfundidad);
                componente.addComponente(nivel);
            } else {
                if (!tienePadre) {
                    hijos = componente.getHijos();
                    if (!hijos.isEmpty()) {
                        tienePadre = addNivelRecursivo(hijos, nivel, padre, tienePadre, nivelProfundidad + 1);
                    }
                }
            }
        }

        if (!tienePadre) {
            //nivel.setNivel(0);
            lista.add(nivel);
        }
    }

    private Boolean addNivelRecursivo(ArrayList<Componente> lista, Componente nivel, String padre, Boolean tienePadre, int nivelProfundidad) {
        ArrayList<Componente> hijos;
        for (Componente componente : lista) {
            if (!tienePadre && componente.getID().equals(padre)) {
                tienePadre = true;
                //nivel.setNivel(nivelProfundidad);
                componente.addComponente(nivel);
                return tienePadre;
            } else {
                if (!tienePadre) {
                    hijos = componente.getHijos();
                    if (!hijos.isEmpty()) {
                        tienePadre = addNivelRecursivo(hijos, nivel, padre, tienePadre, nivelProfundidad + 1);
                    }
                }
            }
        }

        return tienePadre;
    }

    public void setActividad(int ID, String nombre, String descripcion, int nivelOrganizativo, String fechaUltimaMod) {
        String insert = "INSERT OR REPLACE INTO " + Utilidades.TABLA_ACTIVIDAD + " (" + Utilidades.CAMPO_ACTIVIDAD_ID
                + ", " + Utilidades.CAMPO_ACTIVIDAD_NOMBRE + ", "
                + Utilidades.CAMPO_ACTIVIDAD_DESCRIPCION + ", " + Utilidades.CAMPO_ACTIVIDAD_NIVELORGANIZATIVO
                + ", " + Utilidades.CAMPO_ACTIVIDAD_FECHAACTUALIZACION
                + ") VALUES (" + ID + ", '" + nombre + "', '" + descripcion + "', " + nivelOrganizativo
                + ", '" + fechaUltimaMod +  "');";

        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL(insert);
        db.close();
    }

    public void getActividades(ArrayList<Componente> componentes) {
        String select = "SELECT * FROM " + Utilidades.TABLA_ACTIVIDAD + ";";

        SQLiteDatabase db = c.getReadableDatabase();
        String[] parametros = {};
        Cursor cursor = db.rawQuery(select, parametros);
        cursor.moveToFirst();

        Actividad actividad;
        String idPadre = "";

        while (!cursor.isAfterLast()) {
            actividad = new Actividad();

            actividad.setID(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_ACTIVIDAD_ID)));
            actividad.setNombre(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_ACTIVIDAD_NOMBRE)));
            actividad.setDescripcion(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_ACTIVIDAD_DESCRIPCION)));
            idPadre = cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_ACTIVIDAD_NIVELORGANIZATIVO));
            getCategoriasEnActividad(actividad);
            addNivel(componentes, actividad, idPadre);

            cursor.moveToNext();
        }

        cursor.close();
        db.close();
    }

    public void setCategoria(int ID, String nombre, String descripcion, int actividad, String fechaUltimaMod) {
        String insert = "INSERT OR REPLACE INTO " + Utilidades.TABLA_CATEGORIA + " (" + Utilidades.CAMPO_CATEGORIA_ID
                + ", " + Utilidades.CAMPO_CATEGORIA_NOMBRE + ", "
                + Utilidades.CAMPO_CATEGORIA_DESCRIPCION + ", " + Utilidades.CAMPO_CATEGORIA_ACTIVIDAD
                + ", " + Utilidades.CAMPO_CATEGORIA_FECHAACTUALIZACION
                + ") VALUES (" + ID + ", '" + nombre + "', '" + descripcion + "', " + actividad
                + ", '" + fechaUltimaMod + "');";

        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL(insert);
        db.close();
    }

    public void getCategoriasEnActividad(Actividad actividad) {
        String select = "SELECT * FROM " + Utilidades.TABLA_CATEGORIA + " WHERE " + Utilidades.CAMPO_CATEGORIA_ACTIVIDAD + " = ?;";

        SQLiteDatabase db = c.getReadableDatabase();
        String[] parametros = {actividad.getID()};
        Cursor cursor = db.rawQuery(select, parametros);
        cursor.moveToFirst();

        Categoria categoria;

        while (!cursor.isAfterLast()) {
            categoria = new Categoria();

            categoria.setID((cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_CATEGORIA_ID))));
            categoria.setNombreCategoria((cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_CATEGORIA_NOMBRE))));
            categoria.setDescripcion((cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_CATEGORIA_DESCRIPCION))));
            categoria.setID((cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_CATEGORIA_ID))));

            getGruposEnCategoria(categoria);
            actividad.addCategoria(categoria);

            cursor.moveToNext();
        }

        cursor.close();
        db.close();
    }

    public void setGrupo(int ID, String nombre, String descripcion, int categoria, String password, int silenciado, int publico, String fechaUltimaMod) {
        String insert = "INSERT OR REPLACE INTO " + Utilidades.TABLA_GRUPO + " (" + Utilidades.CAMPO_GRUPO_ID
                + ", " + Utilidades.CAMPO_GRUPO_NOMBRE + ", "
                + Utilidades.CAMPO_GRUPO_DESCRIPCION + ", " + Utilidades.CAMPO_GRUPO_CATEGORIA + ", "
                + Utilidades.CAMPO_GRUPO_PASSWORD + ", " + Utilidades.CAMPO_GRUPO_SILENCIADO + ", "
                + Utilidades.CAMPO_GRUPO_PUBLICO + ", " + Utilidades.CAMPO_GRUPO_FECHAACTUALIZACION
                + ") VALUES (" + ID + ", '" + nombre + "', '" + descripcion + "', " + categoria
                + ", '" + password + "', " + silenciado + ", " + publico + ", '" + fechaUltimaMod + "');";

        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL(insert);
        db.close();
    }

    public void getGruposEnCategoria(Categoria categoria) {
        String select = "SELECT * FROM " + Utilidades.TABLA_GRUPO + " WHERE " + Utilidades.CAMPO_GRUPO_CATEGORIA + " = ?;";

        SQLiteDatabase db = c.getReadableDatabase();
        String[] parametros = {categoria.getID()};
        Cursor cursor = db.rawQuery(select, parametros);
        cursor.moveToFirst();

        Grupo grupo;

        while (!cursor.isAfterLast()) {
            grupo = new Grupo();

            grupo.setID(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_GRUPO_ID)));
            grupo.setNombreGrupo(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_GRUPO_NOMBRE)));
            grupo.setDescripcion(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_GRUPO_DESCRIPCION)));
            grupo.setContrasena(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_GRUPO_PASSWORD)));
            grupo.setPublico(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_GRUPO_PUBLICO)).equals("1"));
            grupo.setSilenciado(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_GRUPO_SILENCIADO)).equals("1"));

            try {
                getEventosEnGrupo(grupo);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            categoria.addGrupo(grupo);

            cursor.moveToNext();
        }

        cursor.close();
        db.close();
    }

    public void setEvento(int ID, int grupo, String descripcion, String lugar, String fechaInicio,
                          String fechaFin, String horaInicio, String horaFin, int esRecordatorio, String fechaUltimaMod) {
        String insert = "INSERT OR REPLACE INTO " + Utilidades.TABLA_EVENTO + " (" + Utilidades.CAMPO_EVENTO_ID
                + ", " + Utilidades.CAMPO_EVENTOGRUPO_GRUPO + ", "
                + Utilidades.CAMPO_EVENTO_DESCRIPCION + ", " + Utilidades.CAMPO_EVENTO_LUGAR + ", "
                + Utilidades.CAMPO_EVENTO_FECHAINICIO + ", " + Utilidades.CAMPO_EVENTO_FECHAFIN + ", "
                + Utilidades.CAMPO_EVENTO_HORAINICIO + ", " + Utilidades.CAMPO_EVENTO_HORAFIN + ", "
                + Utilidades.CAMPO_EVENTO_ESRECORDATORIO + ", " + Utilidades.CAMPO_EVENTO_FECHAACTUALIZACION
                + ") VALUES (" + ID + ", " + grupo + ", '" + descripcion + "', '" + lugar + "', '"
                + fechaInicio + "', '" + fechaFin + "', '" + horaInicio + "', '" + horaFin + "', "
                + esRecordatorio + ", '" + fechaUltimaMod + "');";

        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL(insert);
        db.close();
    }

    public void getEventosEnGrupo(Grupo grupo) throws ParseException {
        String select = "SELECT * FROM " + Utilidades.TABLA_EVENTO + " WHERE " + Utilidades.CAMPO_EVENTO_GRUPO + " = ?;";

        SQLiteDatabase db = c.getReadableDatabase();
        String[] parametros = {grupo.getID()};
        Cursor cursor = db.rawQuery(select, parametros);
        cursor.moveToFirst();

        Evento evento;

        while (!cursor.isAfterLast()) {
            evento = new Evento();

            evento.setID(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_ID)));
            evento.setNombreEvento(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_NOMBRE)));
            evento.setDescripcion(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_DESCRIPCION)));
            evento.setLugar(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_LUGAR)));
            evento.setFechaInicio(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_FECHAINICIO)), formatoFecha);
            evento.setFechaFin(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_FECHAFIN)), formatoFecha);
            evento.setHoraInicio(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_HORAINICIO)));
            evento.setHoraFin(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_HORAFIN)));
            evento.setEsRecordatorio(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_ESRECORDATORIO)).equals("1"));

            getNotasEnEvento(evento);

            grupo.addEvento(evento);

            cursor.moveToNext();
        }

        cursor.close();
        db.close();
    }

    public void getNotasEnEvento(Evento evento) throws ParseException {
        String select = "SELECT * FROM " + Utilidades.TABLA_NOTA + " WHERE " + Utilidades.CAMPO_NOTA_EVENTO + " = ?;";

        SQLiteDatabase db = c.getReadableDatabase();
        String[] parametros = {evento.getID()};
        Cursor cursor = db.rawQuery(select, parametros);
        cursor.moveToFirst();

        Nota nota;

        while (!cursor.isAfterLast()) {
            nota = new Nota();

            nota.setID(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_NOTA_ID)));
            nota.setEsPublica(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_NOTA_ESPUBLICA)).equals("1"));
            nota.setEvento(Integer.parseInt(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_NOTA_EVENTO))));
            nota.setFecha(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_NOTA_FECHA)), this.formatoFecha);
            nota.setHora(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_NOTA_HORA)));
            nota.setTitulo(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_NOTA_TITULO)));
            nota.setTexto(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_NOTA_TEXTO)));
            nota.setIDCreador(Integer.parseInt(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_NOTA_CREADOR))));


            evento.addNota(nota);

            cursor.moveToNext();
        }

        cursor.close();
        db.close();
    }

    public void setCalendarioEvento(int calendario, int evento, String fechaUltimaMod) {
        String insert = "INSERT OR REPLACE INTO " + Utilidades.TABLA_CALENDARIOEVENTO + " ("
                + Utilidades.CAMPO_CALENDARIOEVENTO_CALENDARIO + ", "
                + Utilidades.CAMPO_CALENDARIOEVENTO_EVENTO + ", "+ Utilidades.CAMPO_CALENDARIOEVENTO_FECHAACTUALIZACION
                + ") VALUES (" + calendario
                + ", " + evento + ", '" + fechaUltimaMod + "');";

        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL(insert);
        db.close();
    }

    public void guardarCalendarioUsuario(ArrayList<Integer> eventos, int calendario) throws ExecutionException, InterruptedException {
        resetCalendarioEvento();

        String calendarioString = Integer.toString(calendario);
        Conector conector;

        if (calendario == 0)
        {
            //Calendario invitado, no lo subimos al backend
            String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());
            for (Integer evento : eventos)
            {
                setCalendarioEvento(calendario, evento.intValue(), fechaActual);
            }
        }
        else
        {
            //Calendario usuario registrado, lo subimos al backend
            String parametro;
            String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());
            for (Integer evento : eventos)
            {
                setCalendarioEvento(calendario, evento.intValue(), fechaActual);
                conector = new Conector(this, Utilidades.URL);
                parametro = calendarioString
                        +"/evento/"+Integer.toString(evento);
                conector.postRequestAddCalendarioEvento(new Conector.Paquete(parametro, ""));
                conector.get();
            }
        }
    }

    public ArrayList<Evento> recuperarCalendarioUsuario(int calendario) throws ParseException {
        String select = "SELECT E.* FROM " + Utilidades.TABLA_EVENTO + " E, " + Utilidades.TABLA_CALENDARIOEVENTO
                + " CE WHERE CE." + Utilidades.CAMPO_CALENDARIOEVENTO_CALENDARIO + " = ? AND CE."
                + Utilidades.CAMPO_CALENDARIOEVENTO_EVENTO + " = E." + Utilidades.CAMPO_EVENTO_ID;

        SQLiteDatabase db = c.getReadableDatabase();
        String[] parametros = {Integer.toString(calendario)};
        Cursor cursor = db.rawQuery(select, parametros);
        cursor.moveToFirst();

        ArrayList<Evento> eventos = new ArrayList<Evento>();
        Evento evento;
        String formatoFecha = Utilidades.FORMATO_FECHA;
        String formatohora = Utilidades.FORMATO_HORA;

        while (!cursor.isAfterLast()) {
            evento = new Evento();
            evento.setID(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_ID)));
            evento.setNombreEvento(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_NOMBRE)));
            evento.setDescripcion(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_DESCRIPCION)));
            evento.setLugar(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_LUGAR)));
            evento.setFechaInicio(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_FECHAINICIO)), formatoFecha);
            evento.setFechaFin(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_FECHAFIN)), formatoFecha);
            evento.setHoraInicio(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_HORAINICIO)));
            evento.setHoraFin(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_HORAFIN)));
            evento.setEsRecordatorio(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_EVENTO_ESRECORDATORIO)).equals("1"));
            this.getNotasEnEvento(evento);
            eventos.add(evento);

            cursor.moveToNext();
        }

        cursor.close();
        db.close();

        return eventos;
    }

    public Grupo getGrupoDeEvento(int eventoID) {
        String select = "SELECT G.* FROM " + Utilidades.TABLA_GRUPO + " G, " + Utilidades.TABLA_EVENTO
                + " E WHERE E." + Utilidades.CAMPO_EVENTO_ID + " = ? AND E." + Utilidades.CAMPO_EVENTO_GRUPO
                + " = G." + Utilidades.CAMPO_GRUPO_ID + ";";

        SQLiteDatabase db = c.getReadableDatabase();
        String[] parametros = {Integer.toString(eventoID)};
        Cursor cursor = db.rawQuery(select, parametros);
        Grupo grupo;


        if(cursor!=null && cursor.getCount()>0)
        {
            cursor.moveToFirst();
            grupo = new Grupo();
            grupo.setID(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_GRUPO_ID)));
            grupo.setNombreGrupo(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_GRUPO_NOMBRE)));
            grupo.setDescripcion(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_GRUPO_DESCRIPCION)));
            grupo.setContrasena(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_GRUPO_PASSWORD)));
            grupo.setPublico(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_GRUPO_PUBLICO)).equals("1"));
            grupo.setSilenciado(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_GRUPO_SILENCIADO)).equals("1"));
        }
        else
        {
            grupo = new Grupo();
            grupo.setID(Integer.toString(0));
            grupo.setNombreGrupo("Evento personal");
        }

        return grupo;
    }

    public Categoria getCategoriaDeEvento(int eventoID) {
        String select = "SELECT C.* FROM " + Utilidades.TABLA_GRUPO + " G, " + Utilidades.TABLA_EVENTO
                + " E, " + Utilidades.TABLA_CATEGORIA + " C WHERE E." + Utilidades.CAMPO_EVENTO_ID + " = ? AND E." + Utilidades.CAMPO_EVENTO_GRUPO
                + " = G." + Utilidades.CAMPO_GRUPO_ID + " AND C." + Utilidades.CAMPO_CATEGORIA_ID
                + " = G." + Utilidades.CAMPO_GRUPO_CATEGORIA + ";";

        SQLiteDatabase db = c.getReadableDatabase();
        String[] parametros = {Integer.toString(eventoID)};
        Cursor cursor = db.rawQuery(select, parametros);
        Categoria categoria;

        if(cursor!=null && cursor.getCount()>0)
        {
            cursor.moveToFirst();
            categoria = new Categoria();
            categoria.setID((cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_CATEGORIA_ID))));
            categoria.setNombreCategoria((cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_CATEGORIA_NOMBRE))));
            categoria.setDescripcion((cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_CATEGORIA_DESCRIPCION))));
            categoria.setID((cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_CATEGORIA_ID))));
        }
        else
        {
            categoria = new Categoria();
            categoria.setID(Integer.toString(0));
            categoria.setNombreCategoria("Evento personal");

        }

        return categoria;
    }

    public Actividad getActividadDeEvento(int eventoID) {
        String select = "SELECT A.* FROM " + Utilidades.TABLA_GRUPO + " G, " + Utilidades.TABLA_EVENTO
                + " E, " + Utilidades.TABLA_CATEGORIA + " C, " + Utilidades.TABLA_ACTIVIDAD + " A WHERE E."
                + Utilidades.CAMPO_EVENTO_ID + " = ? AND E." + Utilidades.CAMPO_EVENTO_GRUPO
                + " = G." + Utilidades.CAMPO_GRUPO_ID + " AND C." + Utilidades.CAMPO_CATEGORIA_ID
                + " = G." + Utilidades.CAMPO_GRUPO_CATEGORIA + " AND C." + Utilidades.CAMPO_CATEGORIA_ACTIVIDAD
                + " = A." + Utilidades.CAMPO_ACTIVIDAD_ID + ";";

        SQLiteDatabase db = c.getReadableDatabase();
        String[] parametros = {Integer.toString(eventoID)};
        Cursor cursor = db.rawQuery(select, parametros);
        Actividad actividad;

        if(cursor!=null && cursor.getCount()>0)
        {
            cursor.moveToFirst();
            actividad = new Actividad();
            actividad.setID(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_ACTIVIDAD_ID)));
            actividad.setNombre(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_ACTIVIDAD_NOMBRE)));
            actividad.setDescripcion(cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_ACTIVIDAD_DESCRIPCION)));
        }
        else
        {
            actividad = new Actividad();
            actividad.setID(Integer.toString(0));
            actividad.setNombre("Evento personal");
        }

        return actividad;
    }

    public boolean registrarUsuario(String email, String password, String nombre) throws ExecutionException, InterruptedException {
        boolean registrado = true;

        String jsonString = "{\"email\":\"" + email + "\",\"password\":\"" + password + "\",\"nombre\":\"" + nombre + "\"}";
        Conector conector = new Conector(this, Utilidades.URL);
        conector.postRequestAddUsuario(new Conector.Paquete("", jsonString));
        conector.get();
        registrado = conector.bool;

        if (registrado == true) {
            int usuarioID = conector.integer;
            jsonString = "{\"creador\":"+usuarioID+"}";
            conector = new Conector(this, Utilidades.URL);
            conector.postRequestAddCalendario(new Conector.Paquete("", jsonString));
            conector.get();
        }

        return registrado;
    }

    public int addEvento(int grupo, String descripcion, String lugar, String fechaInicio,
                         String fechaFin, String horaInicio, String horaFin, int esRecordatorio, int calendarioID,
                         Usuario usuario, boolean notificar) throws ExecutionException, InterruptedException {
        /*
{"lugar": "TEST",
"descripcion": "TES TEST TEST TEST","fechaInicio": "2020-04-29T00:00:00.000+0000",
"fechaFin": "2020-04-29T00:00:00.000+0000","horaInicio": "09:30:00","horaFin": "10:30:00",
"esRecordatorio": true,"grupo": 1,}
         */
        boolean esRecordatorioBool = (esRecordatorio == 1);


        String jsonString = "{\"lugar\":\"" + lugar + "\",\"descripcion\":\"" + descripcion + "\",\"fechaInicio\":\"" +
                fechaInicio + "\",\"fechaFin\":\"" + fechaFin + "\",\"horaInicio\":\"" + horaInicio +
                "\",\"horaFin\":\"" + horaFin + "\",\"esRecordatorio\":" + esRecordatorioBool;
        if (grupo == 0) {
            jsonString = jsonString + "}";
            ;
        } else {
            jsonString = jsonString + ",\"grupo\":" + grupo + "}";
        }

        System.out.println(jsonString);
        Conector conector = new Conector(this, Utilidades.URL);
        conector.postRequestAddEvento(new Conector.Paquete("", jsonString));
        conector.get();

        int eventoID = conector.integer;
        String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());

        if (usuario == null || usuario.getID().equals("0"))
        {
            System.out.println("Es invitado");
            this.setCalendarioEvento(calendarioID,eventoID, fechaActual);
        }
        else
        {
            System.out.println("Es usuario registrado, con calendario: " + calendarioID);
            conector = new Conector(this, Utilidades.URL);
            conector.postRequestAddCalendarioEvento(new Conector.Paquete(Integer.toString(calendarioID)
                    +"/evento/"+Integer.toString(eventoID), ""));
            conector.get();
            System.out.println("Relacion calendarioevento creada");
            this.setCalendarioEvento(calendarioID,eventoID, fechaActual);
        }
        //Crear notificacion
        if(grupo != 0 && notificar)
        {
            //No es un evento personal
            System.out.println("Tenemos que crear notificacion porque grupo_ " + grupo);
            this.crearNotificacion(grupo,"Nuevo evento "+eventoID,
                    "Se ha creado el evento ("+eventoID+") en el grupo "+grupo+".", usuario.getID());
        }
        return eventoID;
    }

    public void eliminarEvento(int id, int grupo, String creador, boolean notificar)
            throws ExecutionException, InterruptedException {
        Conector conector = new Conector(this, Utilidades.URL);
        conector.deleteRequestEliminarEvento(new Conector.Paquete(Integer.toString(id), ""));
        conector.get();

        if(notificar)
        this.crearNotificacion(grupo,"Eliminado evento "+id,
                "Se ha eliminado el evento ("+id+") en el grupo "+grupo+".", creador);
    }

    public void modificarEvento(int id, int grupo, String descripcion, String lugar, String fechaInicio,
                                String fechaFin, String horaInicio, String horaFin, int esRecordatorio,
                                String creador, boolean notificar)
            throws ExecutionException, InterruptedException
    {
        boolean esRecordatorioBool = (esRecordatorio == 1);


        String jsonString = "{\"lugar\":\"" + lugar + "\",\"descripcion\":\"" + descripcion + "\",\"fechaInicio\":\"" +
                fechaInicio + "\",\"fechaFin\":\"" + fechaFin + "\",\"horaInicio\":\"" + horaInicio +
                "\",\"horaFin\":\"" + horaFin + "\",\"esRecordatorio\":" + esRecordatorioBool +
                ",\"descripcion\":\"" + descripcion + "\",\"descripcion\":\"" + descripcion + "\"";
        if (grupo == 0) {
            jsonString = jsonString + "}";
            ;
        } else {
            jsonString = jsonString + ",\"grupo\":" + grupo + "}";
        }
        Conector conector = new Conector(this, Utilidades.URL);
        conector.putRequestModificarEvento(new Conector.Paquete(Integer.toString(id), jsonString));
        conector.get();

        if (notificar)
        {
            this.crearNotificacion(grupo,"Modificado evento "+id,
                    "Se ha modificado el evento ("+id+") en el grupo "+grupo+".", creador);
        }

    }

    public void deleteEvento(int id)
    {
        SQLiteDatabase db = c.getWritableDatabase();

        String[] parametros = {Integer.toString(id)};
        db.delete(Utilidades.TABLA_EVENTO,Utilidades.CAMPO_EVENTO_ID+" = ?",parametros);

        db.close();
    }

    public void updateEvento(int ID, int grupo, String descripcion, String lugar, String fechaInicio,
                             String fechaFin, String horaInicio, String horaFin, int esRecordatorio)
    {
        String insert = "INSERT OR REPLACE INTO " + Utilidades.TABLA_EVENTO + " (" + Utilidades.CAMPO_EVENTO_ID
                + ", " + Utilidades.CAMPO_EVENTOGRUPO_GRUPO + ", "
                + Utilidades.CAMPO_EVENTO_DESCRIPCION + ", " + Utilidades.CAMPO_EVENTO_LUGAR + ", "
                + Utilidades.CAMPO_EVENTO_FECHAINICIO + ", " + Utilidades.CAMPO_EVENTO_FECHAFIN + ", "
                + Utilidades.CAMPO_EVENTO_HORAINICIO + ", " + Utilidades.CAMPO_EVENTO_HORAFIN + ", "
                + Utilidades.CAMPO_EVENTO_ESRECORDATORIO + ") VALUES (" + ID + ", " + grupo + ", '" + descripcion
                + "', '" + lugar + "', '" + fechaInicio + "', '" + fechaFin + "', '" + horaInicio + "', '"
                + horaFin + "', " + esRecordatorio + ");";

        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL(insert);
        db.close();
    }

    public int iniciarSesion(String email, String password) throws ExecutionException, InterruptedException, ParseException {
        System.out.println("Iniciando sesiooooooon");
        this.resetTablas();
        Usuario usuarioAux = new Usuario();
        usuarioAux.setID("0");
        usuarioAux.setGruposSuscritos(new ArrayList<>());
        this.sincronizarBDLocal(usuarioAux);

        int respuesta = 0;

        String jsonString = "{\"email\":\""+email+"\",\"password\":\""+password+"\"}";
        Conector conector = new Conector(this, Utilidades.URL);
        conector.postRequestLogin(new Conector.Paquete("", jsonString));
        conector.get();
        respuesta = conector.integer;

        /*
            motivo                      error
            credenciales erroneas       401
            usuario bloqueado           423
            login correcto              200
            otros errores               != 200
        */

        if(respuesta == 200)
        {
            Usuario usuario = new Usuario();

            //login correcto
            usuario.setEmail(email);
            //usuario.setPassword(password);

            //get usuario id y nombre
            conector = new Conector(this, Utilidades.URL);
            conector.getRequestGetUsuario(new Conector.Paquete(email, ""));
            conector.get();
            usuario.setID(Integer.toString(conector.integer));
            usuario.setNombre(conector.string);

            //get calendario
            conector = new Conector(this, Utilidades.URL);
            conector.getRequestCalendarioPorUsuario(new Conector.Paquete(usuario.getID(), ""));
            conector.get();
            usuario.setCalendario(conector.integer);

            //get actividades moderadas
            usuario.setActividadesModeradas(this.getActividadesModeradas(usuario));

            //get grupos suscritos
            usuario.setGruposSuscritos(this.getGruposSuscritos(usuario));

            //get grupos bloqueados
            usuario.setGruposBloqueados(this.getGruposBloqueados(usuario));

            //get notas
            this.descargarNotas(usuario.getID());

            System.out.println("Seting usuario: " + usuario.getID());
            setMiUsuario(usuario);
            System.out.println("Setted usuario: " + getMiUsuario().getID());

            //set calendario
            conector = new Conector(this, Utilidades.URL);
            conector.getRequestListaCalendarioEventoPorUsuario(new Conector.Paquete(usuario.getID(), ""));
            conector.get();
            ArrayList<Conector.CalendarioEventoAPI> calendarioEventoAPIs = conector.calendarioEventos;

            ArrayList<Integer> eventosID = new ArrayList<>();

            if(calendarioEventoAPIs != null && calendarioEventoAPIs.isEmpty() == false)
            {
                for (Conector.CalendarioEventoAPI calendarioEvento : calendarioEventoAPIs)
                {
                    eventosID.add(calendarioEvento.evento);
                }
                this.guardarCalendarioUsuario(eventosID,calendarioEventoAPIs.get(0).calendario);
            }
        }
        return respuesta;
    }

    public ArrayList<Integer> getActividadesModeradas(Usuario usuario) throws ExecutionException, InterruptedException {
        Conector conector = new Conector(this, Utilidades.URL);
        conector.getRequestRolesActividadPorUsuario(new Conector.Paquete(usuario.getID(), ""));
        conector.get();
        ArrayList<Integer> actividadesID = new ArrayList<Integer>();
        actividadesID.add(0);
        try {
            actividadesID.addAll(conector.integers);
        } catch (NullPointerException e){
            e.printStackTrace();
        }
        return actividadesID;
    }

    public ArrayList<Integer> getGruposSuscritos(Usuario usuario) throws ExecutionException, InterruptedException {
        Conector conector = new Conector(this, Utilidades.URL);
        conector.getRequestGruposSuscritosPorUsuario(new Conector.Paquete(usuario.getID(), ""));
        conector.get();
        ArrayList<Conector.UsuarioGrupoAPI> listaUsuarioGrupo = conector.usuarioGrupos;

        ArrayList<Integer> gruposID = new ArrayList<>();
        if(listaUsuarioGrupo != null)
        {
            for (Conector.UsuarioGrupoAPI usuarioGrupo : listaUsuarioGrupo)
            {
                if(usuarioGrupo.suscrito)
                {
                    gruposID.add(usuarioGrupo.grupo);
                }
            }

        }
        return gruposID;
    }

    public ArrayList<Integer> getGruposBloqueados(Usuario usuario) throws ExecutionException, InterruptedException {
        Conector conector = new Conector(this, Utilidades.URL);
        conector.getRequestGruposBloqueadosPorUsuario(new Conector.Paquete(usuario.getID(), ""));
        conector.get();
        ArrayList<Conector.UsuarioGrupoAPI> listaUsuarioGrupo = conector.usuarioGrupos;

        ArrayList<Integer> gruposID = new ArrayList<>();
        if (listaUsuarioGrupo != null)
        {
            for (Conector.UsuarioGrupoAPI usuarioGrupo : listaUsuarioGrupo)
            {
                if(usuarioGrupo.bloqueado)
                {
                    gruposID.add(usuarioGrupo.grupo);
                }
            }
        }
        return gruposID;
    }

    public void suscribirseAGrupo(int grupoID, Usuario usuario) throws ExecutionException, InterruptedException {

        Conector conector = new Conector(this,Utilidades.URL);
        String parametro = Utilidades.POST_USUARIO+usuario.getID()+"/grupo/"+Integer.toString(grupoID)+"/suscribir";
        conector.putRequestUsuarioSuscribirGrupo(new Conector.Paquete(parametro,""));
        conector.get();

        if (conector.integer == 200)
        {
            ArrayList<Integer> grupos = usuario.getGruposSuscritos();
            grupos.add(grupoID);
            usuario.setGruposSuscritos(grupos);
            setMiUsuario(usuario);
        }

    }

    public void desuscribirseAGrupo(int grupoID, Usuario usuario) throws ExecutionException, InterruptedException {
;

        Conector conector = new Conector(this,Utilidades.URL);
        String parametro = Utilidades.POST_USUARIO+usuario.getID()+"/grupo/"+Integer.toString(grupoID)+"/desuscribir";
        conector.putRequestUsuarioDesuscribirGrupo(new Conector.Paquete(parametro,""));
        conector.get();

        if (conector.integer == 200)
        {
            ArrayList<Integer> grupos = usuario.getGruposSuscritos();
            if (grupos.contains(grupoID))
            {
                grupos.remove(new Integer(grupoID));
            }
            usuario.setGruposSuscritos(grupos);
            setMiUsuario(usuario);
        }

    }

    public void setNota(int ID, String titulo, String texto, String fecha, String hora, int esPublica, int creador, String fechaActualizacion, int evento)
    {
        String insert = "INSERT OR REPLACE INTO "+Utilidades.TABLA_NOTA+" ("+Utilidades.CAMPO_NOTA_ID
                +", "+Utilidades.CAMPO_NOTA_TITULO+", "+ Utilidades.CAMPO_NOTA_TEXTO+", "
                +Utilidades.CAMPO_NOTA_FECHA+", "+Utilidades.CAMPO_NOTA_HORA+", "+Utilidades.CAMPO_NOTA_ESPUBLICA
                +", "+Utilidades.CAMPO_NOTA_CREADOR+", "+Utilidades.CAMPO_NOTA_FECHAACTUALIZACION
                +", "+Utilidades.CAMPO_NOTA_EVENTO+") VALUES ("+ID+", '"+titulo+"', '"+texto+"', '"+fecha+"', '"+hora+"', "+esPublica
                +", "+creador+", '"+fechaActualizacion+"', "+evento+");";

        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL(insert);
        db.close();
    }

    public void deleteNota(int ID)
    {
        SQLiteDatabase db = c.getWritableDatabase();

        String[] parametros = {Integer.toString(ID)};
        db.delete(Utilidades.TABLA_NOTA,Utilidades.CAMPO_NOTA_ID+" = ?",parametros);

        db.close();
    }

    public void addNota(String titulo, String texto, String fecha, String hora, int esPublica, int creador, int evento) throws ExecutionException, InterruptedException
    {
        /*
        {
        "titulo": "Hacer parte 12",
        "texto": "Hacer mi parte de la práctica de LIS",
        "fecha": "2020-03-01",
        "hora": "11:00:00",
        "esPublica": true,
        "evento": 17,
        "creador": 1463100
        }
         */
        boolean esPublicaBool = true;
        if(esPublica==0)
        {
            esPublicaBool = false;
        }
        String jsonString = "{\"titulo\":\""+titulo+"\",\"texto\":\""+texto+"\",\"fecha\":\""+fecha
                +"\",\"hora\":\""+hora+"\",\"esPublica\":"+esPublicaBool+",\"evento\":"+evento
                +",\"creador\":"+creador+"}";

        Conector conector = new Conector(this, Utilidades.URL);
        conector.postRequestAddNota(new Conector.Paquete("",jsonString));
        conector.get();
    }

    public void descargarNotas(String usuarioID) throws ExecutionException, InterruptedException
    {
        //get notas personales
        this.resetNota();

        Conector conector = new Conector(this, Utilidades.URL);
        conector.getRequestNotasPersonales(new Conector.Paquete(usuarioID, ""));
        conector.get();

        //get notas publicas de grupos a los que estoy suscrito
        conector = new Conector(this, Utilidades.URL);
        conector.getRequestNotasPublicas(new Conector.Paquete(usuarioID, "")); //de grupos a los que estoy suscrito
        conector.get();

    }

    public boolean hayConexionAInternet() {
        boolean haveConnectedWifi = false;
        boolean haveConnectedMobile = false;

        ConnectivityManager cm = (ConnectivityManager) this.context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo[] netInfo = cm.getAllNetworkInfo();
        for (NetworkInfo ni : netInfo) {
            if (ni.getTypeName().equalsIgnoreCase("WIFI"))
                if (ni.isConnected())
                    haveConnectedWifi = true;
            if (ni.getTypeName().equalsIgnoreCase("MOBILE"))
                if (ni.isConnected())
                    haveConnectedMobile = true;
        }
        return haveConnectedWifi || haveConnectedMobile;
    }

    //FORMATO ES YYYY-MM-DDTHH:MM:SS.SSS
    public String getFechaUltimaActualizacionLocal()
    {
        String select = "SELECT * FROM "+Utilidades.TABLA_FECHAULTIMAACTUALIZACION+";";

        SQLiteDatabase db = c.getReadableDatabase();
        String[] parametros = {};
        Cursor cursor = db.rawQuery(select, parametros);
        String fechaUltimaActualizacion = "";

        if(cursor!=null && cursor.getCount()>0)
        {
            cursor.moveToFirst();
            fechaUltimaActualizacion = cursor.getString(cursor.getColumnIndex(Utilidades.CAMPO_FECHAULTIMAACTUALIZACION));

        }

        return fechaUltimaActualizacion;
    }

    public void setFechaUltimaActualizacionLocal(String fecha)
    {
        String insert = "INSERT OR REPLACE INTO "+Utilidades.TABLA_FECHAULTIMAACTUALIZACION+" ("
                +Utilidades.CAMPO_FECHAULTIMAACTUALIZACION+") VALUES ('"+fecha+"');";

        SQLiteDatabase db = c.getWritableDatabase();
        db.execSQL(insert);
        db.close();
    }

    public void sincronizarBDLocal(Usuario usuario) throws ParseException, ExecutionException, InterruptedException {
        System.out.println("EMPEZANDO SINCRONIZACION");
        if(hayConexionAInternet())
        {
            //subir cambios que se han hecho offline



            //descargar cambios de la bd del backend
            String fechaUltimaActualizacion = this.getFechaUltimaActualizacionLocal();


            if(fechaUltimaActualizacion.isEmpty())
            {
                //Sincronizando por primera vez
                System.out.println("Sincronizando por primera vez");

                //Descargar todas las tablas necesarias
                this.setDatosReales();

                //Set fecha de actualizacion
                java.util.Date fechaNueva = Calendar.getInstance().getTime();
                String fechaNuevaString = this.formatterFechaActualizacion.format(fechaNueva);
                System.out.println("La nueva fecha de actualizacion es: "+fechaNuevaString);
                this.setFechaUltimaActualizacionLocal(fechaNuevaString);
            }
            else
            {
                //Sincronizando
                System.out.println("Sincronizando para fecha: "+fechaUltimaActualizacion);

                //Sincronizar todas las tablas necesarias por fechaUltimaActualizacion
                String fechaPedida = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss")
                        .format(this.formatterFechaActualizacion.parse(fechaUltimaActualizacion));
                System.out.println("Enviando fecha : "+fechaPedida);
                this.sincronizarTablas(fechaPedida, usuario);

                //Set nueva fecha de actualizacion
                this.resetFechaUltimaActualizacion();
                java.util.Date fechaNueva = Calendar.getInstance().getTime();
                String fechaNuevaString = this.formatterFechaActualizacion.format(fechaNueva);
                System.out.println("La nueva fecha de actualizacion es: "+fechaNuevaString);
                this.setFechaUltimaActualizacionLocal(fechaNuevaString);
            }

            this.descargarNotas(usuario.getID());
        }

    }

    public void sincronizarTablas(String fechaUltimaActualizacion, Usuario usuario)
            throws ExecutionException, InterruptedException, ParseException {

        System.out.println("funcion sincronizarTablas");

        Conector conector = new Conector(this, Utilidades.URL);
        conector.requestSincronizarNivelesOrganizativos(new Conector.Paquete(fechaUltimaActualizacion,""));
        conector.get();

        conector = new Conector(this, Utilidades.URL);
        conector.requestSincronizarActividades(new Conector.Paquete(fechaUltimaActualizacion,""));
        conector.get();

        conector = new Conector(this, Utilidades.URL);
        conector.requestSincronizarCategorias(new Conector.Paquete(fechaUltimaActualizacion,""));
        conector.get();

        conector = new Conector(this, Utilidades.URL);
        conector.requestSincronizarGrupos(new Conector.Paquete(fechaUltimaActualizacion,""));
        conector.get();

        conector = new Conector(this, Utilidades.URL);
        conector.requestSincronizarEventos(new Conector.Paquete(fechaUltimaActualizacion,""));
        conector.get();

        int usuarioID = Integer.parseInt(usuario.getID());

        if (usuarioID != 0) {
            System.out.println("Hemos entradooo con id " + usuarioID);
            conector = new Conector(this, Utilidades.URL);
            conector.requestSincronizarNotasPersonales(new Conector.Paquete(usuarioID
                    + "/" + Utilidades.FECHAULTIMAMODIFICACION + fechaUltimaActualizacion, ""));
            conector.get();

            conector = new Conector(this, Utilidades.URL);
            conector.requestSincronizarNotasPublicas(new Conector.Paquete(usuarioID
                    + "/suscrito/" + Utilidades.FECHAULTIMAMODIFICACION + fechaUltimaActualizacion, ""));
            conector.get();

            conector = new Conector(this, Utilidades.URL);
            conector.requestSincronizarCalendarioEventos(new Conector.Paquete(usuarioID
                    + "/" + Utilidades.FECHAULTIMAMODIFICACION + fechaUltimaActualizacion, ""));
            conector.get();
            ArrayList<Conector.CalendarioEventoAPI> calendarioEventoAPIs = conector.calendarioEventos;

            ArrayList<Integer> eventosID = new ArrayList<>();

            if (calendarioEventoAPIs != null && calendarioEventoAPIs.isEmpty() == false) {
                for (Conector.CalendarioEventoAPI calendarioEvento : calendarioEventoAPIs) {
                    eventosID.add(calendarioEvento.evento);
                }
                this.guardarCalendarioUsuario(eventosID, calendarioEventoAPIs.get(0).calendario);
            }

            if(usuario.getGruposSuscritos() != null && !usuario.getGruposSuscritos().isEmpty())
            {
                ArrayList<Notificacion> notificaciones = this.recibirNotificaciones(usuario.getGruposSuscritos(), usuarioID);
                if (notificaciones != null && !notificaciones.isEmpty())
                {
                    for (Notificacion notificacion : notificaciones)
                    {
                        System.out.println("Notificacion: ");
                        System.out.println("ID: " + notificacion.getID());
                        System.out.println("Titulo: " + notificacion.getTitulo());
                        System.out.println("Leida: " + notificacion.getLeida());
                    }
                }
            }
            else {
                System.out.println("Usuario lista suscritos vacia");
            }

        }
        else {
            System.out.println("Usuario es id : " + usuarioID);
        }
    }

    public void crearNotificacion(int grupo, String titulo, String texto, String creador) throws ExecutionException, InterruptedException {
        java.util.Date fechaActual = Calendar.getInstance().getTime();
        String fecha = new SimpleDateFormat(Utilidades.FORMATO_FECHA).format(fechaActual);
        String hora = new SimpleDateFormat(Utilidades.FORMATO_HORA).format(fechaActual);
        String jsonString = "{\"grupo\":"+grupo+",\"creador\":"+creador+",\"titulo\":\""+titulo
                +"\",\"texto\":\""+texto+"\",\"fecha\":\""+fecha+"\",\"hora\":\""+hora+"\"}";
        Conector conector = new Conector(this, Utilidades.URL);
        conector.postRequestAddNotificacion(new Conector.Paquete("",jsonString));
        conector.get();
    }

    public ArrayList<Notificacion> recibirNotificaciones(ArrayList<Integer> gruposSuscritos, int usuarioID) throws ExecutionException, InterruptedException, ParseException {
        System.out.println("Recibiendo notificaciones");
        Conector conector;
        ArrayList<Conector.NotificacionAPI> notificacionesAPI;
        ArrayList<Notificacion> notificaciones = new ArrayList<>();

        boolean notificacionLeida;

        for (Integer integer : gruposSuscritos)
        {
            conector = new Conector(this,Utilidades.URL);
            conector.getRequestNotificacionesPorGrupo(new Conector.Paquete(Integer.toString(integer),""));
            conector.get();
            notificacionesAPI = conector.notificaciones;

            if (notificacionesAPI != null && !notificacionesAPI.isEmpty())
            {
                for (Conector.NotificacionAPI notificacionAPI : notificacionesAPI)
                {
                    notificacionLeida = this.notificacionLeidaAnteriormente(usuarioID,notificacionAPI.id);
                    Date fecha = new Date(new SimpleDateFormat(Utilidades.FORMATO_FECHA).parse(notificacionAPI.fecha).getTime());
                    Time hora = Time.valueOf(notificacionAPI.hora);
                    notificaciones.add(new Notificacion(Integer.toString(notificacionAPI.id), notificacionAPI.titulo,
                            notificacionAPI.texto, fecha, hora, Integer.toString(notificacionAPI.creador), notificacionLeida));

                    if(!notificacionLeida)
                    {
                        this.setNotificacionUsuario(usuarioID,notificacionAPI.id,true);
                    }
                    System.out.println("Notificacion creada : " + notificacionAPI.id);
                }
            }

        }

        return notificaciones;
    }
}


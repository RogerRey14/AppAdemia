package nucleo;

public class RolAdmin extends RolUsuario
{

    public void cerrarSesion()
    {

    }

    public void registrarUsuario(String email, String contrasena, String nombre, RolUsuario rol)
    {

    }

    public void modificarUsuario(Usuario usuario)
    {

    }

    public void crearActividad(String nombre, String descripcion)
    {

    }

    public void modificarActividad(Actividad actividad)
    {

    }

    public void eliminarActividad(Actividad actividad)
    {

    }

    //TODO
    //crear/mod/elim-NivelOrganizativo/Categoria/Grupo/Evento

    public void unirseGrupo(String ID, String contrasena)
    {

    }

    public void crearNota(Evento evento, String titulo, String descripcion, Boolean publica)
    {

    }

    public void descargarNotificaciones()
    {

    }

    public void bloquearUsuarioAplicacion(Usuario usuario)
    {

    }

    public void bloquearUsuarioActividad(Usuario usuario, Actividad actividad)
    {

    }

    public void bloquearUsuarioGrupo(Usuario usuario, Grupo grupo)
    {

    }

    public void desbloquearUsuarioAplicacion(Usuario usuario)
    {

    }

    public void desbloquearUsuarioActividad(Usuario usuario, Actividad actividad)
    {

    }

    public void desbloquearUsuarioGrupo(Usuario usuario, Grupo grupo)
    {

    }

    public void asignarAdmin(Usuario usuario, NivelOrganizativo nivelOrganizativo)
    {

    }

}
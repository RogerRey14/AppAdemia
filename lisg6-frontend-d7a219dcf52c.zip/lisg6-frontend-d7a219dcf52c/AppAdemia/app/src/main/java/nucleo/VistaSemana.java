package nucleo;

public class VistaSemana implements Vista
{
    public Calendario mostrar()
    {
    	return null;
    }
}
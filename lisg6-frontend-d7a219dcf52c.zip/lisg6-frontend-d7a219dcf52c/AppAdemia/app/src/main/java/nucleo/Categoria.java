package nucleo;

import android.renderscript.Script;

import java.util.ArrayList;

public class Categoria
{
    private String ID;
    private String nombreCategoria;
    private String descripcion;

    private ArrayList<Grupo> grupos;

    public Categoria() {
        grupos = new ArrayList<Grupo>();
    }

    public void print(String indentacion)
    {
        System.out.println(indentacion+"Es Categoria");
        System.out.println(indentacion+"ID: "+ ID);
        System.out.println(indentacion+"Nombre: "+ nombreCategoria);
        System.out.println(indentacion+"Descripcion: "+ descripcion);
        System.out.println(indentacion+"Numero de grupos: "+ grupos.size());
        if(grupos.isEmpty() == false)
        {
            indentacion=indentacion+"--";
            System.out.println(indentacion);
            for (Grupo grupo : grupos)
            {
//                grupo.print(indentacion);
//                System.out.println(indentacion);
            }
        }
    }

    //Getters y setters
    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public ArrayList<Grupo> getGrupos() {
        return grupos;
    }

    public void setGrupos(ArrayList<Grupo> grupos) {
        this.grupos = grupos;
    }

    public void addGrupo(Grupo grupo)
    {
        this.grupos.add(grupo);
    }

    public void eliminarGrupo(Grupo grupo)
    {
        this.grupos.remove(grupo);
    }
}
package nucleo;

import android.icu.util.UniversalTimeScale;
import android.os.AsyncTask;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.concurrent.ExecutionException;

//public class Conector extends AsyncTask<Void, Void, ArrayList<Conector.NivelOrganizativoAPI>>
public class Conector extends AsyncTask<Integer, Void, Boolean>
{

    public static class Paquete
    {
        public String parametro;
        public String jsonString;
        public Paquete()
        {

        }
        public Paquete(String parametro, String jsonString)
        {
            this.parametro=parametro;
            this.jsonString=jsonString;
        }
    }

    public static class NivelOrganizativoAPI
    {
        public int id;
        public String tipo;
        public String nombre;
        public String descripcion;
        public boolean esOficial;
        public int nivelPadre;
        public String fechaUltimaModificacion;
        public NivelOrganizativoAPI()
        {

        }
    }

    public static class ActividadAPI
    {
        public int id;
        public String nombre;
        public String descripcion;
        public int nivelOrganizativo;
        public String fechaUltimaModificacion;
        public ActividadAPI()
        {

        }
    }

    public static class CategoriaAPI
    {
        public int id;
        public String nombre;
        public String descripcion;
        public int actividad;
        public String fechaUltimaModificacion;
        public CategoriaAPI()
        {

        }
    }

    public static class GrupoAPI
    {
        public int id;
        public String nombre;
        public String descripcion;
        public String password;
        public int categoria;
        public boolean silenciado;
        public boolean publico;
        public String fechaUltimaModificacion;
        public GrupoAPI()
        {

        }
    }

    public static class EventoAPI
    {
        public int id;
        public String lugar;
        public String descripcion;
        public String fechaInicio;
        public String fechaFin;
        public String horaInicio;
        public String horaFin;
        public boolean esRecordatorio;
        public int grupo;
        public String fechaUltimaModificacion;
        public EventoAPI()
        {

        }
        public void print()
        {
//            System.out.println("ID "+id);
//            System.out.println("lugar "+lugar);
//            System.out.println("descripcion "+descripcion);
//            System.out.println("fechaInicio "+fechaInicio);
//            System.out.println("fechaFin "+fechaFin);
//            System.out.println("horaInicio "+horaInicio);
//            System.out.println("horaFin "+horaFin);
//            System.out.println("esRecordatorio "+esRecordatorio);
//            System.out.println("grupo "+grupo);
        }
    }

    public static class UsuarioAPI
    {
        public String fechaUltimaModificacion;
        public int id;
        public String email;
        public String password;
        public String nombre;
        public UsuarioAPI()
        {

        }
    }

    public static class CalendarioAPI
    {
        public int id;
        public int creador;
        public CalendarioAPI()
        {

        }
    }

    public static class CalendarioEventoAPI
    {
        public int calendario;
        public int evento;
        public String fechaUltimaModificacion;
        public CalendarioEventoAPI(){

        }
    }

    public static class ActividadUsuarioAPI
    {
        public String fechaUltimaModificacion;
        public int actividad;
        public int usuario;
        public int rolUsuario;
        public Boolean bloqueado;
        public ActividadUsuarioAPI()
        {

        }
    }

    public static class UsuarioGrupoAPI
    {
        public String fechaUltimaModificacion;
        public int usuario;
        public int grupo;
        public boolean suscrito;
        public boolean bloqueado;
        public UsuarioGrupoAPI()
        {

        }
    }

    public static class NotaAPI
    {
        String fechaUltimaModificacion;
        int id;
        String titulo;
        String texto;
        String fecha;
        String hora;
        boolean esPublica;
        int evento;
        int creador;
        public NotaAPI()
        {

        }
    }

    public static class NotificacionAPI
    {
        public String fechaUltimaNotificacion;
        public int id;
        public int grupo;
        public int creador;
        public String titulo;
        public String texto;
        public String fecha;
        public String hora;
        public NotificacionAPI()
        {

        }
    }

    private static BaseDatosLocal bdlocal;
    private static String url;
    private static Paquete paquete;
    public boolean bool;
    public int integer;
    public String string;
    public ArrayList<CalendarioEventoAPI> calendarioEventos;
    public ArrayList<Integer> integers;
    public ArrayList<UsuarioGrupoAPI> usuarioGrupos;
    public ArrayList<NotificacionAPI> notificaciones;

    public Conector()
    {

    }

    public Conector(BaseDatosLocal bdlocal, String url)
    {
        this.bdlocal = bdlocal;
        this.url = url;
        this.bool = false;
    }

    @Override
    protected Boolean doInBackground(Integer... ints) {

        //this.bdlocal = baseDatosLocals[0];
        switch (ints[0].intValue())
        {
            case Utilidades.OPCION_GET_NIVELESORGANIZATIVOS:
                this.getNivelesOrganizativos();
                break;
            case Utilidades.OPCION_GET_ACTIVIDADES:
                this.getActividades();
                break;
            case Utilidades.OPCION_GET_CATEGORIAS:
                this.getCategorias();
                break;
            case Utilidades.OPCION_GET_GRUPOS:
                this.getGrupos();
                break;
            case Utilidades.OPCION_GET_EVENTOS:
                this.getEventos();
                break;
            case Utilidades.OPCION_POST_USUARIO:
                this.setUsuario();
                break;
            case Utilidades.OPCION_POST_EVENTO:
                this.setEvento();
                break;
            case Utilidades.OPCION_DEL_EVENTO:
                this.eliminarEvento();
                break;
            case Utilidades.OPCION_PUT_EVENTO:
                this.modificarEvento();
                break;
            case Utilidades.OPCION_POST_LOGIN:
                this.login();
                break;
            case Utilidades.OPCION_GET_USUARIO_POR_EMAIL:
                this.getUsuarioPorEmail();
                break;
            case Utilidades.OPCION_GET_CALENDARIO_POR_USUARIO:
                this.getCalendarioPorUsuario();
                break;
            case Utilidades.OPCION_GET_LISTACALENDARIOEVENTO_POR_USUARIO:
                this.getCalendarioEventosPorUsuario();
                break;
            case Utilidades.OPCION_POST_ADDCALENDARIO:
                this.addCalendario();
                break;
            case Utilidades.OPCION_POST_ADDCALENDARIOEVENTO:
                this.addCalendarioEvento();
                break;
            case Utilidades.OPCION_GET_ROLESACTIVIDAD_POR_USUARIO:
                this.getActividadesModeradas();
                break;
            case Utilidades.OPCION_GET_GRUPOSSUSCRITOS_POR_USUARIO:
                this.getGruposSuscritos();
                break;
            case Utilidades.OPCION_GET_GRUPOSBLOQUEADOS_POR_USUARIO:
                this.getGruposBloqueados();
                break;
            case Utilidades.OPCION_SUSCRIBIR_USUARIO:
                this.suscribirUsuarioGrupo();
                break;
            case Utilidades.OPCION_DESUSCRIBIR_USUARIO:
                this.desuscribirUsuarioGrupo();
                break;
            case Utilidades.OPCION_GET_NOTASPERSONALES:
                this.getNotasPersonales();
                break;
            case Utilidades.OPCION_GET_NOTASPUBLICAS:
                this.getNotasPublicas();
                break;
            case Utilidades.OPCION_POST_NOTA:
                this.addNota();
                break;
            case Utilidades.OPCION_SINCRONIZAR_NIVELES:
                this.sincronizarNivelesOrganizativos();
                break;
            case Utilidades.OPCION_SINCRONIZAR_ACTIVIDADES:
                this.sincronizarActividades();
                break;
            case Utilidades.OPCION_SINCRONIZAR_CATEGORIAS:
                this.sincronizarCategorias();
                break;
            case Utilidades.OPCION_SINCRONIZAR_GRUPOS:
                this.sincronizarGrupos();
                break;
            case Utilidades.OPCION_SINCRONIZAR_EVENTOS:
                this.sincronizarEventos();
                break;
            case Utilidades.OPCION_SINCRONIZAR_NOTASPERSONALES:
                this.sincronizarNotasPersonales();
                break;
            case Utilidades.OPCION_SINCRONIZAR_NOTASPUBLICAS:
                this.sincronizarNotasPublicas();
                break;
            case Utilidades.OPCION_SINCRONIZAR_NOTIFICACIONES:
                this.sincronizarNotificaciones();
                break;
            case Utilidades.OPCION_SINCRONIZAR_CALENDARIOEVENTOS:
                this.sincronizarCalendarioEventos();
                break;
            case Utilidades.OPCION_POST_ADDNOTIFICACION:
                this.addNotificacion();
                break;
            case Utilidades.OPCION_GET_NOTIFICACIONES_PORGRUPO:
                this.getNotificacionesPorGrupo();
                break;

        }

        return null;
    }

    public void getRequestNivelesOrganizativos()
    {
        this.execute(Utilidades.OPCION_GET_NIVELESORGANIZATIVOS);
    }

    public void getRequestActividades()
    {
        this.execute(Utilidades.OPCION_GET_ACTIVIDADES);
    }

    public void getRequestCategorias()
    {
        this.execute(Utilidades.OPCION_GET_CATEGORIAS);
    }

    public void getRequestGrupos()
    {
        this.execute(Utilidades.OPCION_GET_GRUPOS);
    }

    public void getRequestEventos()
    {
        this.execute(Utilidades.OPCION_GET_EVENTOS);
    }

    public void postRequestAddUsuario(Paquete paquete) throws ExecutionException, InterruptedException {
        this.paquete=paquete;
        this.execute(Utilidades.OPCION_POST_USUARIO);
    }

    public void postRequestAddEvento(Paquete paquete)
    {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_POST_EVENTO);
    }

    public void deleteRequestEliminarEvento(Paquete paquete)
    {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_DEL_EVENTO);
    }

    public void putRequestModificarEvento(Paquete paquete)
    {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_PUT_EVENTO);
    }

    public void postRequestLogin(Paquete paquete)
    {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_POST_LOGIN);
    }

    public void getRequestGetUsuario(Paquete paquete)
    {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_GET_USUARIO_POR_EMAIL);
    }

    public void getRequestCalendarioPorUsuario(Paquete paquete)
    {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_GET_CALENDARIO_POR_USUARIO);
    }

    public void getRequestListaCalendarioEventoPorUsuario(Paquete paquete)
    {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_GET_LISTACALENDARIOEVENTO_POR_USUARIO);
    }

    public void postRequestAddCalendario(Paquete paquete)
    {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_POST_ADDCALENDARIO);
    }

    public void postRequestAddCalendarioEvento(Paquete paquete)
    {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_POST_ADDCALENDARIOEVENTO);
    }

    public void getRequestRolesActividadPorUsuario(Paquete paquete)
    {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_GET_ROLESACTIVIDAD_POR_USUARIO);
    }

    public void getRequestGruposSuscritosPorUsuario(Paquete paquete)
    {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_GET_GRUPOSSUSCRITOS_POR_USUARIO);
    }

    public void getRequestGruposBloqueadosPorUsuario(Paquete paquete)
    {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_GET_GRUPOSBLOQUEADOS_POR_USUARIO);
    }

    public void putRequestUsuarioSuscribirGrupo(Paquete paquete)
    {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_SUSCRIBIR_USUARIO);
    }

    public void putRequestUsuarioDesuscribirGrupo(Paquete paquete)
    {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_DESUSCRIBIR_USUARIO);
    }

    public void getRequestNotasPersonales(Paquete paquete)
    {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_GET_NOTASPERSONALES);
    }

    public void getRequestNotasPublicas(Paquete paquete)
    {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_GET_NOTASPUBLICAS);
    }

    public void postRequestAddNota(Paquete paquete)
    {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_POST_NOTA);
    }

    public void requestSincronizarNivelesOrganizativos(Paquete paquete) {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_SINCRONIZAR_NIVELES);
    }

    public void requestSincronizarActividades(Paquete paquete) {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_SINCRONIZAR_ACTIVIDADES);
    }

    public void requestSincronizarCategorias(Paquete paquete) {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_SINCRONIZAR_CATEGORIAS);
    }

    public void requestSincronizarGrupos(Paquete paquete) {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_SINCRONIZAR_GRUPOS);
    }

    public void requestSincronizarEventos(Paquete paquete) {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_SINCRONIZAR_EVENTOS);
    }

    public void requestSincronizarNotasPersonales(Paquete paquete) {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_SINCRONIZAR_NOTASPERSONALES);
    }

    public void requestSincronizarNotasPublicas(Paquete paquete) {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_SINCRONIZAR_NOTASPUBLICAS);
    }

    public void requestSincronizarNotificaciones(Paquete paquete) {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_SINCRONIZAR_NOTIFICACIONES);
    }

    public void requestSincronizarCalendarioEventos(Paquete paquete) {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_SINCRONIZAR_CALENDARIOEVENTOS);
    }

    public void postRequestAddNotificacion(Paquete paquete) {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_POST_ADDNOTIFICACION);
    }

    public void getRequestNotificacionesPorGrupo(Paquete paquete) {
        this.paquete = paquete;
        this.execute(Utilidades.OPCION_GET_NOTIFICACIONES_PORGRUPO);
    }

    private Boolean getNivelesOrganizativos()
    {
        ArrayList<NivelOrganizativoAPI> niveles = new ArrayList<>();
        System.out.println("VAMOS A CONECTARNOS NIV-ORG");

        try {
            //URL url = new URL("https://localhost:8080/api/niveles/");//your url i.e fetch data from .
            //URL url = new URL("http://10.0.2.2:8080/api/niveles/");
            URL url = new URL(this.url+Utilidades.GET_NIVELESORGANIZATIVOS);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<NivelOrganizativoAPI>>(){}.getType();
                niveles = gson.fromJson(output, listType);

                String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());
                String fechaUltimaModificacion;
                for (NivelOrganizativoAPI nivel : niveles)
                {
                    int oficialidad = 0;
                    if(nivel.esOficial)
                        oficialidad = 1;

                    if (nivel.fechaUltimaModificacion == null)
                    {
                        fechaUltimaModificacion = fechaActual;
                    }
                    else
                    {
                        fechaUltimaModificacion = nivel.fechaUltimaModificacion;
                    }

                    bdlocal.setNivelOrganizativo(nivel.id, nivel.nombre, nivel.descripcion, nivel.tipo, oficialidad, nivel.nivelPadre,fechaUltimaModificacion);
                }
            }

            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }

        return Boolean.TRUE;
    }

    private Boolean getActividades()
    {
        ArrayList<ActividadAPI> actividades = new ArrayList<>();
        System.out.println("VAMOS A CONECTARNOS ACT");

        try {
            //URL url = new URL("https://localhost:8080/api/niveles/");//your url i.e fetch data from .
            URL url = new URL(this.url+Utilidades.GET_ACTIVIDADES);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());
            String fechaUltimaModificacion;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<ActividadAPI>>(){}.getType();
                actividades = gson.fromJson(output, listType);

                for (ActividadAPI actividad : actividades)
                {
                    if (actividad.fechaUltimaModificacion == null)
                    {
                        fechaUltimaModificacion = fechaActual;
                    }
                    else
                    {
                        fechaUltimaModificacion = actividad.fechaUltimaModificacion;
                    }
                    bdlocal.setActividad(actividad.id, actividad.nombre, actividad.descripcion, actividad.nivelOrganizativo, fechaUltimaModificacion);
                }
            }

            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }

        return Boolean.TRUE;
    }

    private Boolean getCategorias()
    {
        ArrayList<CategoriaAPI> categorias = new ArrayList<>();
        System.out.println("VAMOS A CONECTARNOS CAT");

        try {
            //URL url = new URL("https://localhost:8080/api/niveles/");//your url i.e fetch data from .
            URL url = new URL(this.url+Utilidades.GET_CATEGORIAS);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<CategoriaAPI>>(){}.getType();
                categorias = gson.fromJson(output, listType);

                String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());
                String fechaUltimaModificacion;

                for (CategoriaAPI categoria : categorias)
                {
                    if (categoria.fechaUltimaModificacion == null)
                    {
                        fechaUltimaModificacion = fechaActual;
                    }
                    else
                    {
                        fechaUltimaModificacion = categoria.fechaUltimaModificacion;
                    }
                    bdlocal.setCategoria(categoria.id, categoria.nombre, categoria.descripcion, categoria.actividad, fechaUltimaModificacion);
                }
            }

            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }

        return Boolean.TRUE;
    }

    private Boolean getGrupos()
    {
        ArrayList<GrupoAPI> grupos = new ArrayList<>();
        System.out.println("VAMOS A CONECTARNOS GRUPOS");

        try {
            //URL url = new URL("https://localhost:8080/api/niveles/");//your url i.e fetch data from .
            URL url = new URL(this.url+Utilidades.GET_GRUPOS);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<GrupoAPI>>(){}.getType();
                grupos = gson.fromJson(output, listType);
                int silenciado;
                int publico;
                String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());
                String fechaUltimaModificacion;
                for (GrupoAPI grupo : grupos)
                {
                    silenciado = grupo.silenciado ? 1 : 0;
                    publico = grupo.publico ? 1 : 0;
                    if (grupo.fechaUltimaModificacion == null)
                    {
                        fechaUltimaModificacion = fechaActual;
                    }
                    else
                    {
                        fechaUltimaModificacion = grupo.fechaUltimaModificacion;
                    }
                    bdlocal.setGrupo(grupo.id, grupo.nombre,grupo.descripcion,grupo.categoria,grupo.password,silenciado,publico, fechaUltimaModificacion);
                }
            }

            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }

        return Boolean.TRUE;
    }

    private Boolean getEventos()
    {
        ArrayList<EventoAPI> eventos = new ArrayList<>();
        System.out.println("VAMOS A CONECTARNOS EVENTOS");

        try {
            //URL url = new URL("https://localhost:8080/api/niveles/");//your url i.e fetch data from .
            URL url = new URL(this.url+Utilidades.GET_EVENTOS);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<EventoAPI>>(){}.getType();
                eventos = gson.fromJson(output, listType);
                int esRecordatorio;
                String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());
                String fechaUltimaModificacion;
                for (EventoAPI evento : eventos)
                {
                    if (evento.fechaUltimaModificacion == null)
                    {
                        fechaUltimaModificacion = fechaActual;
                    }
                    else
                    {
                        fechaUltimaModificacion = evento.fechaUltimaModificacion;
                    }
                    esRecordatorio = evento.esRecordatorio ? 1 : 0;
                    bdlocal.setEvento(evento.id,evento.grupo,evento.descripcion,evento.lugar,evento.fechaInicio,evento.fechaFin,
                            evento.horaInicio,evento.horaFin,esRecordatorio, fechaUltimaModificacion);
                }
            }

            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }

        return Boolean.TRUE;
    }

    private Boolean setUsuario()
    {
        Boolean usuarioRegistrado = Boolean.TRUE;
        UsuarioAPI usuario = new UsuarioAPI();
        try {
            URL url = new URL(this.url+Utilidades.POST_USUARIO);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            conn.setDoOutput(true);
            try(OutputStream os = conn.getOutputStream()) {
                byte[] input = paquete.jsonString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            if (conn.getResponseCode() == 417)
            {
                usuarioRegistrado = Boolean.FALSE;
            }
            else
            {
                if (conn.getResponseCode() != 201) {
                    usuarioRegistrado = Boolean.FALSE;
                    throw new RuntimeException("Failed : HTTP Error code : "
                            + conn.getResponseCode());
                }
                usuarioRegistrado = Boolean.TRUE;
                InputStreamReader in = new InputStreamReader(conn.getInputStream());
                BufferedReader br = new BufferedReader(in);

                String output;
                while ((output = br.readLine()) != null) {
                    System.out.println(output);
                    Gson gson = new Gson();
                    Type listType = new TypeToken<UsuarioAPI>(){}.getType();
                    usuario = gson.fromJson(output, listType);
                    this.integer = usuario.id;
                }
                br.close();
            }

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }

        this.bool = usuarioRegistrado.booleanValue();
        return usuarioRegistrado;
    }

    private void setEvento()
    {
        try {
            URL url = new URL(this.url + Utilidades.GET_EVENTOS);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            conn.setDoOutput(true);
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = paquete.jsonString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            if (conn.getResponseCode() != 201) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }

            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            EventoAPI evento;
            while ((output = br.readLine()) != null) {

                System.out.println(output);
                //AÑADIR EVENTO A LA BDLOCAL
                Gson gson = new Gson();
                Type listType = new TypeToken<EventoAPI>(){}.getType();
                evento = gson.fromJson(output, listType);
                int esRecordatorio;
                String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());
                String fechaUltimaModificacion;

                if (evento.fechaUltimaModificacion == null)
                {
                    fechaUltimaModificacion = fechaActual;
                }
                else
                {
                    fechaUltimaModificacion = evento.fechaUltimaModificacion;
                }
                esRecordatorio = evento.esRecordatorio ? 1 : 0;
                bdlocal.setEvento(evento.id,evento.grupo,evento.descripcion,evento.lugar,evento.fechaInicio,evento.fechaFin,
                        evento.horaInicio,evento.horaFin,esRecordatorio, fechaUltimaModificacion);

                this.integer = evento.id;
            }
            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    private void eliminarEvento()
    {
        try {
            URL url = new URL(this.url + Utilidades.GET_EVENTOS+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("DELETE");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded" );
            conn.setDoOutput(true);
            conn.connect();

            if (conn.getResponseCode() != 204) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }

            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            //ELIMINAR EVENTO DE LA BDLOCAL
            bdlocal.deleteEvento(Integer.parseInt(this.paquete.parametro));
            while ((output = br.readLine()) != null) {
                System.out.println(output);
            }
            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    private void modificarEvento()
    {
        try {
            URL url = new URL(this.url + Utilidades.GET_EVENTOS+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("PUT");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            //conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded" );
            conn.setDoOutput(true);
            conn.connect();

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = paquete.jsonString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }


            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }

            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            EventoAPI evento;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                //MODIFICAR EVENTO EN LA BDLOCAL
                Gson gson = new Gson();
                Type listType = new TypeToken<EventoAPI>(){}.getType();
                evento = gson.fromJson(output, listType);
                int esRecordatorio;

                esRecordatorio = evento.esRecordatorio ? 1 : 0;
                bdlocal.updateEvento(evento.id,evento.grupo,evento.descripcion,evento.lugar,evento.fechaInicio,evento.fechaFin,
                        evento.horaInicio,evento.horaFin,esRecordatorio);
            }
            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    private void login()
    {
        Boolean usuarioRegistrado = Boolean.TRUE;
        try {
            this.integer = 0;
            URL url = new URL(this.url+Utilidades.LOGIN);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            conn.setDoOutput(true);
            try(OutputStream os = conn.getOutputStream()) {
                byte[] input = paquete.jsonString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            int responseCode = conn.getResponseCode();
            this.integer = responseCode;

            /*
            credenciales erroneas da error 401
            y bloqueado 423
            login correcto es 200
            otros errores != 200
             */

            if(responseCode == 200)
            {
                //login correcto

                //set usuario en bdlocal

                //set calendario
            }

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    private Boolean getUsuarioPorEmail()
    {
        UsuarioAPI usuario = new UsuarioAPI();

        try {
            //URL url = new URL("https://localhost:8080/api/niveles/");//your url i.e fetch data from .
            URL url = new URL(this.url+Utilidades.USUARIO_POR_EMAIL+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<UsuarioAPI>(){}.getType();
                usuario = gson.fromJson(output, listType);

                this.string = usuario.nombre;
                this.integer = usuario.id;
            }

            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }

        return Boolean.TRUE;
    }

    private Boolean getCalendarioPorUsuario()
    {
        ArrayList<CalendarioAPI> calendarios = new ArrayList<CalendarioAPI>();

        try {
            //URL url = new URL("https://localhost:8080/api/niveles/");//your url i.e fetch data from .
            URL url = new URL(this.url+Utilidades.CALENDARIOS_POR_USUARIO+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<CalendarioAPI>>(){}.getType();
                calendarios = gson.fromJson(output, listType);

                CalendarioAPI calendario=calendarios.get(0);

                System.out.println("Hemos tenido: "+calendario.id);
                this.integer = calendario.id;
            }

            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }

        return Boolean.TRUE;
    }

    private Boolean getCalendarioEventosPorUsuario()
    {
        ArrayList<CalendarioEventoAPI> calendarioEventos = new ArrayList<CalendarioEventoAPI>();

        try {
            //URL url = new URL("https://localhost:8080/api/niveles/");//your url i.e fetch data from .
            URL url = new URL(this.url+Utilidades.CALENDARIOEVENTOS_POR_USUARIO+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<CalendarioEventoAPI>>(){}.getType();
                calendarioEventos = gson.fromJson(output, listType);

                this.calendarioEventos = calendarioEventos;
                //Meter CalendarioEventos en la bd local
/*
                ArrayList<Integer> eventosID = new ArrayList<>();

                for (CalendarioEventoAPI calendarioEvento : calendarioEventos)
                {
                    eventosID.add(calendarioEvento.evento);
                }
                //bdlocal.setCalendarioEvento(calendarioEvento.calendario, calendarioEvento.evento);
                bdlocal.guardarCalendarioUsuario(eventosID,calendarioEventos.get(0).calendario);


 */
            }

            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }

        return Boolean.TRUE;
    }

    private void addCalendario()
    {
        try {
            URL url = new URL(this.url + Utilidades.CALENDARIOS);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            conn.setDoOutput(true);
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = paquete.jsonString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            if (conn.getResponseCode() != 201) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }

            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            EventoAPI evento;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                /*
                Gson gson = new Gson();
                Type listType = new TypeToken<EventoAPI>(){}.getType();
                evento = gson.fromJson(output, listType);
                int esRecordatorio;

                esRecordatorio = evento.esRecordatorio ? 1 : 0;
                bdlocal.setEvento(evento.id,evento.grupo,evento.descripcion,evento.lugar,evento.fechaInicio,evento.fechaFin,
                        evento.horaInicio,evento.horaFin,esRecordatorio);
                 */
            }
            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    private void addCalendarioEvento()
    {
        try {
            URL url = new URL(this.url + Utilidades.CALENDARIOS+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("PUT");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            //conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded" );
            conn.setDoOutput(true);
            conn.connect();
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = this.paquete.jsonString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            EventoAPI evento;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                /*
                Gson gson = new Gson();
                Type listType = new TypeToken<EventoAPI>(){}.getType();
                evento = gson.fromJson(output, listType);
                int esRecordatorio;

                esRecordatorio = evento.esRecordatorio ? 1 : 0;
                bdlocal.updateEvento(evento.id,evento.grupo,evento.descripcion,evento.lugar,evento.fechaInicio,evento.fechaFin,
                        evento.horaInicio,evento.horaFin,esRecordatorio);

                 */
            }
            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    private void getActividadesModeradas()
    {
        ArrayList<ActividadUsuarioAPI> listaActividadUsuario = new ArrayList<ActividadUsuarioAPI>();

        try {
            URL url = new URL(this.url+Utilidades.POST_USUARIO+this.paquete.parametro+"/"+Utilidades.ACTIVIDADES_ROLES);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<ActividadUsuarioAPI>>(){}.getType();
                listaActividadUsuario = gson.fromJson(output, listType);
                this.integers = new ArrayList<Integer>();
                for(ActividadUsuarioAPI actividadUsuario : listaActividadUsuario)
                {
                    if(actividadUsuario.rolUsuario == 2)
                    {
                        this.integers.add(actividadUsuario.actividad);
                    }
                }
            }
            br.close();
            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    private void getGruposSuscritos()
    {
        ArrayList<UsuarioGrupoAPI> listaUsuarioGrupo = new ArrayList<UsuarioGrupoAPI>();

        try {
            URL url = new URL(this.url+Utilidades.POST_USUARIO+this.paquete.parametro+"/"+Utilidades.GRUPOS_SUSCRITO);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<UsuarioGrupoAPI>>(){}.getType();
                listaUsuarioGrupo = gson.fromJson(output, listType);
                this.usuarioGrupos = listaUsuarioGrupo;
            }
            br.close();
            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    private void getGruposBloqueados()
    {
        ArrayList<UsuarioGrupoAPI> listaUsuarioGrupo = new ArrayList<UsuarioGrupoAPI>();

        try {
            URL url = new URL(this.url+Utilidades.POST_USUARIO+this.paquete.parametro+"/"+Utilidades.GRUPOS_BLOQUEADO);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<UsuarioGrupoAPI>>(){}.getType();
                listaUsuarioGrupo = gson.fromJson(output, listType);
                this.usuarioGrupos = listaUsuarioGrupo;
            }
            br.close();
            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    private void suscribirUsuarioGrupo()
    {
        try {
            URL url = new URL(this.url+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("PUT");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            //conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded" );
            conn.setDoOutput(true);
            conn.connect();
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = this.paquete.jsonString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            this.integer = conn.getResponseCode();
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
            }
            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    private void desuscribirUsuarioGrupo()
    {
        try {
            URL url = new URL(this.url+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("PUT");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            //conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded" );
            conn.setDoOutput(true);
            conn.connect();
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = this.paquete.jsonString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            this.integer = conn.getResponseCode();
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
            }
            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    private void getNotasPersonales()
    {
        ArrayList<NotaAPI> notas = new ArrayList<NotaAPI>();

        try {
            URL url = new URL(this.url+Utilidades.NOTAS_USUARIO+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());
            String fechaUltimaModificacion;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<NotaAPI>>(){}.getType();
                notas = gson.fromJson(output, listType);
                int esPublica;

                for (NotaAPI nota : notas)
                {
                    if (nota.fechaUltimaModificacion == null)
                    {
                        fechaUltimaModificacion = fechaActual;
                    }
                    else
                    {
                        fechaUltimaModificacion = nota.fechaUltimaModificacion;
                    }
                    esPublica = nota.esPublica ? 1 : 0;
                    bdlocal.setNota(nota.id,nota.titulo,nota.texto,nota.fecha,nota.hora,esPublica,nota.creador,fechaUltimaModificacion, nota.evento);
                }
            }
            br.close();
            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    private void getNotasPublicas()
    {
        ArrayList<NotaAPI> notas = new ArrayList<NotaAPI>();

        try {
            URL url = new URL(this.url+Utilidades.NOTAS_USUARIO+this.paquete.parametro+"/suscrito");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());
                String fechaUltimaModificacion;
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<NotaAPI>>(){}.getType();
                notas = gson.fromJson(output, listType);
                int esPublica;

                for (NotaAPI nota : notas)
                {
                    if (nota.fechaUltimaModificacion == null)
                    {
                        fechaUltimaModificacion = fechaActual;
                    }
                    else
                    {
                        fechaUltimaModificacion = nota.fechaUltimaModificacion;
                    }
                    esPublica = nota.esPublica ? 1 : 0;
                    bdlocal.setNota(nota.id,nota.titulo,nota.texto,nota.fecha,nota.hora,esPublica,nota.creador,fechaUltimaModificacion, nota.evento);
                }
            }
            br.close();
            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    private void addNota()
    {
        try {
            URL url = new URL(this.url + Utilidades.NOTAS);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            conn.setDoOutput(true);
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = paquete.jsonString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            if (conn.getResponseCode() != 201) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }

            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            NotaAPI nota;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                //AÑADIR NOTA A LA BDLOCAL
                Gson gson = new Gson();
                Type listType = new TypeToken<NotaAPI>(){}.getType();
                nota = gson.fromJson(output, listType);
                int esPublica;

                esPublica = nota.esPublica ? 1 : 0;
                bdlocal.setNota(nota.id,nota.titulo,nota.texto,nota.fecha, nota.hora,esPublica, nota.creador, nota.fechaUltimaModificacion, nota.evento);
                this.integer = nota.id;
            }
            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    private void sincronizarCalendarioEventos() {
        ArrayList<CalendarioEventoAPI> calendarioEventos = new ArrayList<CalendarioEventoAPI>();

        try {
            //URL url = new URL("https://localhost:8080/api/niveles/");//your url i.e fetch data from .
            URL url = new URL(this.url+Utilidades.CALENDARIOEVENTOS_POR_USUARIO+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<CalendarioEventoAPI>>(){}.getType();
                calendarioEventos = gson.fromJson(output, listType);

                this.calendarioEventos = calendarioEventos;
                //Meter CalendarioEventos en la bd local
/*
                ArrayList<Integer> eventosID = new ArrayList<>();

                for (CalendarioEventoAPI calendarioEvento : calendarioEventos)
                {
                    eventosID.add(calendarioEvento.evento);
                }
                //bdlocal.setCalendarioEvento(calendarioEvento.calendario, calendarioEvento.evento);
                bdlocal.guardarCalendarioUsuario(eventosID,calendarioEventos.get(0).calendario);


 */
            }

            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }

    }

    private void sincronizarNotificaciones() {
    }

    private void sincronizarNotasPublicas() {
        ArrayList<NotaAPI> notas = new ArrayList<NotaAPI>();

        try {
            URL url = new URL(this.url+Utilidades.NOTAS_USUARIO+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());
                String fechaUltimaModificacion;
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<NotaAPI>>(){}.getType();
                notas = gson.fromJson(output, listType);
                int esPublica;

                for (NotaAPI nota : notas)
                {
                    if (nota.fechaUltimaModificacion == null)
                    {
                        fechaUltimaModificacion = fechaActual;
                    }
                    else
                    {
                        fechaUltimaModificacion = nota.fechaUltimaModificacion;
                    }
                    esPublica = nota.esPublica ? 1 : 0;
                    bdlocal.setNota(nota.id,nota.titulo,nota.texto,nota.fecha,nota.hora,esPublica,nota.creador,fechaUltimaModificacion, nota.evento);
                }
            }
            br.close();
            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    private void sincronizarNotasPersonales() {
        ArrayList<NotaAPI> notas = new ArrayList<NotaAPI>();

        try {
            URL url = new URL(this.url+Utilidades.NOTAS_USUARIO+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());
            String fechaUltimaModificacion;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<NotaAPI>>(){}.getType();
                notas = gson.fromJson(output, listType);
                int esPublica;

                for (NotaAPI nota : notas)
                {
                    if (nota.fechaUltimaModificacion == null)
                    {
                        fechaUltimaModificacion = fechaActual;
                    }
                    else
                    {
                        fechaUltimaModificacion = nota.fechaUltimaModificacion;
                    }
                    esPublica = nota.esPublica ? 1 : 0;
                    bdlocal.setNota(nota.id,nota.titulo,nota.texto,nota.fecha,nota.hora,esPublica,nota.creador,fechaUltimaModificacion, nota.evento);
                }
            }
            br.close();
            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    private void sincronizarEventos() {
        ArrayList<EventoAPI> eventos = new ArrayList<>();
        System.out.println("VAMOS A CONECTARNOS EVENTOS");

        try {
            //URL url = new URL("https://localhost:8080/api/niveles/");//your url i.e fetch data from .
            URL url = new URL(this.url+Utilidades.GET_EVENTOS+Utilidades.FECHAULTIMAMODIFICACION+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<EventoAPI>>(){}.getType();
                eventos = gson.fromJson(output, listType);
                int esRecordatorio;
                String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());
                String fechaUltimaModificacion;
                for (EventoAPI evento : eventos)
                {
                    if (evento.fechaUltimaModificacion == null)
                    {
                        fechaUltimaModificacion = fechaActual;
                    }
                    else
                    {
                        fechaUltimaModificacion = evento.fechaUltimaModificacion;
                    }
                    esRecordatorio = evento.esRecordatorio ? 1 : 0;
                    bdlocal.setEvento(evento.id,evento.grupo,evento.descripcion,evento.lugar,evento.fechaInicio,evento.fechaFin,
                            evento.horaInicio,evento.horaFin,esRecordatorio, fechaUltimaModificacion);
                }
            }

            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }

    }

    private void sincronizarGrupos() {
        ArrayList<GrupoAPI> grupos = new ArrayList<>();
        System.out.println("VAMOS A CONECTARNOS GRUPOS");

        try {
            //URL url = new URL("https://localhost:8080/api/niveles/");//your url i.e fetch data from .
            URL url = new URL(this.url+Utilidades.GET_GRUPOS+Utilidades.FECHAULTIMAMODIFICACION+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<GrupoAPI>>(){}.getType();
                grupos = gson.fromJson(output, listType);
                int silenciado;
                int publico;
                String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());
                String fechaUltimaModificacion;
                for (GrupoAPI grupo : grupos)
                {
                    silenciado = grupo.silenciado ? 1 : 0;
                    publico = grupo.publico ? 1 : 0;
                    if (grupo.fechaUltimaModificacion == null)
                    {
                        fechaUltimaModificacion = fechaActual;
                    }
                    else
                    {
                        fechaUltimaModificacion = grupo.fechaUltimaModificacion;
                    }
                    bdlocal.setGrupo(grupo.id, grupo.nombre,grupo.descripcion,grupo.categoria,grupo.password,silenciado,publico, fechaUltimaModificacion);
                }
            }

            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }

    }

    private void sincronizarCategorias() {
        ArrayList<CategoriaAPI> categorias = new ArrayList<>();
        System.out.println("VAMOS A CONECTARNOS CAT");

        try {
            //URL url = new URL("https://localhost:8080/api/niveles/");//your url i.e fetch data from .
            URL url = new URL(this.url+Utilidades.GET_CATEGORIAS+Utilidades.FECHAULTIMAMODIFICACION+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<CategoriaAPI>>(){}.getType();
                categorias = gson.fromJson(output, listType);

                String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());
                String fechaUltimaModificacion;

                for (CategoriaAPI categoria : categorias)
                {
                    if (categoria.fechaUltimaModificacion == null)
                    {
                        fechaUltimaModificacion = fechaActual;
                    }
                    else
                    {
                        fechaUltimaModificacion = categoria.fechaUltimaModificacion;
                    }
                    bdlocal.setCategoria(categoria.id, categoria.nombre, categoria.descripcion, categoria.actividad, fechaUltimaModificacion);
                }
            }

            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }

    }

    private void sincronizarActividades() {
        ArrayList<ActividadAPI> actividades = new ArrayList<>();
        System.out.println("VAMOS A CONECTARNOS ACT");

        try {
            URL url = new URL(this.url+Utilidades.GET_ACTIVIDADES+Utilidades.FECHAULTIMAMODIFICACION+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());
            String fechaUltimaModificacion;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<ActividadAPI>>(){}.getType();
                actividades = gson.fromJson(output, listType);

                for (ActividadAPI actividad : actividades)
                {
                    if (actividad.fechaUltimaModificacion == null)
                    {
                        fechaUltimaModificacion = fechaActual;
                    }
                    else
                    {
                        fechaUltimaModificacion = actividad.fechaUltimaModificacion;
                    }
                    bdlocal.setActividad(actividad.id, actividad.nombre, actividad.descripcion, actividad.nivelOrganizativo, fechaUltimaModificacion);
                }
            }

            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    private void sincronizarNivelesOrganizativos()
    {
        ArrayList<NivelOrganizativoAPI> niveles = new ArrayList<>();
        System.out.println("VAMOS A SINCRONIZAR NIV-ORG");

        try {
            //URL url = new URL("https://localhost:8080/api/niveles/");//your url i.e fetch data from .
            //URL url = new URL("http://10.0.2.2:8080/api/niveles/");
            URL url = new URL(this.url+Utilidades.GET_NIVELESORGANIZATIVOS+Utilidades.FECHAULTIMAMODIFICACION+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<NivelOrganizativoAPI>>(){}.getType();
                niveles = gson.fromJson(output, listType);

                String fechaActual = new SimpleDateFormat(Utilidades.FORMATO_FECHAACTUALIZACION).format(Calendar.getInstance().getTime());
                String fechaUltimaModificacion;
                for (NivelOrganizativoAPI nivel : niveles)
                {
                    int oficialidad = 0;
                    if(nivel.esOficial)
                        oficialidad = 1;
                    if (nivel.fechaUltimaModificacion == null)
                    {
                        fechaUltimaModificacion = fechaActual;
                    }
                    else
                    {
                        fechaUltimaModificacion = nivel.fechaUltimaModificacion;
                    }

                    bdlocal.setNivelOrganizativo(nivel.id, nivel.nombre, nivel.descripcion, nivel.tipo, oficialidad, nivel.nivelPadre,fechaUltimaModificacion);
                }
            }

            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }

    }

    private void addNotificacion()
    {
        try {
            URL url = new URL(this.url + Utilidades.NOTIFICACIONES);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");
            conn.setDoOutput(true);
            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = paquete.jsonString.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            if (conn.getResponseCode() != 201) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }

            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            NotaAPI nota;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
            }
            br.close();

            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }

    public void getNotificacionesPorGrupo()
    {
        ArrayList<NotificacionAPI> notificaciones = new ArrayList<NotificacionAPI>();

        try {
            URL url = new URL(this.url+Utilidades.NOTIFICACIONES+Utilidades.GET_GRUPOS+this.paquete.parametro);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP Error code : "
                        + conn.getResponseCode());
            }
            InputStreamReader in = new InputStreamReader(conn.getInputStream());
            BufferedReader br = new BufferedReader(in);

            String output;
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<NotificacionAPI>>(){}.getType();
                notificaciones = gson.fromJson(output, listType);

                this.notificaciones = notificaciones;
            }

            br.close();
            conn.disconnect();
        } catch (Exception e) {
            System.out.println("Exception in NetClientGet:- " + e);
        }
    }


    protected void onProgressUpdate(Integer... progress) {

    }

    protected void onPostExecute(Long result) {

    }

}
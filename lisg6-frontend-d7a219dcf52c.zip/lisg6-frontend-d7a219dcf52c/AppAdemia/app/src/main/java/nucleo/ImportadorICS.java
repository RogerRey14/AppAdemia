package nucleo;

import java.io.File;

public class ImportadorICS implements Importador
{

    public void importar(File archivo)
    {

    }
}
package nucleo;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import lis.main.appademia.AppAdemia;

public class ExportadorVistaPDF implements ExportadorVista
{

    public FileOutputStream exportar(String nombre, File extern, View view)
    {
        PdfDocument document = new PdfDocument();

        // crate a page description
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(view.getWidth(), view.getHeight(), 1).create();

        PdfDocument.Page page = document.startPage(pageInfo);
        Paint paint = new Paint();
        paint.setColor(Color.WHITE);

        Canvas canvas = page.getCanvas();
        canvas.drawBitmap(loadBitmapFromView(view), 10, 10, null);


        document.finishPage(page);

        try {
            document.writeTo(new FileOutputStream(new File(extern, (nombre + ".pdf"))));
        } catch (IOException e){
            e.printStackTrace();
        }

		return null;

    }

    public static Bitmap loadBitmapFromView(View v) {
        Bitmap b = Bitmap.createBitmap(v.getWidth()+1, v.getHeight()+1, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        v.draw(c);
        return b;
    }
}
package nucleo;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.ArrayList;
import java.util.Random;

public class Grupo
{
    private String ID;
    private String nombreGrupo;
    private String descripcion;
    private String contrasena;
    private Boolean silenciado;
    private Boolean publico;
    private PropertyChangeSupport support;

    private ArrayList<Usuario> usuariosSuscritos; //Usuario[] usuariosSuscritos;
    private ArrayList<Usuario> usuariosBloqueados; //Usuario[] usuariosBloqueados;
    private ArrayList<Notificacion> notificaciones;  //private Notificacion[] notificaciones;
    private ArrayList<Evento> eventos; //Evento[] eventos;

    public Grupo()
    {
    	this.support = new PropertyChangeSupport(this);
    	
    	this.setUsuariosBloqueados(new ArrayList<Usuario>());
    	this.setUsuariosSuscritos(new ArrayList<Usuario>());
    	this.notificaciones = new ArrayList<Notificacion>();
    	this.setEventos(new ArrayList<Evento>());
    }

//    public void print(String indentacion)
//	{
//		System.out.println(indentacion+"Es Grupo");
//		System.out.println(indentacion+"ID: "+ID);
//		System.out.println(indentacion+"Nombre: "+nombreGrupo);
//		System.out.println(indentacion+"Descripcion: "+descripcion);
//		System.out.println(indentacion+"Contraseña: "+contrasena);
//		System.out.println(indentacion+"Silenciado: "+silenciado);
//		System.out.println(indentacion+"Publico: "+publico);
//		System.out.println(indentacion+"Numero de eventos: "+eventos.size());
//		if(eventos.isEmpty()==false)
//		{
//			indentacion=indentacion+"--";
//			System.out.println(indentacion);
//			for(Evento evento : eventos)
//			{
//				evento.print(indentacion);
//				System.out.println(indentacion);
//			}
//		}
//	}

    public void addPropertyChangeListener(PropertyChangeListener listener)
    {
        support.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener)
    {
    	support.removePropertyChangeListener(listener);
    }

    public void enviarNotificacion(Notificacion notificacion)
    {
    	support.firePropertyChange("nueva_notificacion", notificacion, notificacion);
    }

    /*
    public void crearNotificacion(Usuario usuario, String titulo, String texto)
    {
    	Notificacion notificacion = new Notificacion(usuario, titulo, texto);
    	this.enviarNotificacion(notificacion);
    }*/
    
    public void anadirNotificacion(Notificacion notificacion)
    {
    	this.notificaciones.add(notificacion);
    }

    public void eliminarNotificacion(Notificacion notificacion)
    {
    	this.notificaciones.remove(notificacion);
    }
    
    public void vaciarNotificaciones()
    {
    	this.notificaciones = new ArrayList<Notificacion>();
    }
    
    public void addUsuarioSuscrito(Usuario usuario)
    {
    	this.usuariosSuscritos.add(usuario);
    }
    
    public void eliminarUsuarioSuscrito(Usuario usuario)
    {
    	this.usuariosSuscritos.remove(usuario);
    }
    
    public void vaciarUsuariosSuscritos()
    {
    	this.usuariosSuscritos = new ArrayList<Usuario>();
    }
    
    public Boolean esUsuarioSuscrito(Usuario usuario)
    {
    	return this.usuariosSuscritos.contains(usuario);
    }
    
    public void addUsuarioBloqueado(Usuario usuario)
    {
    	this.usuariosBloqueados.add(usuario);
    }
    
    public void eliminarUsuarioBloqueado(Usuario usuario)
    {
    	this.usuariosBloqueados.remove(usuario);
    }
    
    public void vaciarUsuariosBloqueados()
    {
    	this.usuariosBloqueados = new ArrayList<Usuario>();
    }
    
    public Boolean esUsuarioBloqueado(Usuario usuario)
    {
    	return this.usuariosBloqueados.contains(usuario);
    }
    
    public void addEvento(Evento evento)
    {
    	this.eventos.add(evento);
    }
    
    public void eliminarEvento(Evento evento)
    {
    	this.eventos.remove(evento);
    }
    
    public void vaciarEventos()
    {
    	this.eventos = new ArrayList<Evento>();
    }
    
    public Boolean esEvento(Evento evento)
    {
    	return this.eventos.contains(evento);
    }
    
    
    
    //Getters y setters
    
    public ArrayList<Notificacion> getNotificaciones() {
		return notificaciones;
	}

	public void setNotificaciones(ArrayList<Notificacion> notificaciones) {
		this.notificaciones = notificaciones;
	}
    
	public ArrayList<Usuario> getUsuariosSuscritos() {
		return usuariosSuscritos;
	}

	public void setUsuariosSuscritos(ArrayList<Usuario> usuariosSuscritos) {
		this.usuariosSuscritos = usuariosSuscritos;
	}

	public ArrayList<Usuario> getUsuariosBloqueados() {
		return usuariosBloqueados;
	}

	public void setUsuariosBloqueados(ArrayList<Usuario> usuariosBloqueados) {
		this.usuariosBloqueados = usuariosBloqueados;
	}

	public ArrayList<Evento> getEventos() {
		return eventos;
	}

	public void setEventos(ArrayList<Evento> eventos) {
		this.eventos = eventos;
	}

	public String getID() {
		return ID;
	}

	public void setID(String ID) {
		this.ID = ID;
	}

	public String getNombreGrupo() {
		return nombreGrupo;
	}

	public void setNombreGrupo(String nombreGrupo) {
		this.nombreGrupo = nombreGrupo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getContrasena() {
		return contrasena;
	}

	public void setContrasena(String contrasena) {
		this.contrasena = contrasena;
	}

	public Boolean getSilenciado() {
		return silenciado;
	}

	public void setSilenciado(Boolean silenciado) {
		this.silenciado = silenciado;
	}

	public Boolean getPublico() {
		return publico;
	}

	public void setPublico(Boolean publico) {
		this.publico = publico;
	}
}
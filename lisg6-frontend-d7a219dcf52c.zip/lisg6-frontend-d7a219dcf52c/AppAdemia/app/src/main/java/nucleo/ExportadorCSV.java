package nucleo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import lis.main.appademia.AppAdemia;
import lis.main.appademia.adapter.DatosEvento;

public class ExportadorCSV implements Exportador {
    @Override
    public FileOutputStream exportar(String nombre, File extern) {

        try {
            FileWriter file = new FileWriter(new File(extern, (nombre + ".csv")));
            file.append("Subject,Start Date,Start Time,End Date,End Time,Description,Location\n");
            String coma = ",";
            String salto = "\n";

            for (DatosEvento i : AppAdemia.getInstance().getDatosCalendario().getEventos()) {
                file.append(i.getNombreEvento());
                file.append(coma);
                file.append(formatoDia(i.getFechaInicio()));
                file.append(coma);
                file.append(formatoHora(i.getFechaInicio()));
                file.append(coma);
                file.append(formatoDia(i.getFechaFin()));
                file.append(coma);
                file.append(formatoHora(i.getFechaFin()));
                file.append(coma);
                file.append(i.getDescripcion());
                file.append(coma);
                file.append(i.getLugar());
                file.append(salto);
            }

            System.out.println(file.getEncoding());

            try {
                file.flush();
                file.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String formatoDia(Calendar c){
        SimpleDateFormat formatoDia = new SimpleDateFormat("MM/dd/yyyy");
        return formatoDia.format(c.getTime());
    }

    private String formatoHora(Calendar c){
        SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm:ss");
        return formatoHora.format(c.getTime());
    }
}
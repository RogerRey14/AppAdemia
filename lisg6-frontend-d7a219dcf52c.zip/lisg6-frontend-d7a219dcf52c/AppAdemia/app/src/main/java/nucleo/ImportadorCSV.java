package nucleo;

import java.io.File;

public class ImportadorCSV implements Importador
{

    public void importar(File archivo)
    {

    }
}
package nucleo;

import java.io.File;
import java.sql.Date;
import java.sql.Time;

public class RolModerador extends RolUsuario
{

    public void crearCategoria(Actividad actividad, String nombre, String descripcion)
    {

    }

    public void crearGrupo(Categoria categoria, String nombre, String descripcion, String contrasena, Boolean publico)
    {

    }
    
    public void crearEvento(Grupo grupo, String nombre, String lugar, Date fechaInicio, Date fechaFin, Time horaInicio, Time horaFin, Boolean esRecordatorio)
    {

    }

    public void asignarModerador(Grupo grupo, Usuario usuario)
    {

    }

    public void eliminarModerador(Grupo grupo, Usuario usuario)
    {

    }

    public void expulsarUsuario(Grupo grupo, Usuario usuario)
    {

    }

    public void bloquearUsuario(Grupo grupo, Usuario usuario)
    {

    }

    public void cerrarSesion()
    {

    }

    public void eliminarCuenta()
    {

    }

    public void unirseGrupo(String ID, String contrasena)
    {

    }
    
    public void crearNota(Evento evento, String titulo, String texto, Boolean esPublica, File[] ficheros)
    {

    }

    public void descargarNotificaciones()
    {

    }
}
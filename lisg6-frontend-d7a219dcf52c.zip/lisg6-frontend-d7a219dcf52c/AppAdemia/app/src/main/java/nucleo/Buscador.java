package nucleo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

public class Buscador
{
    //Clash en el Diagrama de Clases
    //private NivelOrganizativo[] nivelesOrganizativos;
    private Componente[] nivelesOrganizativos;
    //Clash en el Diagrama de Clases

    private Actividad[] actividades;
    private Categoria[] categorias;
    private Grupo[] grupos;

    ConexionSQLiteHelper conexion;

    public Buscador()
    {

    }

    public Buscador(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version)
    {
        conexion = new ConexionSQLiteHelper(context, "DB_prueba", null, 1);
    }

    public void crearTablas()
    {

    }
}
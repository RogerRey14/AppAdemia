package nucleo;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.File;
import java.sql.Date;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Nota implements Parcelable
{
    private String ID;
    private String titulo;
    private String texto;
    private Date fecha;
    private Time hora;
    private Boolean esPublica;
    //private File fichero;
    private int IDCreador;
    private int eventoID;

    public Nota(){

    }

    public Nota(String ID, String titulo, String texto, Date fecha, Time hora, int eventoID, boolean esPublica, int creador){
        this.ID = ID;
        this.titulo = titulo;
        this.texto = texto;
        this.fecha = fecha;
        this.hora = hora;
        this.eventoID = eventoID;
        this.esPublica = esPublica;
        this.IDCreador = creador;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public void setFecha(String fecha, String formato) throws ParseException {
        this.fecha = new Date(new SimpleDateFormat(formato).parse(fecha).getTime());
    }

    public Time getHora() {
        return hora;
    }

    public void setHora(Time hora) {
        this.hora = hora;
    }

    public void setHora(String hora) throws ParseException {
        this.hora = Time.valueOf(hora);
    }

    public Boolean getEsPublica() {
        return esPublica;
    }

    public void setEsPublica(Boolean esPublica) {
        this.esPublica = esPublica;
    }

    public int getIDCreador() {
        return IDCreador;
    }

    public void setIDCreador(int IDCreador) {
        this.IDCreador = IDCreador;
    }

    public int getEvento() {
        return eventoID;
    }

    public void setEvento(int evento) {
        this.eventoID = evento;
    }


    //PARCELABLE
    protected Nota(Parcel in) {

        this.ID = in.readString();
        this.titulo = in.readString();
        this.texto = in.readString();
        this.fecha = (Date) in.readSerializable();
        this.hora = (Time) in.readSerializable();
        this.esPublica = in.readInt() == 1;
        this.IDCreador = in.readInt();
        this.eventoID = in.readInt();
    }

    public static final Creator<Nota> CREATOR = new Creator<Nota>() {
        @Override
        public Nota createFromParcel(Parcel in) {
            return new Nota(in);
        }

        @Override
        public Nota[] newArray(int size) {
            return new Nota[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(ID);
        dest.writeString(titulo);
        dest.writeString(texto);
        dest.writeSerializable(fecha);
        dest.writeSerializable(hora);
        dest.writeInt((esPublica) ? 1 : 0);
        dest.writeInt(IDCreador);
        dest.writeInt(eventoID);
    }



}
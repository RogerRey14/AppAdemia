package nucleo;

public interface Vista
{
    //private ExportadorVista exportadorVista;

    public Calendario mostrar();
}
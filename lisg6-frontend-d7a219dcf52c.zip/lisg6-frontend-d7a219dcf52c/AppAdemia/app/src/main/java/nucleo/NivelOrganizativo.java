package nucleo;

import java.util.ArrayList;
import java.util.Random;

public class NivelOrganizativo implements Componente
{
    private ArrayList<Componente> hijos;

    private int nivel;
    private String tipo;
    private String nombre;
    private String descripcion;
    private int oficialidad;
    private String ID;

    public NivelOrganizativo()
    {
    	this.hijos = new ArrayList<Componente>();
    }

    @Override
    public void addComponente(Componente componente)
    {
    	hijos.add(componente);
    }

    public void eliminarComponente(Componente componente)
    {
    	hijos.remove(componente);
    }
    
    public void vaciarComponentes()
    {
    	this.hijos = new ArrayList<Componente>();
    }
    
    //getters y setters

    @Override
    public ArrayList<Componente> getHijos()
    {
    	return this.hijos;
    }
    
    public void setHijos(ArrayList<Componente> hijos)
    {
    	this.hijos = hijos;
    }
    
    public int getNivel()
    {
    	return this.nivel;
    }
    
    public void setNivel(int nivel)
    {
    	this.nivel = nivel;
    }
    
    public String getTipo()
    {
    	return this.tipo;
    }
    
    public void setTipo(String tipo)
    {
    	this.tipo = tipo;
    }
    
    public String getNombre()
    {
    	return this.nombre;
    }
    
    public void setNombre(String nombre)
    {
    	this.nombre = nombre;
    }
    
    public String getDescripcion()
    {
    	return this.descripcion;
    }
    
    public void setDescripcion(String descripcion)
    {
    	this.descripcion = descripcion;
    }
    
    public int getOficialidad()
    {
    	return this.oficialidad;
    }

    @Override
    public void print(String indentacion) {
//        System.out.println(indentacion+"Es NivelOrganizativo");
//        System.out.println(indentacion+"ID: " + ID);
//        System.out.println(indentacion+"Nombre: " + nombre);
//        System.out.println(indentacion+"Descripcion: " + descripcion);
//        System.out.println(indentacion+"Tipo: " + tipo);
//        System.out.println(indentacion+"Nivel: " + nivel);
//        System.out.println(indentacion+"Oficialidad: " + oficialidad);
//        System.out.println(indentacion+"Numero hijos: " + hijos.size());
        if(hijos.isEmpty()==false)
        {
            indentacion=indentacion+"--";
//            System.out.println(indentacion);
            for(Componente componente : hijos)
            {
                componente.print(indentacion);
//                System.out.println(indentacion);
            }
        }
    }

    public void setOficialidad(int oficialidad)
    {
    	this.oficialidad = oficialidad;
    }

    @Override
    public String getID()
    {
    	return this.ID;
    }


    public void setID(String ID)
    {
    	this.ID = ID;
    }

}
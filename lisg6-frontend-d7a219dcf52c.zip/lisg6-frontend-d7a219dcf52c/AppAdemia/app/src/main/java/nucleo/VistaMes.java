package nucleo;

public class VistaMes implements Vista
{
    public Calendario mostrar()
    {
    	return null;
    }
}
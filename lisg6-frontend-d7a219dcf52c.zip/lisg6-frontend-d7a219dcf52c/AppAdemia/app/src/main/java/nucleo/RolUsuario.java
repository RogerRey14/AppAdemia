package nucleo;

import java.io.File;
import java.sql.Date;
import java.sql.Time;

public class RolUsuario
{
    private String ID;

    public void anadirEventosActividad()
    {

    }

    public void anadirEventosExtraescolares()
    {

    }

    public Calendario crearCalendario(String nombre, String descripcion)
    {
    	return null;
    }

    public void modificarCalendario(Calendario calendario)
    {

    }

    public void eliminarEvento(Calendario calendario, Evento evento)
    {

    }


    public void crearNota(Evento evento, String titulo, String texto, Boolean esPublica, File[] ficheros)
    {

    }

    public void eliminarNota(Nota nota)
    {

    }

    public void modificarNota(Nota nota)
    {

    }

    public Evento getEventoEnCalendario(Calendario calendario)
    {
    	return null;
    }

    public void setEventoEnCalendario(Calendario calendario, Evento evento)
    {
    	
    }

    public Evento[] getEventosEnCalendario(Calendario calendario)
    {
    	return null;
    }

    public void setEventosEnCalendario(Calendario calendario, Evento[] eventos)
    {

    }

}
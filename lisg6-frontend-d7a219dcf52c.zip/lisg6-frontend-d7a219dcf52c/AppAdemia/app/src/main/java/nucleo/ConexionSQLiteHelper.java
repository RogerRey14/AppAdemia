package nucleo;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class ConexionSQLiteHelper extends SQLiteOpenHelper
{

    public ConexionSQLiteHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL(Utilidades.CREAR_TABLA_NIVELORGANIZATIVO);
        db.execSQL(Utilidades.CREAR_TABLA_ACTIVIDAD);
        db.execSQL(Utilidades.CREAR_TABLA_CATEGORIA);
        db.execSQL(Utilidades.CREAR_TABLA_GRUPO);
        db.execSQL(Utilidades.CREAR_TABLA_ROLUSUARIO);
        db.execSQL(Utilidades.CREAR_TABLA_USUARIO);
        db.execSQL(Utilidades.CREAR_TABLA_NIVELORGANIZATIVOUSUARIO);
        db.execSQL(Utilidades.CREAR_TABLA_ACTIVIDADUSUARIO);
        db.execSQL(Utilidades.CREAR_TABLA_USUARIOGRUPO);
        db.execSQL(Utilidades.CREAR_TABLA_NOTIFICACION);
        db.execSQL(Utilidades.CREAR_TABLA_CALENDARIO);
        db.execSQL(Utilidades.CREAR_TABLA_EVENTO);
        db.execSQL(Utilidades.CREAR_TABLA_CALENDARIOEVENTO);
        db.execSQL(Utilidades.CREAR_TABLA_EVENTOGRUPO);
        db.execSQL(Utilidades.CREAR_TABLA_NOTA);
        db.execSQL(Utilidades.CREAR_TABLA_FICHERO);
        db.execSQL(Utilidades.CREAR_TABLA_FECHAULTIMAACTUALIZACION);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_NIVELORGANIZATIVO);
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_ACTIVIDAD);
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_CATEGORIA);
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_GRUPO);
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_ROLUSUARIO);
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_USUARIO);
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_NIVELORGANIZATIVOUSUARIO);
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_ACTIVIDADUSUARIO);
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_USUARIOGRUPO);
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_NOTIFICACION);
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_CALENDARIO);
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_EVENTO);
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_CALENDARIOEVENTO);
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_EVENTOGRUPO);
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_NOTA);
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_FICHERO);
        db.execSQL("DROP TABLE IF EXISTS " + Utilidades.TABLA_FECHAULTIMAACTUALIZACION);

        onCreate(db);
    }
}

package nucleo;

import java.sql.Date;
import java.sql.Time;

public class Notificacion
{
    private String ID;
    private String titulo;
    private String texto;
    private Date fecha;
    private Time hora;
    private Boolean leida;
    private String creador;

    public Notificacion(String ID, String titulo, String texto, Date fecha, Time hora, String creador, boolean leida)
    {
        this.ID = ID;
        this.titulo = titulo;
        this.texto = texto;
        this.fecha =fecha;
        this.hora = hora;
        this.creador = creador;
        this.leida = leida;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Time getHora() {
        return hora;
    }

    public void setHora(Time hora) {
        this.hora = hora;
    }

    public Boolean getLeida() {
        return leida;
    }

    public void setLeida(Boolean leida) {
        this.leida = leida;
    }

    public String getCreador() {
        return creador;
    }

    public void setCreador(String creador) {
        this.creador = creador;
    }
}
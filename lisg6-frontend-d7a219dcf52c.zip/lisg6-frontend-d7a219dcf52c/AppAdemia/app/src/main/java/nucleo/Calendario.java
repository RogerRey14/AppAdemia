package nucleo;

import java.io.File;

public class Calendario
{
    private String nombre;
    private String descripcion;

    private Evento[] eventos;
    private Vista vista;
    private Exportador exportador;
    private Importador importador;


    public void mostrar()
    {

    }

    public File exportar()
    {
    		return null;
    }

    public void importar(File fichero)
    {

    }
}
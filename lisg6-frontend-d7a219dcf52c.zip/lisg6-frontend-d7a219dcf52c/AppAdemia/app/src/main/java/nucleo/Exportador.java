package nucleo;

import java.io.File;
import java.io.FileOutputStream;

public interface Exportador
{
    public FileOutputStream exportar(String nombre, File extern);
}
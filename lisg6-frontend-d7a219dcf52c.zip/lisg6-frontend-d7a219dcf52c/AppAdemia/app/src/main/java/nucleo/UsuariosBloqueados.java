package nucleo;

public class UsuariosBloqueados
{
    private Usuario[] usuariosBloqueados;

    public void bloquearUsuario(Usuario usuario)
    {

    }

    public void desbloquearUsuario(Usuario usuario)
    {

    }
}
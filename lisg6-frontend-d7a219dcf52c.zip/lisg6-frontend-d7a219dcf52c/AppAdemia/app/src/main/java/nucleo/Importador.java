package nucleo;

import java.io.File;

interface Importador
{
    public void importar(File archivo);
}
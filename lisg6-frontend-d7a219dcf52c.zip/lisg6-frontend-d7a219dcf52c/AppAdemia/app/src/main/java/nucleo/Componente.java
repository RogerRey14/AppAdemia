package nucleo;

import java.util.ArrayList;

public interface Componente
{
    Object getID();

    void addComponente(Componente componente);

    ArrayList<Componente> getHijos();

    String getNombre();

    String getDescripcion();

    String getTipo();

    int getOficialidad();

    void print(String indentacion);
    //public Usuario[] administradores;
}
package nucleo;

import java.util.ArrayList;
import java.util.Random;

public class Actividad implements Componente
{
    private String ID;
    private String nombreActividad;
    private String descripcion;

    private ArrayList<Usuario> moderadores;
    private ArrayList<Categoria> categorias;

    public Actividad()
    {
    	this.moderadores = new ArrayList<Usuario>();
    	this.categorias = new ArrayList<Categoria>();
    }

    public void vaciarModeradores()
    {
    	this.moderadores = new ArrayList<Usuario>();
    }

    public void addModerador(Usuario usuario)
    {
    	this.moderadores.add(usuario);
    }
    
    public void eliminarModerador(Usuario usuario)
    {
    	this.moderadores.remove(usuario);
    }
    
    public void vaciarCategorias()
    {
    	this.categorias = new ArrayList<Categoria>();
    }
    
    public void addCategoria(Categoria categoria)
    {
    	this.categorias.add(categoria);
    }
    
    public void eliminarCategoria(Categoria categoria)
    {
    	this.categorias.remove(categoria);
    }    
    
    //setters y getters
    
    public String getID()
    {
    	return this.ID;
    }

    @Override
    public void addComponente(Componente componente) {

    }

    @Override
    public ArrayList<Componente> getHijos() {
        return new ArrayList<Componente>();
    }

    public void setID(String ID)
    {
    	this.ID = ID;
    }
    
    public String getNombre()
    {
    	return this.nombreActividad;
    }
    
    public void setNombre(String nombre)
    {
    	this.nombreActividad = nombre;
    }
    
    public String getDescripcion()
    {
    	return this.descripcion;
    }

    @Override
    public String getTipo() {
        return null;
    }

    @Override
    public int getOficialidad() {
        return 0;
    }

    @Override
    public void print(String indentacion)
    {
//        System.out.println(indentacion+"Es Actividad");
//        System.out.println(indentacion+"ID: " + ID);
//        System.out.println(indentacion+"Nombre: " + nombreActividad);
//        System.out.println(indentacion+"Descripcion: " + descripcion);
//        System.out.println(indentacion+"Numero categorias: " + categorias.size());
        if(categorias.isEmpty()==false)
        {
            indentacion=indentacion+"--";
            System.out.println(indentacion);
            for(Categoria categoria : categorias)
            {
                categoria.print(indentacion);
                System.out.println(indentacion);
            }

        }
    }

    public void setDescripcion(String descripcion)
    {
    	this.descripcion = descripcion;
    }
    
    public ArrayList<Usuario> getModeradores()
    {
    	return this.moderadores;
    }
    
    public void setTipo(ArrayList<Usuario> moderadores)
    {
    	this.moderadores = moderadores;
    }
    
    public ArrayList<Categoria> getCategorias()
    {
    	return this.categorias;
    }
    
    public void setCategorias(ArrayList<Categoria> categorias)
    {
    	this.categorias = categorias;
    }
    

}
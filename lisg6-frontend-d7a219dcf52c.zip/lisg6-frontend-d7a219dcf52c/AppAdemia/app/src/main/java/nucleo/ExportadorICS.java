package nucleo;

import net.fortuna.ical4j.data.CalendarOutputter;
import net.fortuna.ical4j.model.Calendar;
import net.fortuna.ical4j.model.Date;
import net.fortuna.ical4j.model.DateTime;
import net.fortuna.ical4j.model.Property;
import net.fortuna.ical4j.model.TimeZone;
import net.fortuna.ical4j.model.TimeZoneRegistry;
import net.fortuna.ical4j.model.TimeZoneRegistryFactory;
import net.fortuna.ical4j.model.ValidationException;
import net.fortuna.ical4j.model.component.VEvent;
import net.fortuna.ical4j.model.component.VTimeZone;
import net.fortuna.ical4j.model.parameter.Value;
import net.fortuna.ical4j.model.property.CalScale;
import net.fortuna.ical4j.model.property.Categories;
import net.fortuna.ical4j.model.property.Description;
import net.fortuna.ical4j.model.property.DtStart;
import net.fortuna.ical4j.model.property.Location;
import net.fortuna.ical4j.model.property.ProdId;
import net.fortuna.ical4j.model.property.Uid;
import net.fortuna.ical4j.model.property.Version;
import net.fortuna.ical4j.util.UidGenerator;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import lis.main.appademia.AppAdemia;
import lis.main.appademia.adapter.DatosEvento;

/**
 * Clase encargada de exportar los eventos del calendario a formato ICS.
 * La clase padre Exportador permite emplear la misma función tanto para
 * formato ICS como para CSV.
 */
public class ExportadorICS implements Exportador
{
    @Override
    public FileOutputStream exportar(String nombre, File extern)
    {
        try {
            FileOutputStream fout = new FileOutputStream(new File(extern,(nombre + ".ics")));
            CalendarOutputter outputter = new CalendarOutputter();
            Calendar calendar = new Calendar();
            calendar.getProperties().add(new ProdId("-//AppAdemia//AppAdemia 2.0//ES"));
            calendar.getProperties().add(Version.VERSION_2_0);
            calendar.getProperties().add(CalScale.GREGORIAN);
            for (DatosEvento i : AppAdemia.getInstance().getDatosCalendario().getEventos()){
                VEvent evento = new VEvent(new DateTime(i.getFechaInicio().getTime()),
                        new DateTime(i.getFechaFin().getTime()), i.getNombreEvento());
                evento.getProperties().add(new Description(i.getDescripcion()));
                evento.getProperties().add(new Location(i.getLugar()));
                evento.getProperties().add(new Categories(i.getActividad()));
                UidGenerator ug = new UidGenerator("uidGen");
                Uid uid = new Uid(i.getId());
                evento.getProperties().add(uid);
                calendar.getComponents().add(evento);
            }
            outputter.output(calendar, fout);
            return fout;
        } catch (IOException | ValidationException e){
            e.printStackTrace();
        }

        return null;
    }
}
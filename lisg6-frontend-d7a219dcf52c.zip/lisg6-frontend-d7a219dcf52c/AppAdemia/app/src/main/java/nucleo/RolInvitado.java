package nucleo;

public class RolInvitado extends RolUsuario
{

    public Boolean registrarUsuario(String email, String contrasena)
    {
    	return null;
    }

    public RolUsuario iniciarSesion(String email, String contrasena)
    {
		return null;
    }
}
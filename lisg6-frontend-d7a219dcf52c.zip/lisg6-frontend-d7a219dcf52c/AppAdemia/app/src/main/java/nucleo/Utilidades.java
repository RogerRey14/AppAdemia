package nucleo;

public class Utilidades
{
    private static final String ES_ID = " NOT NULL PRIMARY KEY AUTOINCREMENT, ";

    //La creacion de las Tablas debe hacerse en este orden debido a la creacion de las Foreign Keys

    //CONSTANTES TABLAS

    //Constantes tabla NivelOrganizativo
    public static final String TABLA_NIVELORGANIZATIVO = "NivelOrganizativo";

    public static final String CAMPO_NIVELORGANIZATIVO_ID = "ID";
    public static final String CAMPO_NIVELORGANIZATIVO_NOMBRE = "nombre";
    public static final String CAMPO_NIVELORGANIZATIVO_DESCRIPCION = "descripcion";
    public static final String CAMPO_NIVELORGANIZATIVO_TIPO = "tipo";
    public static final String CAMPO_NIVELORGANIZATIVO_ESOFICIAL = "esOficial";
    public static final String CAMPO_NIVELORGANIZATIVO_NIVELPADRE = "nivelPadre";
    public static final String CAMPO_NIVELORGANIZATIVO_FECHAACTUALIZACION = "fecha_ultima_modificacion";

    public static final String NIVELORGANIZATIVO_FK0 = "NivelOrganizativo_fk0";

    public static final String CREAR_TABLA_NIVELORGANIZATIVO = "CREATE TABLE IF NOT EXISTS "+TABLA_NIVELORGANIZATIVO
            +" ("+CAMPO_NIVELORGANIZATIVO_ID+" INTEGER "+ES_ID+CAMPO_NIVELORGANIZATIVO_NOMBRE+" TEXT NOT NULL, "
            +CAMPO_NIVELORGANIZATIVO_DESCRIPCION+" TEXT, "+CAMPO_NIVELORGANIZATIVO_TIPO+" TEXT NOT NULL, "
            +CAMPO_NIVELORGANIZATIVO_ESOFICIAL+" INTEGER NOT NULL, "+CAMPO_NIVELORGANIZATIVO_NIVELPADRE
            +" INTEGER, "+CAMPO_NIVELORGANIZATIVO_FECHAACTUALIZACION+" TEXT, CONSTRAINT "
            +NIVELORGANIZATIVO_FK0+" FOREIGN KEY ("+CAMPO_NIVELORGANIZATIVO_NIVELPADRE+") REFERENCES "
            +TABLA_NIVELORGANIZATIVO+" ("+CAMPO_NIVELORGANIZATIVO_ID+") ON DELETE CASCADE);";

    //Constantes tabla Actividad
    public static final String TABLA_ACTIVIDAD = "Actividad";

    public static final String CAMPO_ACTIVIDAD_ID = "ID";
    public static final String CAMPO_ACTIVIDAD_NOMBRE = "nombre";
    public static final String CAMPO_ACTIVIDAD_DESCRIPCION = "descripcion";
    public static final String CAMPO_ACTIVIDAD_NIVELORGANIZATIVO = "nivelOrganizativo";
    public static final String CAMPO_ACTIVIDAD_FECHAACTUALIZACION = "fecha_ultima_modificacion";

    public static final String ACTIVIDAD_FK0 = "Actividad_fk0";

    public static final String CREAR_TABLA_ACTIVIDAD = "CREATE TABLE IF NOT EXISTS "+TABLA_ACTIVIDAD+" ("
            +CAMPO_ACTIVIDAD_ID+" INTEGER"+ES_ID+CAMPO_ACTIVIDAD_NOMBRE+" TEXT NOT NULL, "+CAMPO_ACTIVIDAD_DESCRIPCION
            +" TEXT, "+CAMPO_ACTIVIDAD_NIVELORGANIZATIVO+" INTEGER NOT NULL, "+CAMPO_ACTIVIDAD_FECHAACTUALIZACION
            +" TEXT, CONSTRAINT "+ACTIVIDAD_FK0
            +" FOREIGN KEY ("+CAMPO_ACTIVIDAD_NIVELORGANIZATIVO+") REFERENCES "+TABLA_NIVELORGANIZATIVO
            +" ("+CAMPO_NIVELORGANIZATIVO_ID+") ON DELETE CASCADE);";

    //Constantes tabla Categoria
    public static final String TABLA_CATEGORIA = "Categoria";

    public static final String CAMPO_CATEGORIA_ID = "ID";
    public static final String CAMPO_CATEGORIA_NOMBRE = "nombre";
    public static final String CAMPO_CATEGORIA_DESCRIPCION = "descripcion";
    public static final String CAMPO_CATEGORIA_ACTIVIDAD = "actividad";
    public static final String CAMPO_CATEGORIA_FECHAACTUALIZACION = "fecha_ultima_modificacion";

    public static final String CATEGORIA_FK0 = "Categoria_fk0";

    public static final String CREAR_TABLA_CATEGORIA = "CREATE TABLE IF NOT EXISTS "+TABLA_CATEGORIA+" ("
            +CAMPO_CATEGORIA_ID+" INTEGER"+ES_ID+CAMPO_CATEGORIA_NOMBRE+" TEXT NOT NULL, "+CAMPO_CATEGORIA_DESCRIPCION
            +" TEXT, "+CAMPO_CATEGORIA_ACTIVIDAD+" INTEGER NOT NULL, "+CAMPO_CATEGORIA_FECHAACTUALIZACION
            +" TEXT, CONSTRAINT "+CATEGORIA_FK0
            +" FOREIGN KEY ("+CAMPO_CATEGORIA_ACTIVIDAD+") REFERENCES "+TABLA_ACTIVIDAD+" ("
            +CAMPO_ACTIVIDAD_ID+") ON DELETE CASCADE);";

    //Constantes tabla Grupo
    public static final String TABLA_GRUPO = "Grupo";

    public static final String CAMPO_GRUPO_ID = "ID";
    public static final String CAMPO_GRUPO_NOMBRE = "nombre";
    public static final String CAMPO_GRUPO_DESCRIPCION = "descripcion";
    public static final String CAMPO_GRUPO_PASSWORD = "password";
    public static final String CAMPO_GRUPO_SILENCIADO = "silenciado";
    public static final String CAMPO_GRUPO_PUBLICO = "publico";
    public static final String CAMPO_GRUPO_CATEGORIA = "categoria";
    public static final String CAMPO_GRUPO_FECHAACTUALIZACION = "fecha_ultima_modificacion";

    public static final String GRUPO_FK0 = "Grupo_fk0";

    public static final String CREAR_TABLA_GRUPO = "CREATE TABLE IF NOT EXISTS "+TABLA_GRUPO+" ("+CAMPO_GRUPO_ID
            +" INTEGER"+ES_ID+CAMPO_GRUPO_NOMBRE+" TEXT NOT NULL, "+CAMPO_GRUPO_DESCRIPCION+" TEXT, "
            +CAMPO_GRUPO_PASSWORD+" TEXT, "+CAMPO_GRUPO_SILENCIADO+" INTEGER NOT NULL, "+CAMPO_GRUPO_PUBLICO
            +" INTEGER NOT NULL, "+CAMPO_GRUPO_CATEGORIA+" INTEGER NOT NULL, "+CAMPO_GRUPO_FECHAACTUALIZACION
            +" TEXT, CONSTRAINT "+GRUPO_FK0
            +" FOREIGN KEY ("+CAMPO_GRUPO_CATEGORIA+") REFERENCES "+TABLA_CATEGORIA+" ("
            +CAMPO_CATEGORIA_ID+") ON DELETE CASCADE);";

    //Constantes tabla RolUsuario
    public static final String TABLA_ROLUSUARIO = "RolUsuario";
    public static final String CAMPO_ROLUSUARIO_ID = "ID";
    public static final String CAMPO_ROLUSUARIO_NOMBRE = "Nombre";
    public static final String CAMPO_ROLUSUARIO_FECHAACTUALIZACION = "fecha_ultima_modificacion";

    public static final String CREAR_TABLA_ROLUSUARIO = "CREATE TABLE IF NOT EXISTS "+TABLA_ROLUSUARIO+" ("
            +CAMPO_ROLUSUARIO_ID+" INTEGER, "+CAMPO_ROLUSUARIO_NOMBRE+" INTEGER, "+CAMPO_ROLUSUARIO_FECHAACTUALIZACION+" TEXT);";

    //Constantes tabla Usuario
    public static final String TABLA_USUARIO = "Usuario";
    public static final String CAMPO_USUARIO_ID = "ID";
    public static final String CAMPO_USUARIO_NOMBRE = "nombre";
    public static final String CAMPO_USUARIO_EMAIL = "email";
    public static final String CAMPO_USUARIO_PASSWORD = "password";
    public static final String CAMPO_USUARIO_FECHAACTUALIZACION = "fecha_ultima_modificacion";

    public static final String CREAR_TABLA_USUARIO = "CREATE TABLE IF NOT EXISTS "+TABLA_USUARIO+" ("+CAMPO_USUARIO_ID
            +" INTEGER"+ES_ID+CAMPO_USUARIO_NOMBRE+" TEXT NOT NULL, "+CAMPO_USUARIO_EMAIL+" TEXT NOT NULL, "
            +CAMPO_USUARIO_PASSWORD+" TEXT NOT NULL, "+CAMPO_USUARIO_FECHAACTUALIZACION+" TEXT);";

    //Constantes tabla NivelOrganizativoUsuario
    public static final String TABLA_NIVELORGANIZATIVOUSUARIO = "NivelOrganizativoUsuario";

    public static final String CAMPO_NIVELORGANIZATIVOUSUARIO_NIVELORGANIZATIVO = "nivelOrganizativo";
    public static final String CAMPO_NIVELORGANIZATIVOUSIARIO_USUARIO = "usuario";
    public static final String CAMPO_NIVELORGANIZATIVOUSUARIO_ROLUSUARIO = "rolUsuario";
    public static final String CAMPO_NIVELORGANIZATIVOUSUARIO_FECHAACTUALIZACION = "fecha_ultima_modificacion";

    public static final String NIVELORGANIZATIVOUSUARIO_FK0 = "NivelOrganizativoUsuario_fk0";
    public static final String NIVELORGANIZATIVOUSUARIO_FK1 = "NivelOrganizativoUsuario_fk1";
    public static final String NIVELORGANIZATIVOUSUARIO_FK2 = "NivelOrganizativoUsuario_fk2";

    public static final String CREAR_TABLA_NIVELORGANIZATIVOUSUARIO = "CREATE TABLE IF NOT EXISTS "+TABLA_NIVELORGANIZATIVOUSUARIO
            +" ("+CAMPO_NIVELORGANIZATIVOUSUARIO_NIVELORGANIZATIVO+" INTEGER NOT NULL, "+CAMPO_NIVELORGANIZATIVOUSIARIO_USUARIO
            +" INTEGER NOT NULL, "+CAMPO_NIVELORGANIZATIVOUSUARIO_ROLUSUARIO+" INTEGER NOT NULL, "
            +CAMPO_NIVELORGANIZATIVOUSUARIO_FECHAACTUALIZACION+" TEXT, PRIMARY KEY("
            +CAMPO_NIVELORGANIZATIVOUSUARIO_NIVELORGANIZATIVO+", "+CAMPO_NIVELORGANIZATIVOUSIARIO_USUARIO
            +", "+CAMPO_NIVELORGANIZATIVOUSUARIO_ROLUSUARIO+"), CONSTRAINT "+NIVELORGANIZATIVOUSUARIO_FK0
            +" FOREIGN KEY ("+CAMPO_NIVELORGANIZATIVOUSUARIO_NIVELORGANIZATIVO+") REFERENCES "
            +TABLA_NIVELORGANIZATIVO+" ("+CAMPO_NIVELORGANIZATIVO_ID+") ON DELETE CASCADE, CONSTRAINT "
            +NIVELORGANIZATIVOUSUARIO_FK1+" FOREIGN KEY ("+CAMPO_NIVELORGANIZATIVOUSIARIO_USUARIO
            +") REFERENCES "+TABLA_USUARIO+" ("+CAMPO_USUARIO_ID+") ON DELETE CASCADE, CONSTRAINT "
            +NIVELORGANIZATIVOUSUARIO_FK2+" FOREIGN KEY ("+CAMPO_NIVELORGANIZATIVOUSUARIO_ROLUSUARIO
            +") REFERENCES "+TABLA_ROLUSUARIO+" ("+CAMPO_ROLUSUARIO_ID+") ON DELETE CASCADE);";

    //Constantes tabla ActividadUsuario
    public static final String TABLA_ACTIVIDADUSUARIO = "ActividadUsuario";

    public static final String CAMPO_ACTIVIDADUSUARIO_ACTIVIDAD = "actividad";
    public static final String CAMPO_ACTIVIDADUSUARIO_USUARIO = "usuario";
    public static final String CAMPO_ACTIVIDADUSUARIO_ROLUSUARIO = "rolUsuario";
    public static final String CAMPO_ACTIVIDADUSUARIO_FECHAACTUALIZACION = "fecha_ultima_modificacion";

    public static final String ACTIVIDADUSUARIO_FK0 = "ActividadUsuario_fk0";
    public static final String ACTIVIDADUSUARIO_FK1 = "ActividadUsuario_fk1";
    public static final String ACTIVIDADUSUARIO_FK2 = "ActividadUsuario_fk2";

    public static final String CREAR_TABLA_ACTIVIDADUSUARIO = "CREATE TABLE IF NOT EXISTS "+TABLA_ACTIVIDADUSUARIO
            +" ("+CAMPO_ACTIVIDADUSUARIO_ACTIVIDAD+" INTEGER NOT NULL, "+CAMPO_ACTIVIDADUSUARIO_USUARIO
            +" INTEGER NOT NULL, "+CAMPO_ACTIVIDADUSUARIO_ROLUSUARIO+" INTEGER NOT NULL, "
            +CAMPO_ACTIVIDADUSUARIO_FECHAACTUALIZACION+" TEXT, PRIMARY KEY("
            +CAMPO_ACTIVIDADUSUARIO_ACTIVIDAD+", "+CAMPO_ACTIVIDADUSUARIO_USUARIO+", "
            +CAMPO_ACTIVIDADUSUARIO_ROLUSUARIO+"), CONSTRAINT "+ACTIVIDADUSUARIO_FK0+" FOREIGN KEY ("
            +CAMPO_ACTIVIDADUSUARIO_ACTIVIDAD+") REFERENCES "+TABLA_ACTIVIDAD+" ("+CAMPO_ACTIVIDAD_ID
            +") ON DELETE CASCADE, CONSTRAINT "+ACTIVIDADUSUARIO_FK1+" FOREIGN KEY ("+CAMPO_ACTIVIDADUSUARIO_USUARIO
            +") REFERENCES "+TABLA_USUARIO+" ("+CAMPO_USUARIO_ID+") ON DELETE CASCADE, CONSTRAINT "
            +ACTIVIDADUSUARIO_FK2+" FOREIGN KEY ("+CAMPO_ACTIVIDADUSUARIO_ROLUSUARIO+") REFERENCES "
            +TABLA_ROLUSUARIO+" ("+CAMPO_ROLUSUARIO_ID+") ON DELETE CASCADE);";

    //Constantes tabla UsuarioGrupo
    public static final String TABLA_USUARIOGRUPO = "UsuarioGrupo";

    public static final String CAMPO_USUARIOGRUPO_USUARIO = "usuario";
    public static final String CAMPO_USUARIOGRUPO_GRUPO = "grupo";
    public static final String CAMPO_USUARIOGRUPO_SUSCRITO = "suscrito";
    public static final String CAMPO_USUARIOGRUPO_BLOQUEADO = "bloqueado";
    public static final String CAMPO_USUARIOGRUPO_FECHAACTUALIZACION = "fecha_ultima_modificacion";

    public static final String USUARIOGRUPO_FK0 = "UsuarioGrupo_fk0";
    public static final String USUARIOGRUPO_FK1 = "UsuarioGrupo_fk1";

    public static final String CREAR_TABLA_USUARIOGRUPO = "CREATE TABLE IF NOT EXISTS " + TABLA_USUARIOGRUPO
            +" ("+CAMPO_USUARIOGRUPO_USUARIO+" INTEGER NOT NULL, "+CAMPO_USUARIOGRUPO_GRUPO+" INTEGER NOT NULL, "
            +CAMPO_USUARIOGRUPO_SUSCRITO+" INTEGER NOT NULL, "+CAMPO_USUARIOGRUPO_BLOQUEADO+" INTEGER NOT NULL, "
            +CAMPO_USUARIOGRUPO_FECHAACTUALIZACION+" TEXT, PRIMARY KEY("
            +CAMPO_USUARIOGRUPO_USUARIO+", "+CAMPO_USUARIOGRUPO_GRUPO+"), CONSTRAINT "+USUARIOGRUPO_FK0
            +" FOREIGN KEY ("+CAMPO_USUARIOGRUPO_USUARIO+") REFERENCES "+TABLA_USUARIO+" ("+CAMPO_USUARIO_ID
            +") ON DELETE CASCADE, CONSTRAINT "+USUARIOGRUPO_FK1+" FOREIGN KEY ("+CAMPO_USUARIOGRUPO_GRUPO
            +") REFERENCES "+TABLA_GRUPO+" ("+CAMPO_GRUPO_ID+") ON DELETE CASCADE);";

    //Constantes tabla Notificacion
    public static final String TABLA_NOTIFICACION = "Notificacion";

    public static final String CAMPO_NOTIFICACION_ID = "ID";
    public static final String CAMPO_NOTIFICACION_GRUPO = "grupo";
    public static final String CAMPO_NOTIFICACION_CREADOR = "creador";
    public static final String CAMPO_NOTIFICACION_TITULO = "titulo";
    public static final String CAMPO_NOTIFICACION_TEXTO = "texto";
    public static final String CAMPO_NOTIFICACION_FECHA = "fecha";
    public static final String CAMPO_NOTIFICACION_HORA = "hora";
    public static final String CAMPO_NOTIFICACION_FECHAACTUALIZACION = "fecha_ultima_modificacion";

    public static final String NOTIFICACION_FK0 = "Notificacion_fk0";
    public static final String NOTIFICACION_FK1 = "Notificacion_fk1";

    public static final String CREAR_TABLA_NOTIFICACION = "CREATE TABLE IF NOT EXISTS "+TABLA_NOTIFICACION
            +" ("+CAMPO_NOTIFICACION_ID+" INTEGER"+ES_ID+CAMPO_NOTIFICACION_GRUPO+" INTEGER NOT NULL, "
            +CAMPO_NOTIFICACION_CREADOR+" INTEGER NOT NULL, "+CAMPO_NOTIFICACION_TITULO+" TEXT NOT NULL, "
            +CAMPO_NOTIFICACION_TEXTO+" TEXT, "+CAMPO_NOTIFICACION_FECHA+" TEXT NOT NULL, "
            +CAMPO_NOTIFICACION_HORA+" TEXT NOT NULL, "+CAMPO_NOTIFICACION_FECHAACTUALIZACION
            +" TEXT, CONSTRAINT "+NOTIFICACION_FK0+" FOREIGN KEY ("
            +CAMPO_NOTIFICACION_GRUPO+") REFERENCES "+TABLA_GRUPO+" ("+CAMPO_GRUPO_ID+"), CONSTRAINT "
            +NOTIFICACION_FK1+" FOREIGN KEY ("+CAMPO_NOTIFICACION_CREADOR+") REFERENCES "+TABLA_USUARIO
            +" ("+CAMPO_USUARIO_ID+"));";

    //Constantes tabla Calendario
    public static final String TABLA_CALENDARIO = "Calendario";

    public static final String CAMPO_CALENDARIO_ID = "ID";
    public static final String CAMPO_CALENDARIO_CREADOR = "creador";
    public static final String CAMPO_CALENDARIO_FECHAACTUALIZACION = "fecha_ultima_modificacion";

    public static final String CALENDARIO_FK0 = "Calendario_fk0";

    public static final String CREAR_TABLA_CALENDARIO = "CREATE TABLE IF NOT EXISTS "+TABLA_CALENDARIO
            +" ("+CAMPO_CALENDARIO_ID+" INTEGER"+ES_ID+CAMPO_CALENDARIO_CREADOR+" INTEGER NOT NULL, "
            +CAMPO_CALENDARIO_FECHAACTUALIZACION+" TEXT, CONSTRAINT "
            +CALENDARIO_FK0+" FOREIGN KEY ("+CAMPO_CALENDARIO_CREADOR+") REFERENCES "+TABLA_USUARIO
            +" ("+CAMPO_USUARIO_ID+") ON DELETE CASCADE);";

    //Constantes tabla Evento
    public static final String TABLA_EVENTO = "Evento";
    public static final String CAMPO_EVENTO_ID = "ID";
    public static final String CAMPO_EVENTO_NOMBRE = "nombre";
    public static final String CAMPO_EVENTO_DESCRIPCION = "descripcion";
    public static final String CAMPO_EVENTO_LUGAR = "lugar";
    public static final String CAMPO_EVENTO_FECHAINICIO = "fechaInicio";
    public static final String CAMPO_EVENTO_FECHAFIN = "fechaFin";
    public static final String CAMPO_EVENTO_HORAINICIO = "horaInicio";
    public static final String CAMPO_EVENTO_HORAFIN = "horaFin";
    public static final String CAMPO_EVENTO_ESRECORDATORIO = "esRecordatorio";
    public static final String CAMPO_EVENTO_GRUPO = "grupo";
    public static final String CAMPO_EVENTO_FECHAACTUALIZACION = "fecha_ultima_modificacion";

    public static final String EVENTO_FK0 = "Evento_fk0";

    public static final String CREAR_TABLA_EVENTO = "CREATE TABLE IF NOT EXISTS "+TABLA_EVENTO+" ("
            +CAMPO_EVENTO_ID+" INTEGER"+ES_ID+CAMPO_EVENTO_NOMBRE+" TEXT, "+CAMPO_EVENTO_DESCRIPCION
            +" TEXT, "+CAMPO_EVENTO_LUGAR+" TEXT NOT NULL, "+CAMPO_EVENTO_FECHAINICIO+" TEXT NOT NULL, "
            +CAMPO_EVENTO_FECHAFIN+" TEXT NOT NULL, "+CAMPO_EVENTO_HORAINICIO+" TEXT NOT NULL, "+CAMPO_EVENTO_HORAFIN
            +" TEXT NOT NULL, "+CAMPO_EVENTO_ESRECORDATORIO+" INTEGER NOT NULL, "+CAMPO_EVENTO_GRUPO
            +" INT, "+CAMPO_EVENTO_FECHAACTUALIZACION+" TEXT, CONSTRAINT "+EVENTO_FK0+" FOREIGN KEY ("
            +CAMPO_EVENTO_GRUPO+") REFERENCES "+TABLA_GRUPO+" ("+CAMPO_GRUPO_ID+") ON DELETE CASCADE);";

    //Constantes tabla CalendarioEvento
    public static final String TABLA_CALENDARIOEVENTO = "CalendarioEvento";

    public static final String CAMPO_CALENDARIOEVENTO_CALENDARIO = "Calendario";
    public static final String CAMPO_CALENDARIOEVENTO_EVENTO = "Evento";
    public static final String CAMPO_CALENDARIOEVENTO_FECHAACTUALIZACION = "fecha_ultima_modificacion";

    public static final String CALENDARIOEVENTO_FK0 = "CalendarioEvento_fk0";
    public static final String CALENDARIOEVENTO_FK1 = "CalendarioEvento_fk1";

    public static final String CREAR_TABLA_CALENDARIOEVENTO = "CREATE TABLE IF NOT EXISTS "+TABLA_CALENDARIOEVENTO
            +" ("+CAMPO_CALENDARIOEVENTO_CALENDARIO+" INTEGER NOT NULL, "+CAMPO_CALENDARIOEVENTO_EVENTO
            +" INTEGER NOT NULL, "+CAMPO_CALENDARIOEVENTO_FECHAACTUALIZACION+" TEXT, PRIMARY KEY("+CAMPO_CALENDARIOEVENTO_CALENDARIO+", "
            +CAMPO_CALENDARIOEVENTO_EVENTO+"), CONSTRAINT "+CALENDARIOEVENTO_FK0+" FOREIGN KEY ("
            +CAMPO_CALENDARIOEVENTO_CALENDARIO+") REFERENCES "+TABLA_CALENDARIO+" ("+CAMPO_CALENDARIO_ID
            +") ON DELETE CASCADE, CONSTRAINT "+CALENDARIOEVENTO_FK1+" FOREIGN KEY ("+CAMPO_CALENDARIOEVENTO_EVENTO
            +") REFERENCES "+TABLA_EVENTO+" ("+CAMPO_EVENTO_ID+") ON DELETE CASCADE);";

    //TODO eliminar esta tabla
    //Constantes tabla EventoGrupo
    public static final String TABLA_EVENTOGRUPO = "EventoGrupo";

    public static final String CAMPO_EVENTOGRUPO_EVENTO = "evento";
    public static final String CAMPO_EVENTOGRUPO_GRUPO = "grupo";

    public static final String EVENTOGRUPO_FK0 = "EventoGrupo_fk0";
    public static final String EVENTOGRUPO_FK1 = "EventoGrupo_fk1";

    public static final String CREAR_TABLA_EVENTOGRUPO = "CREATE TABLE IF NOT EXISTS "+TABLA_EVENTOGRUPO+" ("
            +CAMPO_EVENTOGRUPO_EVENTO+" INTEGER NOT NULL, "+CAMPO_EVENTOGRUPO_GRUPO+" INTEGER NOT NULL, PRIMARY KEY("
            +CAMPO_EVENTOGRUPO_EVENTO+", "+CAMPO_EVENTOGRUPO_GRUPO+"), CONSTRAINT "+EVENTOGRUPO_FK0
            +" FOREIGN KEY ("+CAMPO_EVENTOGRUPO_GRUPO+") REFERENCES "+TABLA_GRUPO+" ("+CAMPO_GRUPO_ID
            +") ON DELETE CASCADE, CONSTRAINT "+EVENTOGRUPO_FK1+" FOREIGN KEY ("+CAMPO_EVENTOGRUPO_EVENTO
            +") REFERENCES "+TABLA_EVENTO+" ("+CAMPO_EVENTO_ID+") ON DELETE CASCADE);";

    //Constantes tabla Nota
    public static final String TABLA_NOTA = "Nota";

    public static final String CAMPO_NOTA_ID = "ID";
    public static final String CAMPO_NOTA_TITULO = "titulo";
    public static final String CAMPO_NOTA_TEXTO = "texto";
    public static final String CAMPO_NOTA_FECHA = "fecha";
    public static final String CAMPO_NOTA_HORA = "hora";
    public static final String CAMPO_NOTA_ESPUBLICA = "esPublica";
    public static final String CAMPO_NOTA_EVENTO = "evento";
    public static final String CAMPO_NOTA_CREADOR = "creador";
    public static final String CAMPO_NOTA_FECHAACTUALIZACION = "fecha_ultima_modificacion";

    public static final String NOTA_FK0 = "Nota_fk0";
    public static final String NOTA_FK1 = "Nota_fk1";

    public static final String CREAR_TABLA_NOTA = "CREATE TABLE IF NOT EXISTS "+TABLA_NOTA+" ("+CAMPO_NOTA_ID
            +" INTEGER"+ES_ID+CAMPO_NOTA_TITULO+" TEXT NOT NULL, "+CAMPO_NOTA_TEXTO+" TEXT, "+CAMPO_NOTA_FECHA
            +" TEXT NOT NULL, "+CAMPO_NOTA_HORA+" TEXT NOT NULL, "+CAMPO_NOTA_ESPUBLICA+" INTEGER NOT NULL, "+CAMPO_NOTA_EVENTO
            +" INTEGER NOT NULL, "+CAMPO_NOTA_CREADOR+" INTEGER NOT NULL, "+CAMPO_NOTA_FECHAACTUALIZACION
            +" TEXT, CONSTRAINT "+NOTA_FK0
            +" FOREIGN KEY ("+CAMPO_NOTA_EVENTO+") REFERENCES "+TABLA_EVENTO+" ("+CAMPO_EVENTO_ID
            +") ON DELETE CASCADE, CONSTRAINT "+NOTA_FK1+" FOREIGN KEY ("+CAMPO_NOTA_CREADOR+") REFERENCES "
            +TABLA_USUARIO+" ("+CAMPO_USUARIO_ID+") ON DELETE CASCADE);";

    //Constantes tabla Fichero
    public static final String TABLA_FICHERO = "Fichero";

    public static final String CAMPO_FICHERO_ID = "ID";
    public static final String CAMPO_FICHERO_FICHERO = "fichero";
    public static final String CAMPO_FICHERO_NOTA = "nota";
    public static final String CAMPO_FICHERO_FECHAACTUALIZACION = "fecha_ultima_modificacion";

    public static final String FICHERO_FK0 = "Fichero_fk0";

    public static final String CREAR_TABLA_FICHERO = "CREATE TABLE IF NOT EXISTS "+TABLA_FICHERO+" ("
            +CAMPO_FICHERO_ID+" INTEGER"+ES_ID+CAMPO_FICHERO_FICHERO+" BLOB NOT NULL, "+CAMPO_FICHERO_NOTA
            +" INTEGER NOT NULL, "+CAMPO_FICHERO_FECHAACTUALIZACION+" TEXT, CONSTRAINT "+FICHERO_FK0+" FOREIGN KEY ("+CAMPO_FICHERO_NOTA+") REFERENCES "
            +TABLA_NOTA+" ("+CAMPO_NOTA_ID+") ON DELETE CASCADE);";

    //Constantes tabla FechaActualizacion
    public static final String TABLA_FECHAULTIMAACTUALIZACION = "FechaUltimaActualizacion";

    public static final String CAMPO_FECHAULTIMAACTUALIZACION = "fecha_ultima_modificacion_interna";

    public static final String CREAR_TABLA_FECHAULTIMAACTUALIZACION = "CREATE TABLE IF NOT EXISTS "
            +TABLA_FECHAULTIMAACTUALIZACION+" ("+CAMPO_FECHAULTIMAACTUALIZACION+" STRING NOT NULL PRIMARY KEY);";

    //Constantes tabla UsuarioNotificacion
    public static final String TABLA_USUARIONOTIFICACION = "UsuarioNotificacion";

    public static final String CAMPO_USUARIONOTIFICACION_USUARIO = "usuario";
    public static final String CAMPO_USUARIONOTIFICACION_NOTIFICACION = "notificacion";
    public static final String CAMPO_USUARIONOTIFICACION_LEIDA = "leida";

    public static final String CREAR_TABLA_USUARIONOTIFICACION = "CREATE TABLE IF NOT EXISTS "
            +TABLA_USUARIONOTIFICACION+" ("+CAMPO_USUARIONOTIFICACION_USUARIO+" INT, "
            +CAMPO_USUARIONOTIFICACION_NOTIFICACION+" INT, "+CAMPO_USUARIONOTIFICACION_LEIDA
            +" INT, PRIMARY KEY("+CAMPO_USUARIONOTIFICACION_USUARIO+", "+CAMPO_USUARIONOTIFICACION_NOTIFICACION+"));";

    //Consultas HTTP
    public static final String FORMATO_FECHA = "yyyy-MM-dd";
    public static final String FORMATO_HORA = "HH:mm:ss";
    public static final String FORMATO_FECHAACTUALIZACION = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"; //"2020-06-03T16:18:09.000+0000"
    public static final String URL = "http://10.0.2.2:8080/api/";
    public static final String GET_NIVELESORGANIZATIVOS = "niveles/";
    public static final int OPCION_GET_NIVELESORGANIZATIVOS = 1;
    public static final String GET_ACTIVIDADES = "actividades/";
    public static final int OPCION_GET_ACTIVIDADES = 2;
    public static final String GET_CATEGORIAS = "categorias/";
    public static final int OPCION_GET_CATEGORIAS = 3;
    public static final String GET_GRUPOS = "grupos/";
    public static final int OPCION_GET_GRUPOS = 4;
    public static final String GET_EVENTOS = "eventos/";
    public static final int OPCION_GET_EVENTOS = 5;
    public static final String POST_USUARIO = "usuarios/";
    public static final int OPCION_POST_USUARIO = 6;
    public static final int OPCION_POST_EVENTO = 7;
    public static final int OPCION_DEL_EVENTO = 8;
    public static final int OPCION_PUT_EVENTO = 9;
    public static final String LOGIN = "login/";
    public static final int OPCION_POST_LOGIN = 10;
    public static final String USUARIO_POR_EMAIL = "usuarios/email/";
    public static final int OPCION_GET_USUARIO_POR_EMAIL = 11;
    public static final String CALENDARIOS_POR_USUARIO = "calendarios/creador/";
    public static final int OPCION_GET_CALENDARIO_POR_USUARIO = 12;
    public static final String CALENDARIOEVENTOS_POR_USUARIO = "calendarios/eventos/creador/";
    public static final int OPCION_GET_LISTACALENDARIOEVENTO_POR_USUARIO = 13;
    public static final String CALENDARIOS = "calendarios/";
    public static final int OPCION_POST_ADDCALENDARIO = 14;
    public static final int OPCION_POST_ADDCALENDARIOEVENTO = 15;
    public static final String ACTIVIDADES_ROLES = "actividades/roles/";
    public static final int OPCION_GET_ROLESACTIVIDAD_POR_USUARIO = 16;
    public static final String GRUPOS_SUSCRITO = "grupos/suscrito/";
    public static final int OPCION_GET_GRUPOSSUSCRITOS_POR_USUARIO = 17;
    public static final String GRUPOS_BLOQUEADO = "grupos/bloqueado/";
    public static final int OPCION_GET_GRUPOSBLOQUEADOS_POR_USUARIO = 18;
    public static final int OPCION_SUSCRIBIR_USUARIO = 19;
    public static final int OPCION_DESUSCRIBIR_USUARIO = 20;
    public static final String NOTAS_USUARIO = "notas/usuario/";
    public static final String NOTAS = "notas/";
    public static final int OPCION_GET_NOTASPERSONALES = 21;
    public static final int OPCION_GET_NOTASPUBLICAS = 22;
    public static final int OPCION_POST_NOTA = 23;
    public static final int OPCION_SINCRONIZAR_NIVELES = 24;
    public static final int OPCION_SINCRONIZAR_ACTIVIDADES = 25;
    public static final int OPCION_SINCRONIZAR_CATEGORIAS = 26;
    public static final int OPCION_SINCRONIZAR_GRUPOS = 27;
    public static final int OPCION_SINCRONIZAR_EVENTOS = 28;
    public static final int OPCION_SINCRONIZAR_NOTASPERSONALES = 29;
    public static final int OPCION_SINCRONIZAR_NOTASPUBLICAS = 30;
    public static final int OPCION_SINCRONIZAR_NOTIFICACIONES = 31;
    public static final int OPCION_SINCRONIZAR_CALENDARIOEVENTOS = 32;
    public static final String FECHAULTIMAMODIFICACION = "fechaModificacion/";
    public static final int OPCION_POST_ADDNOTIFICACION = 33;
    public static final String NOTIFICACIONES = "notificaciones/";
    public static final int OPCION_GET_NOTIFICACIONES_PORGRUPO = 34;



}

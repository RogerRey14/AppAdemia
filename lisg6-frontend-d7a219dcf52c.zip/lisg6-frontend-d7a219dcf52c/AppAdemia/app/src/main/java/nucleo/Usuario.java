package nucleo;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;

public class Usuario implements PropertyChangeListener
{
    private String ID;
    private String email;
    private String password;
    private String nombre;
    private int calendario;

    private RolUsuario rolUsuario;
    //private Calendario calendario;
    private ArrayList<Componente> nivelesOrganizativosAdministrados;
    private ArrayList<Integer> actividadesModeradas;
    private ArrayList<Integer> gruposSuscritos;
    private ArrayList<Integer> gruposBloqueados;

    public Usuario(String ID, String email, String password, String nombre){
        this.ID = ID;
        this.email = email;
        this.password = password;
        this.nombre = nombre;
        this.actividadesModeradas = new ArrayList<>();
        this.gruposSuscritos = new ArrayList<>();
        this.gruposBloqueados = new ArrayList<>();
    }

    public Usuario(boolean invitado){
        this.ID = "0";
        this.email = "";
        this.password = "";
        this.nombre = "Invitado";
        this.actividadesModeradas = new ArrayList<>();
        this.gruposSuscritos = new ArrayList<>();
        this.gruposBloqueados = new ArrayList<>();
        setCalendario(0);
    }

    @Override
	public void propertyChange(PropertyChangeEvent evt) {
		// TODO Auto-generated method stub
		
	}

	public Usuario()
    {

    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public RolUsuario getRolUsuario() {
        return rolUsuario;
    }

    public void setRolUsuario(RolUsuario rolUsuario) {
        this.rolUsuario = rolUsuario;
    }

    public ArrayList<Componente> getNivelesOrganizativosAdministrados() {
        return nivelesOrganizativosAdministrados;
    }

    public void setNivelesOrganizativosAdministrados(ArrayList<Componente> nivelesOrganizativosAdministrados) {
        this.nivelesOrganizativosAdministrados = nivelesOrganizativosAdministrados;
    }

    public ArrayList<Integer> getActividadesModeradas() {
        return actividadesModeradas;
    }

    public void setActividadesModeradas(ArrayList<Integer> actividadesModeradas) {
        this.actividadesModeradas = actividadesModeradas;
    }

    public ArrayList<Integer> getGruposSuscritos() {
        return gruposSuscritos;
    }

    public void setGruposSuscritos(ArrayList<Integer> gruposSuscritos) {
        this.gruposSuscritos = gruposSuscritos;
    }

    public ArrayList<Integer> getGruposBloqueados() {
        return gruposBloqueados;
    }

    public void setGruposBloqueados(ArrayList<Integer> gruposBloqueados) {
        this.gruposBloqueados = gruposBloqueados;
    }

    public void setCalendario(int calendario) {
        this.calendario = calendario;
    }

    public int getCalendario() {
        return this.calendario;
    }

    //Getters y setters




}
package nucleo;

import android.view.View;

import java.io.File;
import java.io.FileOutputStream;

public class ExportadorVistaPNG implements ExportadorVista
{
    public FileOutputStream exportar(String nombre, File extern, View view) {
        return null;
    }
}
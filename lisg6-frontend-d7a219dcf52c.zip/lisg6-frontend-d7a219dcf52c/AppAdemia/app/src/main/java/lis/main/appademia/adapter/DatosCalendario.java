package lis.main.appademia.adapter;

import com.alamkanak.weekview.WeekViewDisplayable;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Encargada de gestionar el conjunto de eventos a visualizar en los tres
 * calendarios Mensual, Semanal y Diario y a exportar en ICS, CSV o PDF.
 *
 * La interficie EventsDatabase se emplea en la libreria alamkanak/Android-
 * Week-View para los calendarios semanal y diario.
 *
 */
public class DatosCalendario implements EventsDatabase {
    private ArrayList<DatosEvento> eventosCalendario;

    public DatosCalendario() {
        this.eventosCalendario = new ArrayList<DatosEvento>();
    }

    public DatosCalendario(ArrayList<DatosEvento> eventosCalendario) {
        this.eventosCalendario = eventosCalendario;
    }

    public ArrayList<DatosEvento> getEventos() {
        return eventosCalendario;
    }

    @Override
    public List<WeekViewDisplayable<DatosEvento>> getEventsInRange(Calendar startDate, Calendar endDate) {
        List<WeekViewDisplayable<DatosEvento>> eventosDelRango = new ArrayList<>();
        for (DatosEvento i : eventosCalendario) {
            if (i.getFechaInicio().getTimeInMillis() > startDate.getTimeInMillis()) {
                if (i.getFechaFin().getTimeInMillis() < endDate.getTimeInMillis()) {
                    eventosDelRango.add(i);
                }
            }
        }
        return eventosDelRango;
    }

    @Override
    public void addDatosEvento(DatosEvento evento) {
        if (eventosCalendario.contains(evento)) {
            return;
        } else {
            for (DatosEvento i : eventosCalendario) {
                if (evento.getId().equals(i.getId())) return;
            }
        }
        eventosCalendario.add(evento);

    }

    public boolean editarEvento(DatosEvento antiguo, DatosEvento nuevo){
        if (eliminarDatosEvento(antiguo)){
            addDatosEvento(nuevo);
            return true;
        }
        return false;
    }

    public boolean eliminarDatosEvento(DatosEvento evento) {
        for (DatosEvento i : eventosCalendario) {
            if (evento.getId().equals(i.getId())){
                eventosCalendario.remove(i);
                return true;
            }
        }
        return false;
    }

}

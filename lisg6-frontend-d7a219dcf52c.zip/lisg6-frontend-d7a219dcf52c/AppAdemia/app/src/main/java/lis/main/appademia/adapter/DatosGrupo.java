package lis.main.appademia.adapter;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

import nucleo.Evento;
import nucleo.Grupo;

/**
 * Encargada de gestionar los datos de los Grupos en ListaGrupos, de controlar
 * el estado de su Checkbox para ver si fueron seleccionados por el usuario y
 * de devolver la lista de eventos.
 *
 * El Parcelable permite compartir un array de instancias de esta clase a
 * través de un Intent.
 */
public class DatosGrupo implements Parcelable {

    private String nombreGrupo;
    private String categoria;
    private String actividad;
    private boolean checked;
    private ArrayList<DatosEvento> eventos;

    public DatosGrupo(Grupo grupo, String categoria, String actividad){
        this.nombreGrupo = grupo.getNombreGrupo();
        this.categoria = categoria;
        this.actividad = categoria;
        this.checked = false;
        this.eventos = new ArrayList<DatosEvento>();
        for (Evento i : grupo.getEventos()){
            this.eventos.add(new DatosEvento(i, nombreGrupo, categoria, actividad));
        }
    }

    //GETTERS AND SETTERS
    public String getNombre() {
        return nombreGrupo;
    }

    public void setNombre(String nombre) {
        this.nombreGrupo = nombre;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean check) {
        this.checked = check;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getActividad() {
        return actividad;
    }

    public void setActividad(String actividad) {
        this.actividad = actividad;
    }

    public ArrayList<DatosEvento> getEventos(){
        return eventos;
    }

    public int getNumeroEventos(){
        if (eventos==null){
            return 0;
        }
        return eventos.size();
    }


    //PARCELABLE
    protected DatosGrupo(Parcel in) {
        nombreGrupo = in.readString();
        categoria = in.readString();
        actividad = in.readString();
        checked = in.readByte() != 0;
        eventos = new ArrayList<DatosEvento>();
        in.readTypedList(eventos, DatosEvento.CREATOR);
    }

    public static final Creator<DatosGrupo> CREATOR = new Creator<DatosGrupo>() {
        @Override
        public DatosGrupo createFromParcel(Parcel in) {
            return new DatosGrupo(in);
        }

        @Override
        public DatosGrupo[] newArray(int size) {
            return new DatosGrupo[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nombreGrupo);
        dest.writeString(categoria);
        dest.writeString(actividad);
        dest.writeByte((byte) (checked ? 1 : 0));
        dest.writeTypedList(eventos);
    }
}

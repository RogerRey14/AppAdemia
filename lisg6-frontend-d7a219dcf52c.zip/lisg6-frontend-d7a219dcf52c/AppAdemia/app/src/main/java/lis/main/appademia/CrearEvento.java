package lis.main.appademia;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.ArrayList;
import java.util.Calendar;

public class CrearEvento extends AppCompatActivity implements View.OnClickListener {

    Button bcrearEvento, bfecha, bhoraInicial, bhoraFinal;
    EditText descripcion, localizacion;
    TextView tfecha,thoraInicial, thoraFinal, error;
    RelativeLayout definirGrupo;
    Spinner spinActividad, spinGrupo;
    RadioButton si, no;

    Calendar horaInicio, horaFinal;
    ArrayList<String> listaActividades, listaGrupos;
    int posAct, posGrupo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_evento);
        setTitle(getText(R.string.crearEvento).toString());

        bcrearEvento = (Button) findViewById(R.id.ButtonEvento);
        descripcion = (EditText) findViewById(R.id.descripcionEvento);
        localizacion = (EditText) findViewById(R.id.localEvento);
        bfecha = (Button) findViewById(R.id.ButtonFecha);
        bhoraInicial = (Button) findViewById(R.id.ButtonHora);
        bhoraFinal = (Button) findViewById(R.id.ButtonHoraFinal2);
        tfecha = (TextView) findViewById(R.id.textViewFecha2);
        thoraInicial = (TextView) findViewById(R.id.textViewHora2);
        thoraFinal = (TextView) findViewById(R.id.textViewHoraFinal);
        error = (TextView) findViewById(R.id.errorText);

        definirGrupo = (RelativeLayout) findViewById(R.id.ElegirGrupo);
        spinActividad = (Spinner) findViewById(R.id.desplegableActividad);
        spinGrupo = (Spinner) findViewById(R.id.desplegableGrupo);
        si = (RadioButton) findViewById(R.id.si);
        no = (RadioButton) findViewById(R.id.no);

        horaInicio = Calendar.getInstance();
        horaFinal = Calendar.getInstance();

        bfecha.setOnClickListener(this);
        bhoraInicial.setOnClickListener(this);
        bhoraFinal.setOnClickListener(this);

        posAct = 0;
        posGrupo = 0;

        if (!AppAdemia.getInstance().esModerador()){
            definirGrupo.setVisibility(View.GONE);
        } else {
            listaActividades = AppAdemia.getInstance().getActividadesModeradas();

            ArrayAdapter<String> adapterAct = new ArrayAdapter<>(this,
                    android.R.layout.simple_spinner_item, listaActividades);
            adapterAct.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinActividad.setAdapter(adapterAct);

            actualizarListaGrupo();
        }

        bcrearEvento.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                error.setVisibility(View.GONE);
                if(crearEvento()) {
                    Intent intent = new Intent(CrearEvento.this, CalendarioSemanal.class);
                    intent.putExtra("Hoy", horaInicio);
                    startActivity(intent);
                    finish();
                } else {
                    error.setVisibility(View.VISIBLE);
                }
            }
        });

        spinActividad.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                posAct = position;
                actualizarListaGrupo();
            }
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        spinGrupo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                posGrupo = position;
            }
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public void onClick(View v) {
        if (v==bfecha) {
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,R.style.PickerColor,
                    new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                            tfecha.setText(dayOfMonth +"/"+ (month+1) + "/"+ year);
                            horaInicio.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                            horaInicio.set(Calendar.MONTH, month);
                            horaInicio.set(Calendar.YEAR, year);
                            horaFinal.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                            horaFinal.set(Calendar.MONTH, month);
                            horaFinal.set(Calendar.YEAR, year);
                        }
                    }, horaInicio.get(Calendar.YEAR), horaInicio.get(Calendar.MONTH), horaInicio.get(Calendar.DAY_OF_MONTH));
            datePickerDialog.show();
        }

        if (v==bhoraInicial) {
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,R.style.PickerColor,
                    new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                            thoraInicial.setText(hourOfDay + ":" + (minute < 10 ? "0" : "") + minute);
                            horaInicio.set(Calendar.HOUR_OF_DAY, hourOfDay);
                            horaInicio.set(Calendar.MINUTE, minute);
                        }
                    }, horaInicio.get(Calendar.HOUR_OF_DAY), horaInicio.get(Calendar.MINUTE),false);
            timePickerDialog.show();

        }

        if (v==bhoraFinal) {
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,R.style.PickerColor,
                    new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                            thoraFinal.setText(hourOfDay + ":" + (minute < 10 ? "0" : "") + minute);
                            horaFinal.set(Calendar.HOUR_OF_DAY, hourOfDay);
                            horaFinal.set(Calendar.MINUTE, minute-1);
                        }
                    }, horaFinal.get(Calendar.HOUR_OF_DAY), horaFinal.get(Calendar.MINUTE),false);
            timePickerDialog.show();
        }
    }

    private boolean crearEvento(){
        String laDescripcion = descripcion.getText().toString();
        String elLugar = localizacion.getText().toString();
        if (laDescripcion.isEmpty()){
            setError(R.string.sinDescripcion);
        } else if (elLugar.isEmpty()) {
            setError(R.string.sinLugar);
        } else if (tfecha.getText().toString().equals("")){
            setError(R.string.sinFecha);
        } else if (thoraInicial.getText().toString().equals("")){
            setError(R.string.sinHoraInicio);
        } else if (thoraFinal.getText().toString().equals("")) {
            setError(R.string.sinHoraFinal);
        } else if (horaInicio.getTimeInMillis() > horaFinal.getTimeInMillis()){
            setError(R.string.finalAntesInicio);
        } else if (horaInicio.getTimeInMillis()+300000 > horaFinal.getTimeInMillis()){
            setError(R.string.cincoMinutos);
        } else {
            setError(R.string.eventoError);
            return AppAdemia.getInstance().crearEvento(laDescripcion, elLugar, horaInicio, horaFinal, posAct, posGrupo);
        }
        return false;
    }

    private void setError(int msg){
        error.setText(getText(msg).toString());
    }

    private void actualizarListaGrupo(){
        listaGrupos = AppAdemia.getInstance().getGruposModerados(posAct);
        posGrupo = 0;

        ArrayAdapter<String> adapterGrupo = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, listaGrupos);
        adapterGrupo.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinGrupo.setAdapter(adapterGrupo);
    }
}

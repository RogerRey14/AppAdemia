package lis.main.appademia;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class PreguntasFrecuentes extends AppCompatActivity {

    TextView pregunta1, pregunta2, pregunta3, pregunta4, respuesta1, respuesta2, respuesta3, respuesta4;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preguntas_frecuentes);

        pregunta1 = (TextView) findViewById(R.id.pregunta1);
        pregunta2 = (TextView) findViewById(R.id.pregunta2);
        pregunta3 = (TextView) findViewById(R.id.pregunta3);
        pregunta4 = (TextView) findViewById(R.id.pregunta4);
        respuesta1 = (TextView) findViewById(R.id.respuesta1);
        respuesta2 = (TextView) findViewById(R.id.respuesta2);
        respuesta3 = (TextView) findViewById(R.id.respuesta3);
        respuesta4 = (TextView) findViewById(R.id.respuesta4);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}

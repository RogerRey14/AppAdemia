package lis.main.appademia;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

import lis.main.appademia.adapter.DatosEvento;
import nucleo.Nota;

public class ListaNotas extends AppCompatActivity {

    RecyclerView recyclerView;

    DatosEvento evento;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notas);

        Toolbar toolbar = findViewById(R.id.toolbarEvento);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Intent intent = getIntent();
        evento = (DatosEvento) intent.getParcelableExtra("Evento");
        if (evento == null) {
            System.out.println("NO HAY EVENTO EN LISTANOTAS");
            Intent myIntent = new Intent(this, CalendarioSemanal.class);
            myIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(myIntent);
            finish();
            return;
        }


        try{
            System.out.println("recibidas notas " + evento.getNotas());
        } catch (NullPointerException e){
            e.printStackTrace();
        }

        System.out.println("EVENTO EN LISTANOTAS ES " + evento.getDescripcion());

        recyclerView = findViewById(R.id.recyclerViewNotas);

        LinearLayoutManager mLinearLayoutManager = new LinearLayoutManager(ListaNotas.this,
                LinearLayoutManager.VERTICAL, false);

        recyclerView.addItemDecoration(new DividerItemDecoration(ListaNotas.this,
                DividerItemDecoration.VERTICAL));

        recyclerView.setLayoutManager(mLinearLayoutManager);

        ArrayList<Nota> notas = new ArrayList<>();
//        notas.add(new Nota("x","titulo","texto",
//                new Date(Calendar.getInstance().getTimeInMillis()), new Time(Calendar.getInstance().getTimeInMillis()),
//                Integer.parseInt(evento.getId()), true, 0));
        try {
            notas.addAll(evento.getNotas());
        } catch(NullPointerException e){
            e.printStackTrace();
        }
        AdapterNota mAdapterNota = new AdapterNota(ListaNotas.this, notas);
        recyclerView.setAdapter(mAdapterNota);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_nota,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.anadirNota) {
            Intent intent1 = new Intent(ListaNotas.this, CrearNota.class);
            intent1.putExtra("Evento", evento);
            startActivity(intent1);
        }

        return super.onOptionsItemSelected(item);
    }

    private class AdapterNota extends RecyclerView.Adapter<HolderNota> {
        private ArrayList<Nota> notas;
        private Context mContext;

        public AdapterNota(Context mContext, ArrayList<Nota> notas) {
            this.mContext = mContext;
            this.notas = notas;
        }

        @NonNull
        @Override
        public HolderNota onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_notificacion_item, parent, false);
            return new HolderNota(view);

        }

        @Override
        public void onBindViewHolder(HolderNota holder, int position) {
            holder.mSender.setText(notas.get(position).getID());
            holder.mEmailTitle.setText(notas.get(position).getTitulo());
            holder.mEmailDetails.setText(notas.get(position).getTexto());
            holder.mEmailTime.setText(notas.get(position).getFecha().toString());

            //Pone colores random al icono
            Random mRandom = new Random();
            final int color = Color.argb(255, mRandom.nextInt(256), mRandom.nextInt(256),
                    mRandom.nextInt(256));
            ((GradientDrawable) holder.mIcon.getBackground()).setColor(color);
        }

        @Override
        public int getItemCount() {
            return notas.size();
        }
    }

    private class HolderNota extends RecyclerView.ViewHolder {

        RelativeLayout mLayout;
        TextView mIcon;
        TextView mSender;
        TextView mEmailTitle;
        TextView mEmailDetails;
        TextView mEmailTime;

        public HolderNota(@NonNull View itemView) {
            super(itemView);
            mLayout = itemView.findViewById(R.id.notificacionLayout);
            mIcon = itemView.findViewById(R.id.tvIcon);
            mSender = itemView.findViewById(R.id.tvEmailSender);
            mEmailTitle = itemView.findViewById(R.id.tvEmailTitle);
            mEmailDetails = itemView.findViewById(R.id.tvEmailDetails);
            mEmailTime = itemView.findViewById(R.id.tvEmailTime);
        }
    }

}
package lis.main.appademia;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Random;

import nucleo.Notificacion;

public class AdapterNotificacion extends RecyclerView.Adapter<HolderNotificacion> {


    private List<Notificacion> mDatumNotificacions;
    private Context mContext;

    public AdapterNotificacion(Context mContext, List<Notificacion> mDatumNotificacions) {
        this.mContext = mContext;
        this.mDatumNotificacions = mDatumNotificacions;
    }

    @NonNull
    @Override
    public HolderNotificacion onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_notificacion_item, parent, false);
        return new HolderNotificacion(view);

    }

    @Override
    public void onBindViewHolder(HolderNotificacion holder, int position) {

        holder.mSender.setText(mDatumNotificacions.get(position).getCreador());
        holder.mEmailTitle.setText(mDatumNotificacions.get(position).getTitulo());
        holder.mEmailDetails.setText(mDatumNotificacions.get(position).getTexto());
        holder.mEmailTime.setText(mDatumNotificacions.get(position).getFecha().toString());

        //Pone colores random al icono
        Random mRandom = new Random();
        final int color = Color.argb(255, mRandom.nextInt(256), mRandom.nextInt(256),
                mRandom.nextInt(256));
        ((GradientDrawable) holder.mIcon.getBackground()).setColor(color);

        holder.mLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mIntent = new Intent(mContext, DetalleNotificacion.class);
                mIntent.putExtra("sender", holder.mSender.getText().toString());
                mIntent.putExtra("title", holder.mEmailTitle.getText().toString());
                mIntent.putExtra("details", holder.mEmailDetails.getText().toString());
                mIntent.putExtra("time", holder.mEmailTime.getText().toString());
                mIntent.putExtra("icon", holder.mIcon.getText().toString());
                mIntent.putExtra("colorIcon", color);
                mContext.startActivity(mIntent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return mDatumNotificacions.size();
    }
}

class HolderNotificacion extends RecyclerView.ViewHolder {

    RelativeLayout mLayout;
    TextView mIcon;
    TextView mSender;
    TextView mEmailTitle;
    TextView mEmailDetails;
    TextView mEmailTime;


    public HolderNotificacion(@NonNull View itemView) {
        super(itemView);

        mLayout = itemView.findViewById(R.id.notificacionLayout);
        mIcon = itemView.findViewById(R.id.tvIcon);
        mSender = itemView.findViewById(R.id.tvEmailSender);
        mEmailTitle = itemView.findViewById(R.id.tvEmailTitle);
        mEmailDetails = itemView.findViewById(R.id.tvEmailDetails);
        mEmailTime = itemView.findViewById(R.id.tvEmailTime);
    }
}

package lis.main.appademia.adapter;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.io.Serializable;
import java.util.ArrayList;

import nucleo.Actividad;
import nucleo.Categoria;

/**
 * Encargada de gestionar las actividades hijas de Niveles, padres de
 * Categorias y abuelas de Grupos. Usada en ListaActividad.
 *
 * El Parcelable permite compartir un array de instancias de esta clase a
 * través de un Intent.
 */
public class DatosActividad implements Serializable, Parcelable {

    private String nombreActividad;
    private String descripcion;
    private String ID;
    private boolean checked;        //Para checkbox de ListaActividades
    private int numero_categorias;   //Para Lista de Grupos
    private int numero_grupos;
    private ArrayList<DatosCategoria> categorias;
    private ArrayList<DatosGrupo> grupos;

    public DatosActividad(String nombre){
        this.nombreActividad = nombre;
        this.checked = false;
        this.descripcion = nombre;
        this.categorias = new ArrayList<DatosCategoria>();
        this.grupos = new ArrayList<DatosGrupo>();
    }

    public DatosActividad(Actividad actividad){
        this.nombreActividad = actividad.getNombre();
        this.checked = false;
        this.descripcion = actividad.getDescripcion();
        this.ID = actividad.getID();
        this.categorias = new ArrayList<DatosCategoria>();
        this.grupos = new ArrayList<DatosGrupo>();
        for (Categoria i : actividad.getCategorias()){
            DatosCategoria datosCategoria = new DatosCategoria(i, nombreActividad);
            categorias.add(datosCategoria);
            grupos.addAll(datosCategoria.getGrupos());
        }

        this.numero_categorias=categorias.size();
        this.numero_grupos=grupos.size();
        this.numero_grupos=0;
    }

    @NonNull
    @Override
    public String toString(){
        return nombreActividad;
    }

    public String getNombreActividad() {
        return nombreActividad;
    }

    public void setNombreActividad(String nombreActividad) {
        this.nombreActividad = nombreActividad;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean isChecked() {
        return checked;
    }
    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public ArrayList<DatosCategoria> getCategorias() {
        return categorias;
    }

    public void setGrupos(){
        numero_grupos = 0;
        for (DatosCategoria i : categorias){
            numero_grupos += i.getNumeroGrupos();
        }
    }

    public int getNumero_grupos(){
        numero_grupos = 0;
        for(DatosCategoria i : categorias){
            numero_grupos += i.getGrupos().size();
        }
        return numero_grupos;
    }

    public int getNumero_categorias(){
        numero_categorias = categorias.size();
        return numero_categorias;
    }

    //PARCELABLE
    protected DatosActividad(Parcel in) {
        this.nombreActividad = in.readString();
        this.descripcion = in.readString();
        this.checked = in.readByte() != 0;
        this.categorias = new ArrayList<DatosCategoria>();
        in.readTypedList(categorias, DatosCategoria.CREATOR);
        this.grupos = new ArrayList<DatosGrupo>();
        in.readTypedList(grupos, DatosGrupo.CREATOR);
    }

    public static final Creator<DatosActividad> CREATOR = new Creator<DatosActividad>() {
        @Override
        public DatosActividad createFromParcel(Parcel in) {
            return new DatosActividad(in);
        }

        @Override
        public DatosActividad[] newArray(int size) {
            return new DatosActividad[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nombreActividad);
        dest.writeString(descripcion);
        dest.writeByte((byte) (checked ? 1 : 0));
        dest.writeTypedList(categorias);
        dest.writeTypedList(grupos);
    }

}

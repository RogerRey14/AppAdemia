package lis.main.appademia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import nucleo.Usuario;

public class Login extends AppCompatActivity {

    Button iniciarSesion, registrarse;
    EditText correo, password;
    TextView error;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        iniciarSesion = (Button) findViewById(R.id.iniciarSesion);
        registrarse = (Button) findViewById(R.id.registrarse);
        correo = (EditText) findViewById(R.id.campoCorreo);
        password = (EditText) findViewById(R.id.campoPass);
        error = (TextView) findViewById(R.id.errorText);

        iniciarSesion.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                error.setVisibility(View.GONE);
                try {
                    if (iniciarLaSesion()){
                        Intent intent = new Intent(Login.this, CalendarioSemanal.class);
                        startActivity(intent);
                        finish();
                    } else {
                        error.setVisibility(View.VISIBLE);
                    }
                } catch (ExecutionException | InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        registrarse.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(Login.this, Registro.class);
                startActivity(intent);
                finish();
            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private boolean iniciarLaSesion() throws ExecutionException, InterruptedException {
        String elCorreo = correo.getText().toString();
        String laPassword = password.getText().toString();
        if (elCorreo.isEmpty() || !isEmailValid(elCorreo) || elCorreo.length() > 255){
            setError(R.string.sinCorreo);
        } else if (laPassword.isEmpty() || laPassword.length() > 255){
            setError(R.string.sinPassword);
        } else {
            switch (AppAdemia.getInstance().iniciarSesion(elCorreo, laPassword)) {
                case 200:
                    return true;
                case 401:
                    setError(R.string.credenciales);
                    break;
                case 423:
                    setError(R.string.usuarioBloqueado);
                    break;
                default:
                    setError(R.string.loginError);
                    break;
            }
        }
        return false;
    }

    private void setError(int msg){
        error.setText(getText(msg).toString());
    }

    public static boolean isEmailValid(String email) {
        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

}
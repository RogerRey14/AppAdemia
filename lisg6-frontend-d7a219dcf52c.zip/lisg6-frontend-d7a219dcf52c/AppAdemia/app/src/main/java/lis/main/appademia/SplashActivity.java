package lis.main.appademia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        AppAdemia.getInstance().setAppContext(this);
        AppAdemia.getInstance().cargarBaseDeDatos(this);                         //COMENTA ESTA LINEA PARA NO CARGAR LA BBDD local
        AppAdemia.getInstance().setIdioma("es");
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent=new Intent(SplashActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }, 1500);
    }

}

package lis.main.appademia;

public class DataNotificacion {

    private String mSender;
    private String mTitle;
    private String mDetails;
    private String mTime;

    public DataNotificacion(String mSender, String mTitle, String mDetails, String mTime) {
        this.mSender = mSender;
        this.mDetails = mDetails;
        this.mTitle = mTitle;
        this.mTime = mTime;
    }

    public String getmSender() {

        return mSender;
    }

    public String getmTitle() {
        return mTitle;
    }

    public String getmDetails() {

        return mDetails;
    }

    public String getmTime()
    {
        return mTime;
    }
}

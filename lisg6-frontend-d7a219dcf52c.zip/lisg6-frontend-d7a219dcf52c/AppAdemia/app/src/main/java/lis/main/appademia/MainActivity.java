package lis.main.appademia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity
{
    Button login, invitado, registrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login = (Button) findViewById(R.id.iniciarSesion);
        invitado = (Button) findViewById(R.id.accederInvitado);
        registrar = (Button) findViewById(R.id.registrarse);

        login.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent myIntent = new Intent(MainActivity.this, Login.class);
                MainActivity.this.startActivity(myIntent);
            }
        });

        invitado.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                AppAdemia.getInstance().accesoInvitado();
                Intent myIntent = new Intent(MainActivity.this, CalendarioSemanal.class);
                MainActivity.this.startActivity(myIntent);
            }
        });

        registrar.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent myIntent = new Intent(MainActivity.this, Registro.class);
                MainActivity.this.startActivity(myIntent);
            }
        });
    }

}

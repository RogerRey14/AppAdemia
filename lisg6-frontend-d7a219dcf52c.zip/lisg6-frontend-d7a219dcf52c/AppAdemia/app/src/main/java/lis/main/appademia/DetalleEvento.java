package lis.main.appademia;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;

import lis.main.appademia.adapter.DatosEvento;

public class DetalleEvento extends AppCompatActivity implements DialogSuscribirse.DialogSuscribirseListener {

    DatosEvento evento;
    Button bsuscribirse, bnotas;
    TextView nombreActividad, grupo, categoria, nombre, lugar, fechaInicio
            , horaInicio, fechaFinal, horaFinal, descripcion, moderadores;
    RelativeLayout franjaActividad;

    String passwordGrupo;
    boolean suscritoAGrupo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_evento);

        Toolbar toolbar = findViewById(R.id.toolbarEvento);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        franjaActividad = (RelativeLayout) findViewById(R.id.FranjaActividad);
        bsuscribirse = (Button) findViewById(R.id.ButtonSuscribirse);
        bnotas = (Button) findViewById(R.id.buttonNotas);

        nombreActividad = (TextView) findViewById(R.id.NombreActividad);
        grupo = (TextView) findViewById(R.id.Campo1b);
        categoria = (TextView) findViewById(R.id.Campo1d);
//        nombre = (TextView) findViewById(R.id.Campo2b);
        descripcion = (TextView) findViewById(R.id.Campo3b);
        lugar = (TextView) findViewById(R.id.Campo4b);
        fechaInicio = (TextView) findViewById(R.id.Campo5b);
        horaInicio = (TextView) findViewById(R.id.Campo6b);
        //fechaFinal = (TextView) findViewById(R.id.Campo6d);
        horaFinal = (TextView) findViewById(R.id.Campo6d);
        moderadores = (TextView) findViewById(R.id.Campo7b);

        Intent intent = getIntent();
        evento = (DatosEvento) intent.getParcelableExtra("Evento");
        if (evento == null) {
            Intent myIntent = new Intent(this, CalendarioSemanal.class);
            myIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(myIntent);
            finish();
            return;
        } else {
            toolbar.setTitle(getText(R.string.evento) + " " + evento.getId());
            setTitle(getText(R.string.evento));
            franjaActividad.setBackgroundColor(evento.getColor());
            nombreActividad.setText(evento.getActividad());
            grupo.setText(evento.getGrupo());
            categoria.setText(evento.getCategoria());
            //      nombre.setText("Evento con id " + String.valueOf(evento.getId()));
            descripcion.setText(evento.getDescripcion());
            lugar.setText(evento.getLugar());
            fechaInicio.setText(evento.getDiaInicio());
            horaInicio.setText(evento.getHoraInicio());
            horaFinal.setText(evento.getHoraFinal());
        }

        if (AppAdemia.getInstance().getIDUsuario().equals("0")){
            bsuscribirse.setVisibility(View.GONE);
            bnotas.setVisibility(View.GONE);
        } else {

            botonSuscripcion();

            bsuscribirse.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    suscripcionGrupo();
                }
            });

            bnotas.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(DetalleEvento.this, ListaNotas.class);
                    intent.putExtra("Evento", evento);
                    startActivity(intent);
                }
            });
        }
    }

    public void openDialog() {
        DialogSuscribirse dialogSuscribirse = new DialogSuscribirse();
        dialogSuscribirse.show(getSupportFragmentManager(), "Suscripcion dialog");
    }

    @Override
    public void applyTexts(String password, boolean suscrito) {
        passwordGrupo = password;
        suscripcionGrupo();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if(AppAdemia.getInstance().moderaActividad(evento)){
            getMenuInflater().inflate(R.menu.menu_evento,menu);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
       int id = item.getItemId();

        if (id == R.id.editarEvento) {
            Intent intent2 = new Intent(DetalleEvento.this, EditarEvento.class);
            intent2.putExtra("Evento", evento);
            startActivity(intent2);
        }
        return super.onOptionsItemSelected(item);
    }


    private void suscripcionGrupo(){
        if (!AppAdemia.getInstance().suscripcionGrupo(evento, passwordGrupo)){
            openDialog();
            if (!passwordGrupo.equals("")){
                Toast.makeText(DetalleEvento.this, getText(R.string.badPassword), Toast.LENGTH_SHORT).show();
            }
            passwordGrupo = "";
        }
        botonSuscripcion();
    }

    private void botonSuscripcion(){
        passwordGrupo = "";
        suscritoAGrupo = AppAdemia.getInstance().suscritoAGrupo(evento);
        if (suscritoAGrupo) {
            bsuscribirse.setBackgroundColor(getResources().getColor(R.color.Eliminar));
            bsuscribirse.setText(getResources().getString(R.string.desuscribirse));
        } else {
            bsuscribirse.setBackgroundColor(getResources().getColor(R.color.fondoBoton));
            bsuscribirse.setText(getResources().getString(R.string.suscribirse));
        }
    }
}

package lis.main.appademia;

import android.content.Intent;
import android.os.Bundle;

import com.applandeo.materialcalendarview.CalendarView;
import com.applandeo.materialcalendarview.EventDay;
import com.applandeo.materialcalendarview.exceptions.OutOfDateRangeException;
import com.applandeo.materialcalendarview.listeners.OnDayClickListener;

import java.util.ArrayList;
import java.util.Calendar;

import lis.main.appademia.adapter.DatosEvento;

public class CalendarioMensual extends MenuCalendario {

    Calendar diaSeleccionado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendario_mensual);

        setContexto(CalendarioMensual.this);

        CalendarView calendarApp = (CalendarView) findViewById(R.id.calendarViewApp);

        //Setting a date
        Intent intent = getIntent();
        diaSeleccionado = (Calendar) intent.getSerializableExtra("Hoy");
        if (diaSeleccionado != null) {
            try {
                calendarApp.setDate(diaSeleccionado);
            } catch (OutOfDateRangeException e) {
                e.printStackTrace();
            }
        } else {
            diaSeleccionado = Calendar.getInstance();
        }

        //ADDING EVENTS
        ArrayList<EventDay> eventos = new ArrayList<EventDay>();
        ArrayList<DatosEvento> eventosCal = new ArrayList<DatosEvento>(AppAdemia.getInstance().getDatosCalendario().getEventos());
        for (DatosEvento i : eventosCal){
            Calendar fechaInicio = i.getFechaInicio();
            Calendar fechaFinal = i.getFechaFin();
            Calendar fecha = Calendar.getInstance();
            fecha.set(Calendar.DAY_OF_YEAR, fechaInicio.get(Calendar.DAY_OF_YEAR));
            eventos.add(new EventDay(fecha, R.drawable.ic_event));

            int x = 0;
            while(x < (fechaFinal.get(Calendar.DAY_OF_YEAR) - fecha.get(Calendar.DAY_OF_YEAR))){
                x += 1;
                Calendar test = Calendar.getInstance();
                test.set(Calendar.DAY_OF_YEAR, fecha.get(Calendar.DAY_OF_YEAR)+x);
                eventos.add(new EventDay(test, R.drawable.ic_event));
            }
        }
        calendarApp.setEvents(eventos);

        //Minimum and maxim
        Calendar min = Calendar.getInstance();
        min.set(2019, 0, 1);
        Calendar max = Calendar.getInstance();
        max.set(2020, 11, 31);
        calendarApp.setMinimumDate(min);
        calendarApp.setMaximumDate(max);

        //Clic en dia
        calendarApp.setOnDayClickListener(new OnDayClickListener() {
            @Override
            public void onDayClick(EventDay eventDay) {
                Calendar clickedDayCalendar = eventDay.getCalendar();
                if (clickedDayCalendar.getTime().equals(diaSeleccionado.getTime())) {
                    gotoCalendarioDiario();
                } else {
                    diaSeleccionado = clickedDayCalendar;
                    setHoy(diaSeleccionado);
                }

            }
        });

        floatingAction();
        ponerTitulo(getText(R.string.calendarioMensual).toString());
    }

    @Override
    public void gotoSiguienteCalendario(){
        setHoy(diaSeleccionado);
        gotoCalendarioSemanal();
    }

    @Override
    public void gotoEsteCalendario(){
        setHoy(diaSeleccionado);
        gotoCalendarioMensual();
    }
}

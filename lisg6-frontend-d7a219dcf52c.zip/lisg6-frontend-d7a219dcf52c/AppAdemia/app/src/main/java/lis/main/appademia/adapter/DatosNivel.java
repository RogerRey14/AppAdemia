package lis.main.appademia.adapter;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

import nucleo.Actividad;
import nucleo.Componente;
import nucleo.NivelOrganizativo;

/**
 * Encargada de gestionar los Niveles Organizativos a mostrar en la
 * ListaNiveles y a devolver sus subniveles y actividades.
 *
 * El Parcelable permite compartir un array de instancias de esta clase a
 * través de un Intent.
 */
public class DatosNivel implements Parcelable {

    public String nombre;
    public List<DatosNivel> listaSubNiveles;
    public List<DatosActividad> listaDatosActividades;
    public NivelOrganizativo nivel;

    public DatosNivel(String nombre){
        this.nombre = nombre;
        this.listaSubNiveles = new ArrayList<DatosNivel>();
        this.listaDatosActividades = new ArrayList<DatosActividad>();
    }

    public DatosNivel(NivelOrganizativo nivel){
        this.nombre = nivel.getNombre();
        this.listaSubNiveles = new ArrayList<DatosNivel>();
        this.listaDatosActividades = new ArrayList<DatosActividad>();
        setComponentesHijos(nivel.getHijos());
        this.nivel = nivel;
    }

    private void setComponentesHijos(ArrayList<Componente> hijos){
        this.listaSubNiveles = new ArrayList<DatosNivel>();
        listaSubNiveles.add(new DatosNivel(""));
        this.listaDatosActividades = new ArrayList<DatosActividad>();
        for (Componente i : hijos){
            if (i.getClass() == NivelOrganizativo.class){
                NivelOrganizativo nivel = (NivelOrganizativo) i;
                listaSubNiveles.add(new DatosNivel(nivel));
            } else if (i.getClass() == Actividad.class){
                Actividad act = (Actividad) i;
                listaDatosActividades.add(new DatosActividad(act));
            }
        }
    }

    @NonNull
    @Override
    public String toString(){
        return nombre;
    }

    public List<DatosActividad> getActividades() {
        return listaDatosActividades;
    }

    public List<DatosNivel> getSubNiveles() {
        return listaSubNiveles;
    }

    public int getNumeroActividades() { return listaDatosActividades.size(); }

    public int getNumeroSubNiveles() { return listaSubNiveles.size() - 1; }

    //PARCELABLE
    protected DatosNivel(Parcel in) {
        this.nombre = in.readString();
        this.listaSubNiveles = new ArrayList<DatosNivel>();
        in.readTypedList(listaSubNiveles, DatosNivel.CREATOR);
        this.listaDatosActividades = new ArrayList<DatosActividad>();
        in.readTypedList(listaDatosActividades, DatosActividad.CREATOR);
    }

    public static final Creator<DatosNivel> CREATOR = new Creator<DatosNivel>() {
        @Override
        public DatosNivel createFromParcel(Parcel in) {
            return new DatosNivel(in);
        }

        @Override
        public DatosNivel[] newArray(int size) {
            return new DatosNivel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nombre);
        dest.writeTypedList(listaSubNiveles);
        dest.writeTypedList(listaDatosActividades);
    }

}

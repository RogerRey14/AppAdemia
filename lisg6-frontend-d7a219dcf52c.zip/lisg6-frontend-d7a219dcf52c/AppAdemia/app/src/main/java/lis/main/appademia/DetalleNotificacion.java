package lis.main.appademia;

import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetalleNotificacion extends AppCompatActivity {

    TextView mIcon;
    TextView mSender;
    TextView mEmailTitle;
    TextView mEmailDetails;
    TextView mEmailTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_notificacion);
        setTitle(getText(R.string.notificacion).toString());

        mIcon = findViewById(R.id.tvIcon2);
        mSender = findViewById(R.id.tvEmailSender2);
        mEmailTitle = findViewById(R.id.tvEmailTitle2);
        mEmailDetails = findViewById(R.id.tvEmailDetails2);
        mEmailTime = findViewById(R.id.tvEmailTime2);

        Bundle mBundle = getIntent().getExtras();
        if (mBundle != null) {
            mIcon.setText(mBundle.getString("icon"));
            ((GradientDrawable) mIcon.getBackground()).setColor(mBundle.getInt("colorIcon"));
            mSender.setText(mBundle.getString("sender"));
            mEmailTitle.setText(mBundle.getString("title"));
            mEmailDetails.setText(mBundle.getString("details"));
            mEmailTime.setText(mBundle.getString("time"));
        }

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}

package lis.main.appademia;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class VistaDescargar extends AppCompatActivity {

    RadioGroup radio;
    EditText nombreFichero;
    TextView errorFichero, pickedFormat;
    Spinner rango;
    Button bGenerar;

    RelativeLayout activityExport;

    int posicionRango;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_export);

        radio = (RadioGroup) findViewById(R.id.campoFormato);
        nombreFichero = (EditText) findViewById(R.id.nombreExportar);
        pickedFormat = (TextView) findViewById(R.id.pickedFormat);
        rango = (Spinner) findViewById(R.id.seleccionVista);
        bGenerar = (Button) findViewById(R.id.botonExportar);
        errorFichero = (TextView) findViewById(R.id.errorText);
        activityExport = (RelativeLayout) findViewById(R.id.activity_export);

        radio.setVisibility(View.GONE);

        bGenerar.setText(R.string.Descargar);
        pickedFormat.setText(R.string.puntoPDF);

        posicionRango = 0;
        ArrayList<String> objetos = new ArrayList<String>();
        objetos.add(getText(R.string.Todo).toString());
        objetos.add(getText(R.string.esteMes).toString());
        objetos.add(getText(R.string.estaSemana).toString());
        objetos.add(getText(R.string.esteDia).toString());

        ArrayAdapter<String> lista = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, objetos);
        lista.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        rango.setAdapter(lista);

        bGenerar.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                if(nombreFichero.getText().toString().equals("")){
                    errorFichero.setVisibility(View.VISIBLE);
                } else {
                    errorFichero.setVisibility(View.GONE);
                    System.out.println("Nombre es " + nombreFichero.getText()  + " y posi " + posicionRango);
                    AppAdemia.getInstance().Descargar(nombreFichero.getText().toString(), posicionRango,
                            //LayoutInflater.from(VistaDescargar.this).inflate(R.layout.activity_calendario_semanal, null));
                            activityExport);
                    Toast.makeText(VistaDescargar.this, "¡Fichero creado!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        rango.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                posicionRango = pos;
            }
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}

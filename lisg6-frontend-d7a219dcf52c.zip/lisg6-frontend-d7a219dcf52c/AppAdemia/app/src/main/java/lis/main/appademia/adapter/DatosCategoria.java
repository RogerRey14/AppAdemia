package lis.main.appademia.adapter;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

import nucleo.Categoria;
import nucleo.Grupo;

/**
 * Encargada de gestionar las Categorias con la lista de Grupos en ListaGrupos
 *
 * El Parcelable permite compartir un array de instancias de esta clase a
 * través de un Intent.
 */
public class DatosCategoria implements Parcelable {

    private String nombreCategoria;
    private String actividad;
    private ArrayList<DatosGrupo> grupos;

    public DatosCategoria(Categoria categoria, String actividad){
        this.nombreCategoria = categoria.getNombreCategoria();
        this.actividad = actividad;
        this.grupos = new ArrayList<DatosGrupo>();
        for (Grupo i : categoria.getGrupos()){
            grupos.add(new DatosGrupo(i, nombreCategoria, actividad));
        }
    }

    public String getNombre() {
        return nombreCategoria;
    }

    public void setNombre(String nombre) {
        this.nombreCategoria = nombre;
    }

    public String getActividad() {
        return actividad;
    }

    public void setActividad(String actividad) {
        this.actividad = actividad;
    }

    public ArrayList<DatosGrupo> getGrupos() {
        return grupos;
    }

    public int getNumeroGrupos() {
        return grupos.size();
    }

    //PARCELABLE
    protected DatosCategoria(Parcel in) {
        this.nombreCategoria = in.readString();
        this.actividad = in.readString();
        this.grupos = new ArrayList<DatosGrupo>();
        in.readTypedList(grupos, DatosGrupo.CREATOR);
    }

    public static final Creator<DatosCategoria> CREATOR = new Creator<DatosCategoria>() {
        @Override
        public DatosCategoria createFromParcel(Parcel in) {
            return new DatosCategoria(in);
        }

        @Override
        public DatosCategoria[] newArray(int size) {
            return new DatosCategoria[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nombreCategoria);
        dest.writeString(actividad);
        dest.writeTypedList(grupos);
    }
}

package lis.main.appademia;

import android.content.Intent;
import android.graphics.RectF;
import android.os.Bundle;
import androidx.annotation.NonNull;

import com.alamkanak.weekview.DateTimeInterpreter;
import com.alamkanak.weekview.EmptyViewLongPressListener;
import com.alamkanak.weekview.EventClickListener;
import com.alamkanak.weekview.MonthChangeListener;
import com.alamkanak.weekview.WeekView;
import com.alamkanak.weekview.WeekViewDisplayable;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import lis.main.appademia.adapter.DatosCalendario;
import lis.main.appademia.adapter.DatosEvento;
import lis.main.appademia.adapter.EventsDatabase;

/**
 * Vista encargada del Calendario Semanal. Implementa la libreria
 * alamkanak/Android-Week-View que permite la visualización de eventos en tablas
 * por dia y hora. El layout de esta clase determina que se visualizen solo 5
 * dias. Recibe los eventos desde la clase AppAdemia. Extiende desde la clase
 * MenuCalendario con las funcionalidades comunes en los tres calendarios, como
 * la toolbar y el botón flotante.
 *
 * This is a base activity which contains week view and all the codes necessary to initialize the
 * week view.
 * Created by Raquib-ul-Alam Kanak on 1/3/2014.
 * Website: http://alamkanak.github.io
 */
public class CalendarioSemanal extends MenuCalendario
        implements EventClickListener<DatosEvento>, MonthChangeListener<DatosEvento>,
        EmptyViewLongPressListener {

    private WeekView<DatosEvento> mWeekView;
    private EventsDatabase mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendario_semanal);
        setContexto(CalendarioSemanal.this);
        mDatabase = AppAdemia.getInstance().getDatosCalendario();
        if (mDatabase == null){
            mDatabase = new DatosCalendario();
            AppAdemia.getInstance().setDatosCalendario((DatosCalendario) mDatabase);
        }
        mWeekView = findViewById(R.id.weekView);

        Intent intent = getIntent();
        setHoy((Calendar) intent.getSerializableExtra("Hoy"));
        if (getHoy() != null) {
            mWeekView.goToDate(getHoy());
        } else {
            setHoy(Calendar.getInstance());
        }
        mWeekView.goToHour(7);
        mWeekView.setOnEventClickListener(this);
        mWeekView.setMonthChangeListener(this);
        mWeekView.setEmptyViewLongPressListener(this);
        setupDateTimeInterpreter();

        floatingAction();
        ponerTitulo(getText(R.string.calendarioSemanal).toString());
    }

    /**
     * Set up a date time interpreter which will show short date values when in week view and long
     * date values otherwise.
     */
    private void setupDateTimeInterpreter() {
        mWeekView.setDateTimeInterpreter(new DateTimeInterpreter() {
            String idioma = AppAdemia.getInstance().getIdioma();

            SimpleDateFormat weekdayNameFormat = new SimpleDateFormat("EEE", new Locale(
                    idioma,"ES"));

            SimpleDateFormat format = new SimpleDateFormat(" d/M", new Locale(
                    idioma,"ES"));

            @Override
            public String interpretDate(Calendar date) {
                String weekday = weekdayNameFormat.format(date.getTime());
                if (mWeekView.getNumberOfVisibleDays() == 7) {
                    weekday = String.valueOf(weekday.charAt(0));
                }
                if(idioma.equals("en")){
                    format = new SimpleDateFormat(" M/d", new Locale(idioma,"US"));
                }
                return weekday.toUpperCase() + format.format(date.getTime());
            }

            @Override
            public String interpretTime(int hour) {
                return hour > 11 ? (hour - 12) + " PM" : (hour == 0 ? "12 aM" : hour + " AM");
            }
        });
    }

    @NonNull
    @Override
    public List<WeekViewDisplayable<DatosEvento>> onMonthChange(@NonNull Calendar startDate,
                                                                @NonNull Calendar endDate) {
        return mDatabase.getEventsInRange(startDate, endDate);
    }

    //Clic en evento: Ver Detalle de Evento
    @Override
    public void onEventClick(@NonNull DatosEvento event, @NonNull RectF eventRect) {
        gotoDetalleEvento(event);
    }

    //Mantener pulsado lugar vacio: Volver a Vista mensual
    @Override
    public void onEmptyViewLongPress(@NonNull Calendar time) {
        setHoy(time);
        gotoCalendarioDiario();
    }

    @Override
    public void gotoSiguienteCalendario(){
        setHoy(mWeekView.getFirstVisibleDay());
        gotoCalendarioDiario();
    }

    @Override
    public void gotoEsteCalendario(){
        setHoy(mWeekView.getFirstVisibleDay());
        gotoCalendarioSemanal();
    }
}

package lis.main.appademia;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

import lis.main.appademia.adapter.DatosEvento;

public class CrearNota extends AppCompatActivity{

    Button bcrearNota;
    EditText nombre, descripcion;
    TextView error;
    RadioButton si, no;

    DatosEvento evento;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crear_nota);
        setTitle(getText(R.string.nuevaNota).toString());

        bcrearNota = (Button) findViewById(R.id.ButtonNota);
        nombre = (EditText) findViewById(R.id.nombreNota);
        descripcion = (EditText) findViewById(R.id.descripcionNota);
        error = (TextView) findViewById(R.id.errorText);
        si = (RadioButton) findViewById(R.id.si);
        no = (RadioButton) findViewById(R.id.no);

        Intent intent = getIntent();
        evento = (DatosEvento) intent.getParcelableExtra("Evento");
        if (evento == null) {
            Intent myIntent = new Intent(this, CalendarioSemanal.class);
            myIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(myIntent);
            finish();
            return;
        }

        bcrearNota.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                error.setVisibility(View.GONE);
                if(crearNota()) {

                    try{
                        System.out.println(evento.getNotas());
                    } catch (NullPointerException e){
                        e.printStackTrace();
                    }

                    Intent intent = new Intent(CrearNota.this, ListaNotas.class);
                    intent.putExtra("Evento", evento);
                    startActivity(intent);
                    finish();
                } else {
                    error.setVisibility(View.VISIBLE);
                }
            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private boolean crearNota(){
        String elTitulo = nombre.getText().toString();
        String laDescripcion = descripcion.getText().toString();
        if (elTitulo.isEmpty()){
            setError(R.string.sinTitulo);
        } else if (laDescripcion.isEmpty()) {
            setError(R.string.sinTexto);
        } else {
            setError(R.string.loginError);
            boolean compartir = false;
            if(si.isChecked()) compartir = true;
            return AppAdemia.getInstance().crearNota(elTitulo, laDescripcion, compartir, evento);
        }
        return false;
    }

    private void setError(int msg){
        error.setText(getText(msg).toString());
    }
}

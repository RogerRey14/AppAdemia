package lis.main.appademia;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.view.View;

import androidx.core.app.NotificationCompat;

import java.sql.Date;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.ExecutionException;

import lis.main.appademia.adapter.DatosCalendario;
import lis.main.appademia.adapter.DatosEvento;
import lis.main.appademia.adapter.DatosNivel;
import nucleo.Actividad;
import nucleo.BaseDatosLocal;
import nucleo.Categoria;
import nucleo.Componente;
import nucleo.Evento;
import nucleo.Grupo;
import nucleo.NivelOrganizativo;
import nucleo.Nota;
import nucleo.Exportador;
import nucleo.ExportadorCSV;
import nucleo.ExportadorICS;
import nucleo.ExportadorVistaPDF;
import nucleo.Notificacion;
import nucleo.Usuario;

/**
 * Clase que implementa el patrón Singleton para crear una única instancia
 * durante la ejecución de la aplicación. Guarda valores comunes globales,
 * como el Calendario activo, el Usuario y la conexión con la BBDD local.
 */
public class AppAdemia {

    /**
     * Instancia que permite gesionar el patrón Singleton
     */
    private static AppAdemia INSTANCE = null;
    private AppAdemia() {}

    /**
     * Contexto de la aplicación
     */
    private Context appContext;

    /**
     * Objeto con el array de eventos descargados a mostrar en los tres calendarios
     */
    private DatosCalendario datosCalendario;

    /**
     * Base de datos local con los objetos del núcleo
     */
    private BaseDatosLocal bdlocal;

    /**
     * Usuario activo en la aplicación
     */
    private Usuario miUsuario;

    /**
     * Guarda la estructura de niveles organizativos (escuelas, asigntauras y grupos)
     */
    private ArrayList<DatosNivel> listaDatosNiveles;

    /**
     * Array de nombres de actividades para asignar colores según su posición
     */
    private ArrayList<String> actividades = new ArrayList<String>();

    /**
     * Guarda el tag con el idioma seleccionado, por defecto el castellano
     */
    private String idioma = "es";

    /**
     * Formato para las fechas (castellano y català)
     */
    private SimpleDateFormat formatoDia = new SimpleDateFormat("yyyy-MM-dd", new Locale(getIdioma()));

    /**
     * Formato para las fechas (castellano y català)
     */
    private SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm:ss", new Locale(getIdioma()));

    /**
     * Guarda la lista de actividades moderadas
     */
    private ArrayList<Actividad> actividadesModeradas;

    /**
     * Guarda la lista de nombres de las actividades moderadas
     */
    private ArrayList<String> nombresActividadesModeradas = new ArrayList<>();

    /**
     * Guarda la lista de grupos de las actividades moderadas
     */
    private ArrayList<Grupo> gruposModerados;


    /**
     * Método para recibir la instáncia única de la clase
     * @return AppAdemia como instáncia única
     */
    public static AppAdemia getInstance(){
        if (INSTANCE == null) createInstance();
        return INSTANCE;
    }

    /**
     * Constructor de la instáncia del Singleton
     */
    private synchronized static void createInstance() {
        if (INSTANCE == null) {
            INSTANCE = new AppAdemia();
        }
    }

    /**
     * Configura el contexto de la aplicación
     * @param context con un contexto del AppCompatActivity
     */
    public void setAppContext(Context context){
        appContext = context;
    }

    /**
     * Carga los eventos sincronizados con la base de datos y devuelve el calendario
     * @return DatosCalendario con el calendario de eventos
     */
    public DatosCalendario getDatosCalendario() {
        cargarEventos();
        return datosCalendario;
    }

    /**
     * En caso de que no haya un calendario establecido, recibe uno
     * @param datosCalendario con el calendario nuevo
     */
    public void setDatosCalendario(DatosCalendario datosCalendario) {
        this.datosCalendario = datosCalendario;
    }

    /**
     * Recibe un calendario y lo guarda como calendario activo.
     * Notifica a la base de datos local de todos los eventos presentes y registra
     * su relación con el usuario.
     *
     * @param datosCalendario con el calendario nuevo
     * @param context con el contexto de la aplicación
     */
    public void setDatosCalendario(DatosCalendario datosCalendario, Context context) {
        if(datosCalendario != null){
            setAppContext(context);
            setBdlocal(new BaseDatosLocal(context, "DB_prueba", null, 1));
            ArrayList<Integer> ids = new ArrayList<Integer>();
            ArrayList<DatosEvento> eventos = datosCalendario.getEventos();
            for(DatosEvento i : eventos){
                ids.add(Integer.parseInt(i.getId()));
            }

            try {
                bdlocal.guardarCalendarioUsuario(ids, miUsuario.getCalendario());
            } catch (ExecutionException | InterruptedException e){
                e.printStackTrace();
            }
        }
        this.datosCalendario = datosCalendario;
    }

    /**
     * Devuelve la base de datos local
     * @return BaseDatosLocal con la base de datos local
     */
    public BaseDatosLocal getBdlocal() {
        return bdlocal;
    }

    /**
     * Guarda el objeto con el que esta clase interactuará para leer de la
     * base de datos local.
     * @param bdlocal con la nueva base de datos
     */
    public void setBdlocal(BaseDatosLocal bdlocal) {
        this.bdlocal = bdlocal;
    }

    /**
     * Carga la base de datos local con la información de la base de datos
     * remota a través de la API por primera vez.
     * @param context con el contexto de la Aplicación
     */
    public void cargarBaseDeDatos(Context context){
        setAppContext(context);
        setBdlocal(new BaseDatosLocal(context, "DB_prueba", null, 1));
        bdlocal.resetTablas();
        try {
            bdlocal.setDatosReales();
            setListaDatosNiveles();
        } catch (ParseException | ExecutionException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    /**
     * Guarda la lista de Niveles organizativos a partir de los datos de
     * la base de datos.
     */
    public void setListaDatosNiveles(){
        listaDatosNiveles = new ArrayList<>();
        try {
            Usuario usuario = new Usuario();
            if(getMiUsuario() != null && !getMiUsuario().getID().equals("0"))
            {
                usuario = getMiUsuario();
            }
            else
            {
                usuario.setID("0");
                usuario.setGruposSuscritos(new ArrayList<Integer>());
            }

            for (Componente i : bdlocal.getNivelesOrganizativos(usuario)) {
                if (i.getClass() == NivelOrganizativo.class) {
                    NivelOrganizativo nivel = (NivelOrganizativo) i;
                    listaDatosNiveles.add(new DatosNivel(nivel));
                }
            }
        } catch (ExecutionException | InterruptedException | ParseException e){
            e.printStackTrace();
        }
    }

    /**
     * Devuelve la lista de niveles una vez cargada desde la bdlocal.
     * @return listaDatosNiveles con el array de niveles.
     */
    public  ArrayList<DatosNivel> getListaDatosNiveles(){
        setListaDatosNiveles();
        return listaDatosNiveles;
    }

    /**
     * Carga la lista de eventos seleccionados o creados por el usuario.
     * Implementa la sincronización en la base de datos local.
     * También crea el calendario activo con los eventos descargados.
     */
    public void cargarEventos(){
        try {
            ArrayList<Evento> eventos = bdlocal.recuperarCalendarioUsuario(miUsuario.getCalendario());
            ArrayList<DatosEvento> datosEventos = new ArrayList<DatosEvento>();

            for (Evento i : eventos){
                datosEventos.add(new DatosEvento(i,
                        bdlocal.getGrupoDeEvento(Integer.parseInt(i.getID())).getNombreGrupo(),
                        bdlocal.getCategoriaDeEvento(Integer.parseInt(i.getID())).getNombreCategoria(),
                        bdlocal.getActividadDeEvento(Integer.parseInt(i.getID())).getNombre()));
            }

            DatosCalendario dc = new DatosCalendario(datosEventos);
            setDatosCalendario(dc);

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    /**
     * Guarda los nombres de las actividades en un array y les asigna un color
     * según el orden
     * @param actividad con el nombre de la actividad
     * @return el número RGB del color
     */
    public int getColorActividad(String actividad){
        if (!actividades.contains(actividad)){
            actividades.add(actividad);
        }
        return getColor(actividades.indexOf(actividad));
    }

    /**
     * A partir de una posición devuelve un color.
     * @param posicion con el entero
     * @return el número RGB del color
     */
    public int getColor(int posicion){
        ArrayList<Integer> colores = new ArrayList<>();
        colores.add(appContext.getResources().getColor(R.color.EventoRojo));
        colores.add(appContext.getResources().getColor(R.color.EventoAzul));
        colores.add(appContext.getResources().getColor(R.color.color0201));
        colores.add(appContext.getResources().getColor(R.color.color0202));
        colores.add(appContext.getResources().getColor(R.color.color0203));
        colores.add(appContext.getResources().getColor(R.color.VerdeClaro));
        colores.add(appContext.getResources().getColor(R.color.EventoVerde));
        colores.add(appContext.getResources().getColor(R.color.EventoRosa));
        colores.add(appContext.getResources().getColor(R.color.blue));
        colores.add(appContext.getResources().getColor(R.color.colorAccent));
        colores.add(appContext.getResources().getColor(R.color.white));
        return colores.get(posicion%10);
    }


    /**
     * Devuelve los datos del usuario identificado.
     * @return Usuario con la instáncia del usuario.
     */
    public Usuario getMiUsuario() {
        return miUsuario;
    }

    /**
     * Guarda los datos del usuario identificado.
     * @param miUsuario con la instáncia del usuario.
     */
    public void setMiUsuario(Usuario miUsuario) {
        this.miUsuario = miUsuario;
    }

    /**
     * Devuelve el id del usuario activo.
     * @return el String con la ID del usuario
     */
    public String getIDUsuario(){
        return miUsuario.getID();
    }


    /**
     * Inicia la sesión con un correo y contraseña. La API le devolverá
     * el resultado según las credenciales:
     *      401 = credenciales erroneas
     *      423 = usuario bloqueado
     *      200 = login correcto
     * @param email con el correo
     * @param password con la contraseña
     * @return int con el resultado
     */
	public int iniciarSesion(String email, String password){
	    try {
            int resultado = bdlocal.iniciarSesion(email, password);
            if (resultado==200){
                setMiUsuario(bdlocal.getMiUsuario());
                cargarBaseDeDatos(appContext);
                cargarEventos();
                obtenerNotificaciones();
            }

            return resultado;
        } catch (ExecutionException | InterruptedException | ParseException e){
	        e.printStackTrace();
        }
	    return 0;
    }

    /**
     * Cierra la sesión del usuario y reinicia las variables.
     */
    public void cerrarSesion(){
        miUsuario = null;
        datosCalendario = null;
        gruposModerados = null;
    }

    /**
     * Accede con una cuenta de usuario invitado
     */
    public void accesoInvitado(){
        Usuario invitado = new Usuario(false);
	    ArrayList<Integer> act = new ArrayList<Integer>();
	    act.add(0);
	    invitado.setActividadesModeradas(act);
	    setMiUsuario(invitado);
	    cargarEventos();
    }

    /**
     * Envia los datos para crear un nuevo usuario a la base de datos
     * @param nombre con el nombre
     * @param email con el correo
     * @param password con la contraseña
     * @return booleano con el resultado true / false
     * @throws ExecutionException
     * @throws InterruptedException
     */
    public boolean registro(String nombre, String email, String password) throws ExecutionException, InterruptedException {
        return bdlocal.registrarUsuario(email, password, nombre);
    }

    /**
     * Contesta si el usuario activo modera una actividad a aparte de "Eventos Personales"
     * @return booleano con un true / false
     */
    public boolean esModerador(){
	    return miUsuario.getActividadesModeradas().size() > 1;
    }

    /**
     * Devuelve la lista de nombres de las actividades moderadas para
     * el desplegable del menú de Crear Evento
     * @return
     */
    public ArrayList<String> getActividadesModeradas(){
        actividadesModeradas = new ArrayList<>();
        nombresActividadesModeradas = new ArrayList<>();
        nombresActividadesModeradas.add("Evento personal");
        for (Integer x : miUsuario.getActividadesModeradas()) {
            for (DatosNivel i : listaDatosNiveles) {
                recorrerRamas(i.nivel, x);
            }
        }
        return nombresActividadesModeradas;
    }

    /**
     * Recorre el arbol de niveles organizativos para extraer las actividades
     * moderadas por el usuario.
     * @param i con el componente nivel o actividad
     * @param id con el id de la actividad moderada que se busca
     */
    public void recorrerRamas(Componente i, Integer id){
        for (Componente j : i.getHijos()) {
            if (j.getClass().equals(Actividad.class) && j.getID().equals(id.toString())) {
                nombresActividadesModeradas.add(j.getNombre());
                actividadesModeradas.add((Actividad) j);
            }
            for(Componente k : j.getHijos()){
                recorrerRamas(k, id);
            }
        }
    }

    /**
     * Devuelve la lista de grupos moderados por el usuario de una actividad concreta
     * @param pos con la elección de la actividad de la lista de actividades moderadas.
     * @return la lista con el nombre de los grupos
     */
    public ArrayList<String> getGruposModerados(int pos){
        gruposModerados = new ArrayList<>();
        ArrayList<String> gModerados = new ArrayList<>();
        if (pos == 0){
            gModerados.add("Evento personal");
        } else {
            for (Categoria c : actividadesModeradas.get(pos - 1).getCategorias()) {
                gruposModerados.addAll(c.getGrupos());
                for (Grupo g : c.getGrupos()) {
                    gModerados.add(c.getNombreCategoria() + ": " + g.getNombreGrupo());
                }
            }
        }
        return gModerados;
    }

    /**
     * Devuelve el id del grupo de la posición de la lista de grupos moderados.
     * @param pos con la posición a la lista
     * @return el id del grupo
     */
    public int getIDGrupoPosicion(int pos){
        if (actividadesModeradas == null || actividadesModeradas.size() < 1){
            return 0;
        }
        if (gruposModerados == null || gruposModerados.size()<1){
            return 0;
        }
        return Integer.parseInt(gruposModerados.get(pos).getID());
    }

    /**
     * Responde si el usuario modera la actividad de un evento concreto.
     * @param evento con el evento a consultar.
     * @return booleano con la respuesta true / false.
     */
    public boolean moderaActividad(DatosEvento evento){
        Actividad actividad = bdlocal.getActividadDeEvento(Integer.parseInt(evento.getId()));
        if (miUsuario.getActividadesModeradas().contains(Integer.parseInt(actividad.getID()))){
            return true;
        }
        return false;
    }

    /**
     * Responde si el usuario activo está suscrito al grupo de un evento.
     * @param evento con el evento a consultar.
     * @return booleano con el true / false.
     */
    public boolean suscritoAGrupo(DatosEvento evento){
	    Grupo grupo = bdlocal.getGrupoDeEvento(Integer.parseInt(evento.getId()));
	    if (miUsuario.getGruposSuscritos().contains(Integer.parseInt(grupo.getID()))){
	        return true;
        }
	    return false;
    }

    /**
     * Suscribe o desuscribe al usuario activo al grupo de un evento concreto.
     * @param evento con el evento perteneciente a un grupo al que quiere suscribirse.
     * @param password con la contraseña, si se necesita.
     * @return booleano con el resultado true / false.
     */
    public boolean suscripcionGrupo(DatosEvento evento, String password){
        Grupo grupo = bdlocal.getGrupoDeEvento(Integer.parseInt(evento.getId()));
	    try {
	        if(suscritoAGrupo(evento)) {
                bdlocal.desuscribirseAGrupo(Integer.parseInt(grupo.getID()), miUsuario);
            } else {
                if (grupo.getContrasena()!=null && !grupo.getContrasena().equals("") && !grupo.getContrasena().equals(password)){
                    return false;
                } else {
                    bdlocal.setMiUsuario(miUsuario);
                    bdlocal.suscribirseAGrupo(Integer.parseInt(grupo.getID()), miUsuario);
                    setMiUsuario(bdlocal.getMiUsuario());
                }
            }
        } catch (ExecutionException | InterruptedException e){
	        e.printStackTrace();
        }

	    return true;
    }

    /**
     * Crea un evento en la base de datos y lo añade al calendario actual.
     * @param descripcion con la descripción del evento
     * @param lugar del evento
     * @param horaInicio del evento
     * @param horaFinal del evento
     * @param posAct posición de la actividad a la que añadir el evento de la
     *               lista de actividades moderadas
     * @param posGrupo posición del grupo al que añadir el evento de la lista
     *                 de grupos moderados
     * @return booleano con true / false
     */
    public boolean crearEvento(String descripcion, String lugar,
                               Calendar horaInicio, Calendar horaFinal, int posAct, int posGrupo){
        int ID = 0;
        try {
            ID = bdlocal.addEvento((posAct==0) ? 0 : getIDGrupoPosicion(posGrupo), descripcion, lugar, formatoDia.format(horaInicio.getTime()),
                    formatoDia.format(horaFinal.getTime()), formatoHora.format(horaInicio.getTime()),
                    formatoHora.format(horaFinal.getTime()), 0, (miUsuario.getCalendario()),
                    getMiUsuario(), true);

        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        if (posAct != 0){
            DatosEvento nuevoEvento = new DatosEvento(String.valueOf(ID),
                    "", descripcion, bdlocal.getActividadDeEvento(ID).getNombre(),
                    bdlocal.getCategoriaDeEvento(ID).getNombreCategoria(),
                    bdlocal.getGrupoDeEvento(ID).getNombreGrupo(),
                    horaInicio, horaFinal, lugar, getColorActividad(bdlocal.getActividadDeEvento(ID).getNombre()), false);
            getDatosCalendario().addDatosEvento(nuevoEvento);
        } else {
            DatosEvento nuevoEvento = new DatosEvento(String.valueOf(ID),
                    "", descripcion, "Evento personal", "Evento de " + miUsuario.getNombre(), "Evento personal",
                    horaInicio, horaFinal, lugar, getColorActividad("Evento personal"), false);
            getDatosCalendario().addDatosEvento(nuevoEvento);
        }

        return true;
    }

    /**
     * Edita los datos del evento de un grupo que modere el usuario activo.
     * @param evento con el evento a editar
     * @param descripcion con la nueva descripción
     * @param lugar con el nuevo lugar
     * @param horaInicio con la nueva hora
     * @param horaFinal con la nueva hora final
     * @return booleano con true / false
     */
    public boolean editarEvento(DatosEvento evento, String descripcion, String lugar,
                                Calendar horaInicio, Calendar horaFinal){
        DatosEvento eventoEditado = new DatosEvento(evento.getId(), "", descripcion,
                evento.getActividad(), evento.getCategoria(), evento.getGrupo(), horaInicio, horaFinal,
                lugar, getColorActividad(evento.getActividad()), false);

        try {
            bdlocal.modificarEvento(Integer.parseInt(evento.getId()),Integer.parseInt(bdlocal.getGrupoDeEvento(Integer.parseInt(evento.getId())).getID()),
                    descripcion, lugar, formatoDia.format(eventoEditado.getFechaInicio().getTime()),
                    formatoDia.format(eventoEditado.getFechaFin().getTime()), formatoHora.format(eventoEditado.getFechaInicio().getTime()),
                    formatoHora.format(eventoEditado.getFechaFin().getTime()), 0,
                    getIDUsuario(), true);


        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        return getDatosCalendario().editarEvento(evento,eventoEditado);
    }

    /**
     * Elimina un evento del calendario y de la base de datos.
     * @param evento con el evento a eliminar
     * @return boolelano con el resultado
     */
    public boolean eliminarEvento(DatosEvento evento){
        try {
            bdlocal.eliminarEvento(Integer.parseInt(evento.getId()),Integer
                    .parseInt(bdlocal.getGrupoDeEvento(Integer.parseInt(evento.getId())).getID()),getIDUsuario(), true);
            getDatosCalendario().eliminarDatosEvento(evento);
        } catch (ExecutionException | InterruptedException e){
            e.printStackTrace();
        }
        return true;
    }

    /**
     * Crea una nueva nota para un evento y lo guarda en la base de datos.
     * @param nombre con el titulo de la nota
     * @param descripcion con el texto de la nota
     * @param compartir será true si se desea hacer pública la nota
     * @param evento con el evento donde incorporar la nota.
     * @return booleano con el resultado.
     */
    public boolean crearNota(String nombre, String descripcion, boolean compartir, DatosEvento evento) {
        try {
            Calendar hoy = Calendar.getInstance();
            bdlocal.addNota(nombre, descripcion, formatoDia.format(hoy.getTime()),
                    formatoHora.format(hoy.getTime()), (compartir) ? 1 : 0,
                    Integer.parseInt(miUsuario.getID()), Integer.parseInt(evento.getId()));


            ArrayList<Nota> notas = new ArrayList<Nota>();
            if (evento.getNotas() != null)
                notas.addAll(evento.getNotas());
            Nota mNota = new Nota("x", nombre, descripcion,
                    new Date(Calendar.getInstance().getTimeInMillis()),
                    new Time(Calendar.getInstance().getTimeInMillis()),
                    Integer.parseInt(evento.getId()),
                    compartir, Integer.parseInt(miUsuario.getID()));
            notas.add(mNota);
            evento.setNotas(notas);

        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
        }
        return true;
    }

    /**
     * Revisa la lista de notificaciones y crea en android las notificaciones de
     * aquellas que no han sido leidas.
     * @return lista de notificaciones.
     */
    public ArrayList<Notificacion> obtenerNotificaciones(){
        ArrayList<Notificacion> notificaciones = new ArrayList<>();
        try {
            notificaciones = bdlocal.recibirNotificaciones(miUsuario.getGruposSuscritos(),
                            Integer.parseInt(miUsuario.getID()));
        } catch (ExecutionException | InterruptedException | ParseException e){
            e.printStackTrace();
        }

        for (Notificacion i : notificaciones){
            if(!i.getLeida()){
                NotificationCompat.Builder mBuilder;
                NotificationManager mNotifyMgr = (NotificationManager) appContext.getSystemService(Context.NOTIFICATION_SERVICE);

                int icono = R.mipmap.ic_launcher;
                Intent intent = new Intent(appContext, Notificaciones.class);
                PendingIntent pendingIntent = PendingIntent.getActivity(appContext, 0,intent, 0);

                mBuilder =new NotificationCompat.Builder(appContext)
                        .setContentIntent(pendingIntent)
                        .setSmallIcon(icono)
                        .setContentTitle(i.getTitulo())
                        .setContentText(i.getTexto())
                        .setVibrate(new long[] {100, 250, 100, 500})
                        .setAutoCancel(true);
                try {
                    mNotifyMgr.notify(1, mBuilder.build());
                } catch (NullPointerException e){
                    e.printStackTrace();
                }
            }
        }

        return notificaciones;
    }

    /**
     * Exporta el calendario actual a formato ICS o CSV
     * @param nombre con el nombre del fichero
     * @param formatoICS será true en caso de que el usuario quiera un fichero ICS
     * @param pos con la opción de exportación elegida
     */
    public void Exportar(String nombre, boolean formatoICS, int pos){
        Exportador exportador;
        if (formatoICS){
            exportador = new ExportadorICS();
        } else {
            exportador = new ExportadorCSV();
        }

        exportador.exportar(nombre, appContext.getExternalFilesDir(null));
    }

    /**
     * Descargará el calendario actual en formato PDF
     * @param nombre con el nombre del fichero
     * @param pos con la modalidad a descargar el pdf
     * @param view con la vista a guardar en el pdf.
     */
    public void Descargar(String nombre, int pos, View view){
        ExportadorVistaPDF exportador = new ExportadorVistaPDF();
        exportador.exportar(nombre, appContext.getExternalFilesDir(null), view);
    }

    /**
     * Emplea la localización y internacionalización de la aplicación
     * @param idioma con el tag del nuevo idioma
     */
    public void setIdioma(String idioma){
        this.idioma = idioma;
        Locale myLocale = new Locale(idioma);
        Resources res = appContext.getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.locale = myLocale;
        res.updateConfiguration(conf, dm);
    }

    /**
     * Devuelve el tag del idioma actual
     * @return el tag del idioma
     */
    public String getIdioma(){
        return idioma;
    }
}

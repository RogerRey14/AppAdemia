package lis.main.appademia;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class VistaExportar extends AppCompatActivity {

    RadioButton opcICS, opcCSV;
    EditText nombreFichero;
    TextView errorFichero, pickedFormat;
    Spinner rango;
    Button bExportar;

    int posicionRango;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_export);

        opcICS = (RadioButton) findViewById(R.id.campoICS);
        opcCSV = (RadioButton) findViewById(R.id.campoCSV);
        nombreFichero = (EditText) findViewById(R.id.nombreExportar);
        pickedFormat = (TextView) findViewById(R.id.pickedFormat);
        rango = (Spinner) findViewById(R.id.seleccionVista);
        bExportar = (Button) findViewById(R.id.botonExportar);
        errorFichero = (TextView) findViewById(R.id.errorText);

        posicionRango = 0;
        ArrayList<String> objetos = new ArrayList<String>();
        objetos.add(getText(R.string.Todo).toString());

        ArrayAdapter<String> lista = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, objetos);
        lista.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        rango.setAdapter(lista);

        bExportar.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                boolean formatoExportar = false;
                if (opcICS.isChecked()) formatoExportar = true;
                if (opcCSV.isChecked()) formatoExportar = false;

                if(nombreFichero.getText().toString().equals("")){
                    errorFichero.setVisibility(View.VISIBLE);
                } else {
                    errorFichero.setVisibility(View.GONE);
                    System.out.println("Nombre es " + nombreFichero.getText()  + " y posi " + posicionRango + " y formato " + formatoExportar);
                    AppAdemia.getInstance().Exportar(nombreFichero.getText().toString(),
                            formatoExportar, posicionRango);
                    Toast.makeText(VistaExportar.this, "¡Fichero creado!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        rango.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                posicionRango = pos;
            }
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    public void setFormat(View v){
        if (opcICS.isChecked())
            pickedFormat.setText(R.string.puntoICS);
        if (opcCSV.isChecked())
            pickedFormat.setText(R.string.puntoCSV);
    }
}

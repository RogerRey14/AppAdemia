package lis.main.appademia;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import lis.main.appademia.adapter.DatosActividad;
import lis.main.appademia.adapter.DatosCalendario;
import lis.main.appademia.adapter.DatosCategoria;
import lis.main.appademia.adapter.DatosEvento;
import lis.main.appademia.adapter.DatosGrupo;
import lis.main.appademia.adapter.DatosNivel;

public class ListaGrupos extends AppCompatActivity {

    Button boton;
    TextView textoSeleccionado;
    ListView listViewActividades;

    ArrayList<DatosActividad> actividadesSeleccionadas;
    DatosNivel nivelSeleccionado;
    private ArrayAdapter<DatosActividad> aaAct;

    private ArrayList<DatosGrupo> gruposSeleccionados = new ArrayList<DatosGrupo>();
    int numeroGrupos = 0;

    AppCompatActivity thisContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_grupos);
        thisContext = this;

        textoSeleccionado = (TextView) findViewById(R.id.Text1);
        boton = (Button) findViewById(R.id.Button1);

        final DatosCalendario calendarioOficial = AppAdemia.getInstance().getDatosCalendario();

        Intent intent = getIntent();
        nivelSeleccionado = (DatosNivel) intent.getParcelableExtra("nivelSeleccionado");
        if (nivelSeleccionado != null) {
            setTitle(nivelSeleccionado.toString());
        } else {
            setTitle(getText(R.string.ningunNivel).toString()); }
        actividadesSeleccionadas = intent.getParcelableArrayListExtra("actividadesSeleccionadas");
        if (actividadesSeleccionadas == null) {
            actividadesSeleccionadas = new ArrayList<DatosActividad>();
        }

        listViewActividades = (ListView) this.findViewById(R.id.listaActividadesCategoriasGrupos);
        List<DatosActividad> listaDatosActividades = new ArrayList<DatosActividad>();
        aaAct = new ActividadesAdapter<DatosActividad>(this, listaDatosActividades);
        listViewActividades.setAdapter(aaAct);
        llenarListaDeActividades(actividadesSeleccionadas);

        //Flecha atrás
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        boton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                gruposSeleccionados = new ArrayList<DatosGrupo>();
                for (DatosActividad i : actividadesSeleccionadas){
                    for(DatosCategoria j : i.getCategorias()){
                        for(DatosGrupo k : j.getGrupos()){
                            if (k.isChecked()){
                                gruposSeleccionados.add(k);
                                for (DatosEvento x : k.getEventos()){
                                    calendarioOficial.addDatosEvento(x);
                                }

                            }
                        }
                    }
                }

                numeroGrupos = gruposSeleccionados.size();

                AppAdemia.getInstance().setDatosCalendario(calendarioOficial, getApplicationContext());

                Intent myIntent = new Intent(ListaGrupos.this, CalendarioSemanal.class);
                myIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |  Intent.FLAG_ACTIVITY_SINGLE_TOP);
                finishAffinity();
                ListaGrupos.this.startActivity(myIntent);
                finish();
            }
        });

    }

    private void llenarListaDeActividades(ArrayList<DatosActividad> actividades){
        aaAct.clear();
        for (DatosActividad i : actividades) {
            aaAct.add(i);
        }
        aaAct.notifyDataSetChanged();
    }


    public class ActividadesAdapter<C> extends ArrayAdapter<DatosActividad> {
        List<DatosActividad> listaActividades;

        public ActividadesAdapter(@NonNull Context context, @NonNull List<DatosActividad> nuevasActividades) {
            super(context, R.layout.row_lista_grupos_actividad, nuevasActividades);
            this.listaActividades = nuevasActividades;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup container) {
            DatosActividad fila = getItem(position);
            int num_grupos = fila.getNumero_grupos();
            int num_categorias = fila.getNumero_categorias();

            if (convertView == null) {
                convertView = getLayoutInflater().inflate(R.layout.row_lista_grupos_actividad,
                        container, false);
            }
            RelativeLayout relative = (RelativeLayout) convertView.findViewById(R.id.row_lista_grupos_actividad);

            TextView nombre = (TextView) convertView.findViewById(R.id.nombre_actividad);
            nombre.setText(fila.getDescripcion());

            ListView listaCategorias = (ListView) convertView.findViewById(R.id.listaCategorias);
            ArrayList<DatosCategoria> listaDeCategorias = new ArrayList<>();
            ArrayAdapter<DatosCategoria> catAdapt = new CategoriasAdapter<DatosCategoria>(this.getContext(), listaDeCategorias);
            listaCategorias.setAdapter(catAdapt);
            catAdapt.clear();
            for (DatosCategoria i : fila.getCategorias()) {
                catAdapt.add(i);
            }
            catAdapt.notifyDataSetChanged();

            relative.getLayoutParams().height = cambiarAlturaFila(num_grupos,
                    num_categorias, 1, getContext());
            return convertView;
        }
    }

    public class CategoriasAdapter<C> extends ArrayAdapter<DatosCategoria> {
        List<DatosCategoria> listaCategorias;

        public CategoriasAdapter(@NonNull Context context, @NonNull List<DatosCategoria> nuevasCategorias) {
            super(context, R.layout.row_lista_grupos_categoria, nuevasCategorias);
            this.listaCategorias = nuevasCategorias;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup container) {
            DatosCategoria fila = getItem(position);
            int num_grupos = fila.getNumeroGrupos();

            if (convertView == null) {
                convertView = getLayoutInflater().inflate(R.layout.row_lista_grupos_categoria,
                        container, false);
            }
            RelativeLayout relative = (RelativeLayout) convertView.findViewById(R.id.row_lista_grupos_categoria);

            TextView nombre = (TextView) convertView.findViewById(R.id.nombre_categoria);
            nombre.setText(fila.getNombre());

            ListView listaGrupos = (ListView) convertView.findViewById(R.id.listaCategorias);
            ArrayList<DatosGrupo> listaDatosGrupos = new ArrayList<DatosGrupo>();
            ArrayAdapter<DatosGrupo> catAdapt = new GruposAdapter<DatosGrupo>(this.getContext(), listaDatosGrupos);
            listaGrupos.setAdapter(catAdapt);
            catAdapt.clear();

            for (DatosGrupo i : fila.getGrupos()) {
                catAdapt.add(i);
            }
            catAdapt.notifyDataSetChanged();
            relative.getLayoutParams().height = cambiarAlturaFila(num_grupos,
                    1, 0, getContext());
            return convertView;
        }
    }

    public class GruposAdapter<C> extends ArrayAdapter<DatosGrupo> {
        List<DatosGrupo> listaCategorias;

        public GruposAdapter(@NonNull Context context, @NonNull List<DatosGrupo> nuevasCategorias) {
            super(context, R.layout.row_checkbox, nuevasCategorias);
            this.listaCategorias = nuevasCategorias;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup container) {
            final DatosGrupo fila = getItem(position);
            if (convertView == null) {
                convertView = getLayoutInflater().inflate(R.layout.row_checkbox,
                        container, false);
            }
            TextView nombre = (TextView) convertView.findViewById(R.id.nombre_actividad);
            nombre.setText(fila.getNombre());

            CheckBox opcion = (CheckBox) convertView.findViewById(R.id.checkbox_actividad);
            opcion.setChecked(fila.isChecked());
            opcion.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                    CheckBox cb = (CheckBox) v;
                    fila.setChecked(cb.isChecked());
                }
            });
            return convertView;
        }
    }

    private int cambiarAlturaFila(int grupos, int categorias, int actividades, Context context){
        int altura_grupo = (int) (getResources().getDimension(R.dimen.altura_fila_grupo));
        int altura_categoria = (int) (getResources().getDimension(R.dimen.altura_fila_categoria));
        int altura_actividad = (int) (getResources().getDimension(R.dimen.altura_fila_actividad));
        int altura_padding = (int) (getResources().getDimension(R.dimen.altura_padding));
        int end = grupos * altura_grupo + categorias * altura_categoria +
                actividades * altura_actividad + categorias * altura_padding;
        return end;
    }


}

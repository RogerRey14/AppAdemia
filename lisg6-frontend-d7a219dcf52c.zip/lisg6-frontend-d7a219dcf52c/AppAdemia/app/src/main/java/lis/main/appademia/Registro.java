package lis.main.appademia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Objects;
import java.util.concurrent.ExecutionException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import nucleo.RolInvitado;

public class Registro extends AppCompatActivity {

    Button registrar;
    EditText nombre, correo, password;
    TextView error;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        registrar = (Button) findViewById(R.id.botonRegistrar);
        nombre = (EditText) findViewById(R.id.campoNombre);
        correo = (EditText) findViewById(R.id.campoCorreo);
        password = (EditText) findViewById(R.id.campoPass);
        error = (TextView) findViewById(R.id.errorText);

        registrar.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                error.setVisibility(View.GONE);
                try {
                    if (registro()){
                        Intent intent = new Intent(Registro.this, Login.class);
                        startActivity(intent);
                        finish();
                    } else {
                        error.setVisibility(View.VISIBLE);
                    }
                } catch (ExecutionException | InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private boolean registro() throws ExecutionException, InterruptedException {
        String elNombre = nombre.getText().toString();
        String elCorreo = correo.getText().toString();
        String laPassword = password.getText().toString();
        if (elNombre.isEmpty() || elNombre.length() > 255){
            setError(R.string.sinNombre);
        } else if (elCorreo.isEmpty() || !isEmailValid(elCorreo) || elCorreo.length() > 255){
            setError(R.string.sinCorreo);
        } else if (laPassword.isEmpty() || laPassword.length() > 255){
            setError(R.string.sinPassword);
        } else {
            setError(R.string.registroError);
            //Devolverá true si logra hacer el registro
            return AppAdemia.getInstance().registro(elNombre, elCorreo, laPassword);
        }
        return false;
    }

    private void setError(int msg){
        error.setText(getText(msg).toString());
    }

    private static boolean isEmailValid(String email) {
        String expression = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

}

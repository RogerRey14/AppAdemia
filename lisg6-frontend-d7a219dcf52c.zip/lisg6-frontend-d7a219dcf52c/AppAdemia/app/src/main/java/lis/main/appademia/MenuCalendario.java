package lis.main.appademia;

import android.content.Context;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.getbase.floatingactionbutton.FloatingActionButton;
import com.getbase.floatingactionbutton.FloatingActionsMenu;
import com.google.android.material.navigation.NavigationView;

import java.util.Calendar;

import lis.main.appademia.adapter.DatosEvento;

public class MenuCalendario extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private Context elContexto;
    private Calendar hoy;
    private DrawerLayout drawer;
    private Toolbar toolbar;

    public Context getContexto() {
        return elContexto;
    }

    public void setContexto(Context elContexto) {
        this.elContexto = elContexto;
    }

    public Calendar getHoy() {
        return hoy;
    }

    public void setHoy(Calendar hoy) {
        this.hoy = hoy;
    }

    public DrawerLayout getDrawer() {
        return drawer;
    }

    public void setDrawer(DrawerLayout drawer) {
        this.drawer = drawer;
    }

    public void floatingAction(){
        //Toolbar
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //NavDrawer
        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        TextView nombreUsuario = navigationView.getHeaderView(0).findViewById(R.id.nombreUsuario);
        if (AppAdemia.getInstance().getMiUsuario() != null){
            nombreUsuario.setText(AppAdemia.getInstance().getMiUsuario().getNombre());
        } else {
            nombreUsuario.setText(R.string.invitado);
        }

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        //FloatingActionMenu Code
        final FloatingActionsMenu grupoFab = (FloatingActionsMenu) findViewById(R.id.grupoFab);
        final FloatingActionButton fab1 = (FloatingActionButton) findViewById(R.id.fab1);
        final FloatingActionButton fab2 = (FloatingActionButton) findViewById(R.id.fab2);

        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ( view == findViewById(R.id.fab1)){
                    Intent intent = new Intent(elContexto, ListaNiveles.class);
                    startActivity(intent);
                }
                grupoFab.collapse();
            }
        });

        fab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ( view == findViewById(R.id.fab2)){
                    Intent intent = new Intent(elContexto, CrearEvento.class);
                    startActivity(intent);
                }
                grupoFab.collapse();
            }
        });
    }

    //Nueva vista de Calendario Diario
    public void gotoCalendarioDiario() {
        Intent myIntent = new Intent(getContexto(), CalendarioDiario.class);
        myIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        myIntent.putExtra("Hoy", hoy);
        startActivity(myIntent);
        finish();
    }

    public void gotoCalendarioSemanal(){
        Intent myIntent = new Intent(getContexto(), CalendarioSemanal.class);
        myIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        myIntent.putExtra("Hoy", hoy);
        startActivity(myIntent);
        finish();
    }


    //Nueva vista de Calendario Mensual
    public void gotoCalendarioMensual() {
        Intent myIntent = new Intent(getContexto(), CalendarioMensual.class);
        myIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        myIntent.putExtra("Hoy", hoy);
        startActivity(myIntent);
        finish();
    }

    //Nueva vista de Detalle Evento
    public void gotoDetalleEvento(@NonNull DatosEvento event) {
        Intent myIntent = new Intent(getContexto(), DetalleEvento.class);
        myIntent.putExtra("Evento", event);
        startActivity(myIntent);
    }

    public void gotoEsteCalendario() {
    }

    public void gotoSiguienteCalendario(){
    }


    //Toolbar metodos
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.vista) {
            gotoSiguienteCalendario();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    //NavDrawer methods
    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        } else {
            //super.onBackPressed();
            Intent myIntent = new Intent(getContexto(), MainActivity.class);
            myIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |  Intent.FLAG_ACTIVITY_SINGLE_TOP);
            finishAffinity();
            startActivity(myIntent);
            finish();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Intent intent;
        switch (menuItem.getItemId()) {
            case R.id.perfil:
                break;
            case R.id.Calendario:
                gotoEsteCalendario();
                break;
            case R.id.notificaciones:
                intent = new Intent(elContexto, Notificaciones.class);
                startActivity(intent);
                break;
            case R.id.informacion:
                intent = new Intent(elContexto, Informacion.class);
                startActivity(intent);
                break;
            case R.id.configuracion:
                intent = new Intent(elContexto, Configuracion.class);
                startActivity(intent);
                break;
            case R.id.descargar:
                intent = new Intent(elContexto, VistaDescargar.class);
                startActivity(intent);
                break;
            case R.id.importar:
                intent = new Intent(elContexto, VistaExportar.class);
                startActivity(intent);
                break;
            case R.id.cerrar:
                AppAdemia.getInstance().cerrarSesion();

                intent = new Intent(elContexto, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |  Intent.FLAG_ACTIVITY_SINGLE_TOP);
                finishAffinity();
                startActivity(intent);
                finish();
                break;
        }
        return true;
    }

    public void ponerTitulo(String titulo){
        toolbar.setTitle(titulo);
        setTitle(titulo);
    }

}

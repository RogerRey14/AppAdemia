package lis.main.appademia;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import lis.main.appademia.adapter.DatosNivel;
import nucleo.BaseDatosLocal;
import nucleo.Componente;
import nucleo.ConexionSQLiteHelper;
import nucleo.NivelOrganizativo;

public class ListaNiveles extends AppCompatActivity {

    Button boton;
    TextView textoNivel;
    Spinner[] desplegables = new Spinner[8];

    DatosNivel nivelSeleccionado;

    private ArrayList<DatosNivel> listaDatosNiveles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_niveles);
        setTitle(getText(R.string.listaNiveles).toString());

        nivelSeleccionado = new DatosNivel("");

        textoNivel = (TextView) findViewById(R.id.Text1);
        desplegables[0] = (Spinner) findViewById(R.id.desplegable0);
        desplegables[1] = (Spinner) findViewById(R.id.desplegable1);
        desplegables[2] = (Spinner) findViewById(R.id.desplegable2);
        desplegables[3] = (Spinner) findViewById(R.id.desplegable3);
        desplegables[4] = (Spinner) findViewById(R.id.desplegable4);
        desplegables[5] = (Spinner) findViewById(R.id.desplegable5);
        desplegables[6] = (Spinner) findViewById(R.id.desplegable6);
        desplegables[7] = (Spinner) findViewById(R.id.desplegable7);

        boton = (Button) findViewById(R.id.Button1);
        boton.setText(R.string.aceptar);
        apagarBoton();
        boton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent myIntent = new Intent(ListaNiveles.this, ListaActividades.class);
                myIntent.putExtra("nivelSeleccionado", nivelSeleccionado);
                ListaNiveles.this.startActivity(myIntent);
            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listaDatosNiveles = new ArrayList<DatosNivel>();
        listaDatosNiveles.add(new DatosNivel(""));  //Primera opción vacia.

        listaDatosNiveles.addAll(AppAdemia.getInstance().getListaDatosNiveles());

        crearDesplegable(desplegables[0], listaDatosNiveles);
        for (int i = 0; i< desplegables.length; i++){
            if(i!=0) { desplegables[i].setVisibility(View.GONE); }
            final int I = i;
            desplegables[i].setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {

                    encenderBoton();
                    if (pos == 0) {
                        if (I == 0) {
                            apagarBoton();
                        } else {
                            return;
                        }
                    }

                    nivelSeleccionado = (DatosNivel) parent.getItemAtPosition(pos);
                    textoNivel.setText(nivelSeleccionado.toString());
                    for(int j = I+1; j<desplegables.length; j++){
                        desplegables[j].setVisibility(View.GONE);
                        desplegables[j].setAdapter(null);
                    }

                    if (nivelSeleccionado.getNumeroSubNiveles() > 0) {
                        crearDesplegable(desplegables[I + 1], nivelSeleccionado.getSubNiveles());
                    }
                }
                public void onNothingSelected(AdapterView<?> arg0) {
                    // TODO Auto-generated method stub
                }
            });
        }
    }

    private void apagarBoton(){
        boton.setEnabled(false);
        boton.setBackgroundColor(getResources().getColor(R.color.fondoApagado));
    }

    private void encenderBoton(){
        boton.setEnabled(true);
        boton.setBackgroundColor(getResources().getColor(R.color.fondoBoton));
    }

    private void crearDesplegable(Spinner spin, List<DatosNivel> objetos){
        spin.setVisibility(View.VISIBLE);
        ArrayAdapter<DatosNivel> lista = new ArrayAdapter<DatosNivel>(this,
                android.R.layout.simple_spinner_item, objetos);
        lista.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(lista);
    }
}

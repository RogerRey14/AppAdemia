package lis.main.appademia;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;
import java.util.Objects;

import lis.main.appademia.adapter.DatosEvento;

public class EditarEvento extends AppCompatActivity implements View.OnClickListener, DialogEliminarEvento.EliminarEventoListener {

    DatosEvento evento;
    Button bmodificarEvento, beliminarEvento,  bfecha, bhoraInicial, bhoraFinal;
    EditText descripcion, localizacion;
    TextView tfecha,thoraInicial, thoraFinal, error;
    RadioButton si, no;

    Calendar horaInicio, horaFinal;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_evento);

        bmodificarEvento = (Button) findViewById(R.id.ButtonEvento2);
        beliminarEvento = (Button) findViewById(R.id.ButtonEventoEliminar2);
        descripcion = (EditText) findViewById(R.id.descripcionEvento2);
        localizacion = (EditText) findViewById(R.id.localEvento2);
        bfecha = (Button) findViewById(R.id.ButtonFecha2);
        bhoraInicial = (Button) findViewById(R.id.ButtonHora2);
        bhoraFinal = (Button) findViewById(R.id.ButtonHoraFinal);
        tfecha = (TextView) findViewById(R.id.textViewFecha22);
        thoraInicial = (TextView) findViewById(R.id.textViewHora22);
        thoraFinal = (TextView) findViewById(R.id.textViewHora32);
        error = (TextView) findViewById(R.id.errorText);

        si = (RadioButton) findViewById(R.id.si);
        no = (RadioButton) findViewById(R.id.no);

        bfecha.setOnClickListener(this);
        bhoraInicial.setOnClickListener(this);
        bhoraFinal.setOnClickListener(this);

        Intent intent = getIntent();
        evento = (DatosEvento) intent.getParcelableExtra("Evento");
        if (evento == null) finish();

        horaInicio = evento.getFechaInicio();
        horaFinal = evento.getFechaFin();

        descripcion.setText(evento.getDescripcion());
        localizacion.setText(evento.getLugar());
        tfecha.setText(horaInicio.get(Calendar.DAY_OF_MONTH) +"/"+
                String.valueOf(horaInicio.get(Calendar.MONTH)+1) + "/"+ horaInicio.get(Calendar.YEAR));
        thoraInicial.setText(evento.getHoraInicio());
        thoraFinal.setText(evento.getHoraFinal());

        bmodificarEvento.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                error.setVisibility(View.GONE);
                if (editarEvento()){
                    Intent intent = new Intent(EditarEvento.this, CalendarioSemanal.class);
                    intent.putExtra("Hoy", horaInicio);
                    startActivity(intent);
                    finish();
                } else {
                    error.setVisibility(View.VISIBLE);
                }

            }
        });

        beliminarEvento.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                openDialog();
            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public void onClick(View v) {
        if (v==bfecha) {
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,R.style.PickerColor,
                    new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                            tfecha.setText(dayOfMonth +"/"+ (month+1) + "/"+ year);
                            horaInicio.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                            horaInicio.set(Calendar.MONTH, month);
                            horaInicio.set(Calendar.YEAR, year);
                            horaFinal.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                            horaFinal.set(Calendar.MONTH, month);
                            horaFinal.set(Calendar.YEAR, year);
                        }
                    }, horaInicio.get(Calendar.YEAR), horaInicio.get(Calendar.MONTH), horaInicio.get(Calendar.DAY_OF_MONTH));
            datePickerDialog.show();
        }

        if (v==bhoraInicial) {
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,R.style.PickerColor,
                    new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                            thoraInicial.setText(hourOfDay + ":" + (minute < 10 ? "0" : "") + minute);
                            horaInicio.set(Calendar.HOUR_OF_DAY, hourOfDay);
                            horaInicio.set(Calendar.MINUTE, minute);
                        }
                    }, horaInicio.get(Calendar.HOUR_OF_DAY), horaInicio.get(Calendar.MINUTE),false);
            timePickerDialog.show();

        }

        if (v==bhoraFinal) {
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,R.style.PickerColor,
                    new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                            thoraFinal.setText(hourOfDay + ":" + (minute < 10 ? "0" : "") + minute);
                            horaFinal.set(Calendar.HOUR_OF_DAY, hourOfDay);
                            horaFinal.set(Calendar.MINUTE, minute-1);
                        }
                    }, horaFinal.get(Calendar.HOUR_OF_DAY), horaFinal.get(Calendar.MINUTE),false);
            timePickerDialog.show();
        }
    }

    private boolean editarEvento(){
        String laDescripcion = descripcion.getText().toString();
        String elLugar = localizacion.getText().toString();

        if (laDescripcion.isEmpty()){
            setError(R.string.sinDescripcion);
        } else if (elLugar.isEmpty()){
            setError(R.string.sinLugar);
        } else if (tfecha.getText().toString().equals("")){
            setError(R.string.sinFecha);
        } else if (thoraInicial.getText().toString().equals("")){
            setError(R.string.sinHoraInicio);
        } else if (thoraFinal.getText().toString().equals("")) {
            setError(R.string.sinHoraFinal);
        } else if (horaInicio.getTimeInMillis() > horaFinal.getTimeInMillis()){
            setError(R.string.finalAntesInicio);
        } else if (horaInicio.getTimeInMillis()+300000 > horaFinal.getTimeInMillis()){
            setError(R.string.cincoMinutos);
        } else {
            setError(R.string.eventoError);
            return AppAdemia.getInstance().editarEvento(evento, laDescripcion, elLugar,
                    horaInicio, horaFinal);
        }
        return false;
    }

    private void setError(int msg){
        error.setText(getText(msg).toString());
    }


    public void openDialog() {
        DialogEliminarEvento dialog = new DialogEliminarEvento();
        dialog.show(getSupportFragmentManager(), "delete event dialog");
    }

    @Override
    public void onYesClicked() {
        AppAdemia.getInstance().eliminarEvento(evento);
        Intent intent = new Intent(EditarEvento.this, CalendarioSemanal.class);
        startActivity(intent);
        finish();
    }
}


package lis.main.appademia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import nucleo.Notificacion;

public class Notificaciones extends AppCompatActivity {

    List<DataNotificacion> mDatumNotificacios = new ArrayList<>();
    List<Notificacion> listaNotificaciones = new ArrayList<>();
    RecyclerView mRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notification);
        setTitle(getText(R.string.notificaciones).toString());

        listaNotificaciones = AppAdemia.getInstance().obtenerNotificaciones();

        mRecyclerView = findViewById(R.id.recyclerViewNotificaciones);

        LinearLayoutManager mLinearLayoutManager = new LinearLayoutManager(Notificaciones.this,
                LinearLayoutManager.VERTICAL, false);

        mRecyclerView.addItemDecoration(new DividerItemDecoration(Notificaciones.this,
                DividerItemDecoration.VERTICAL));

        mRecyclerView.setLayoutManager(mLinearLayoutManager);

        AdapterNotificacion mAdapterNotificacion = new AdapterNotificacion(Notificaciones.this, listaNotificaciones);
        mRecyclerView.setAdapter(mAdapterNotificacion);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }
}

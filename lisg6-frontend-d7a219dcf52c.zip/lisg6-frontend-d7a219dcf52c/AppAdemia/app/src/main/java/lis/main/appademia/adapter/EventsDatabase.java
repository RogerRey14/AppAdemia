package lis.main.appademia.adapter;

import com.alamkanak.weekview.WeekViewDisplayable;

import java.util.Calendar;
import java.util.List;

import lis.main.appademia.adapter.DatosEvento;

public interface EventsDatabase {
    List<WeekViewDisplayable<DatosEvento>> getEventsInRange(Calendar startDate, Calendar endDate);
    void addDatosEvento(DatosEvento evento);
}


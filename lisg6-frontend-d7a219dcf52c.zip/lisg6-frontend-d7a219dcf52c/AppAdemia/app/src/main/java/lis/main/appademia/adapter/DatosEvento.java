package lis.main.appademia.adapter;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import com.alamkanak.weekview.WeekViewDisplayable;
import com.alamkanak.weekview.WeekViewEvent;

import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

import lis.main.appademia.AppAdemia;
import nucleo.Evento;
import nucleo.Nota;

/**
 * Encargada de gestionar los eventos de los grupos que han de visualizarse en
 * los Calendarios. Implementa WeekViewDisplayable para su uso en las clases
 * WeekView de los calendarios semanal y diario.
 *
 * El Parcelable permite compartir un array de instancias de esta clase a
 * través de un Intent.
 */
public class DatosEvento implements WeekViewDisplayable<DatosEvento>, Parcelable {

    private String nombreEvento;
    private String grupo;
    private String categoria;
    private String actividad;
    private String id;
    private String descripcion;
    private Calendar fechaInicio;
    private Calendar fechaFin;
    private String lugar;
    private int color;
    private boolean isAllDay;

    private ArrayList<Nota> notas;

    private SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm", new Locale("es","ES"));
    private SimpleDateFormat formatoDia = new SimpleDateFormat("EEEE dd/MM/yyyy", new Locale("es","ES"));

    public DatosEvento(Evento evento, String grupo, String categoria, String actividad){
        if (evento != null) {
            this.nombreEvento = (actividad + "/" + categoria + "/" + grupo);
            this.grupo = grupo;
            this.categoria = categoria;
            this.actividad = actividad;
            this.id = evento.getID();
            this.descripcion = evento.getDescripcion();
            this.lugar = evento.getLugar();
            this.color = AppAdemia.getInstance().getColorActividad(actividad);
            this.isAllDay = false;

            Calendar hora = Calendar.getInstance();

            this.fechaInicio = Calendar.getInstance();
            this.fechaInicio.setTime(evento.getFechaInicio());
            hora.setTime(evento.getHoraInicio());
            this.fechaInicio.set(Calendar.HOUR_OF_DAY, hora.get(Calendar.HOUR_OF_DAY));
            this.fechaInicio.set(Calendar.MINUTE, hora.get(Calendar.MINUTE));

            this.fechaFin = Calendar.getInstance();
            this.fechaFin.setTime(evento.getFechaFin());
            hora.setTime(evento.getHoraFin());
            this.fechaFin.set(Calendar.HOUR_OF_DAY, hora.get(Calendar.HOUR_OF_DAY));
            this.fechaFin.set(Calendar.MINUTE, hora.get(Calendar.MINUTE));

            this.notas = new ArrayList<Nota>();
            if (evento.getNotas()!=null)
                this.notas.addAll(evento.getNotas());
        }
    }

    public DatosEvento(String idd, String name, String desc, String a, String c, String g, Calendar start, Calendar end, String zone, int colorid, boolean all) {
        id = idd;
        grupo = g;
        categoria = c;
        actividad = a;
        nombreEvento = name;    //title
        descripcion = desc;
        this.fechaInicio = Calendar.getInstance();
        this.fechaFin = Calendar.getInstance();
        fechaInicio = start;    //startTime
        fechaFin = end;         //endTime
        lugar = zone;           //location
        color = AppAdemia.getInstance().getColorActividad(actividad);
        isAllDay = all;
    }

    public String getNombreEvento() {
        return nombreEvento;
    }

    public void setNombreEvento(String nombreEvento) {
        this.nombreEvento = nombreEvento;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Calendar getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Calendar fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Calendar getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(Calendar fechaFin) {
        this.fechaFin = fechaFin;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public String getActividad() {
        return actividad;
    }

    public void setActividad(String actividad) {
        this.actividad = actividad;
    }

    public ArrayList<Nota> getNotas() {
        return notas;
    }

    public void setNotas(ArrayList<Nota> notas) {
        this.notas = notas;
    }

    //---MIOS
    public String getDiaInicio(){
        String pattern;
        if (AppAdemia.getInstance().getIdioma().equals("en")){
            pattern = "EEEE, MM/dd/yyyy";
        } else {
            pattern = "EEEE, dd/MM/yyyy";
        }

        SimpleDateFormat formatoDia = new SimpleDateFormat(pattern, new Locale(
                AppAdemia.getInstance().getIdioma(),"ES"));
        return formatoDia.format(fechaInicio.getTime());
    }

    public String getHoraInicio(){
        SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm", new Locale(
                AppAdemia.getInstance().getIdioma(),"ES"));
        return formatoHora.format(fechaInicio.getTime());
    }

    public String getDiaFinal(){
        String pattern;
        if (AppAdemia.getInstance().getIdioma().equals("en")){
            pattern = "EEEE, MM/dd/yyyy";
        } else {
            pattern = "EEEE, dd/MM/yyyy";
        }

        SimpleDateFormat formatoDia = new SimpleDateFormat(pattern, new Locale(
            AppAdemia.getInstance().getIdioma(),"ES"));
        return formatoDia.format(fechaFin.getTime());
    }

    public String getHoraFinal(){
        SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm", new Locale(
                AppAdemia.getInstance().getIdioma(),"ES"));
        return formatoHora.format(fechaFin.getTime());
    }

    //WeekViewDisplayable
    @NonNull
    @Override
    public WeekViewEvent<DatosEvento> toWeekViewEvent() {
        // Note: It's important to pass "this" as the last argument to WeekViewEvent's constructor.
        // This way, the EventClickListener can return this object in its onEventClick() method.
        isAllDay = false;
        String descripcion = categoria +" / "+ grupo + " / " + lugar;
        return new WeekViewEvent<DatosEvento>(id.length(), actividad, fechaInicio,
                fechaFin, descripcion, color, isAllDay, this);
    }

    //PARCELABLE
    protected DatosEvento(Parcel in) {
        this.nombreEvento = in.readString();
        this.grupo = in.readString();
        this.categoria = in.readString();
        this.actividad = in.readString();
        this.id = in.readString();
        this.descripcion = in.readString();
        this.fechaInicio = Calendar.getInstance();
        this.fechaFin = Calendar.getInstance();
        this.fechaInicio.setTimeInMillis(in.readLong());
        this.fechaFin.setTimeInMillis(in.readLong());
        this.lugar = in.readString();
        this.color = in.readInt();
        this.isAllDay = false;
        this.notas = new ArrayList<Nota>();
        in.readTypedList(notas, Nota.CREATOR);
    }

    public static final Creator<DatosEvento> CREATOR = new Creator<DatosEvento>() {
        @Override
        public DatosEvento createFromParcel(Parcel in) {
            return new DatosEvento(in);
        }

        @Override
        public DatosEvento[] newArray(int size) {
            return new DatosEvento[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nombreEvento);
        dest.writeString(grupo);
        dest.writeString(categoria);
        dest.writeString(actividad);
        dest.writeString(id);
        dest.writeString(descripcion);
        dest.writeLong(fechaInicio.getTimeInMillis());
        dest.writeLong(fechaFin.getTimeInMillis());
        dest.writeString(lugar);
        dest.writeInt(color);
        dest.writeTypedList(notas);
    }


}

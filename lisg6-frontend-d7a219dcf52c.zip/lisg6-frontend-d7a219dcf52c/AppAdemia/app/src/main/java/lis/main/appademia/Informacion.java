package lis.main.appademia;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Informacion extends AppCompatActivity {

    Button bPreguntas;
    ImageView logo;
    TextView equipoApp, contacto, miembro1, miembro2, miembro3, miembro4, miembro5, miembro6, miembro7;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_informacion);
        setTitle(getText(R.string.informacion).toString());

        bPreguntas = (Button) findViewById(R.id.preguntas);
        logo = (ImageView) findViewById(R.id.logoInfo);
        equipoApp = (TextView) findViewById(R.id.textViewEquipo);
        contacto = (TextView) findViewById(R.id.textViewContacto);
        miembro1 = (TextView) findViewById(R.id.miembro1);
        miembro2 = (TextView) findViewById(R.id.miembro2);
        miembro3 = (TextView) findViewById(R.id.miembro3);
        miembro4 = (TextView) findViewById(R.id.miembro4);
        miembro5 = (TextView) findViewById(R.id.miembro5);
        miembro6 = (TextView) findViewById(R.id.miembro6);
        miembro7 = (TextView) findViewById(R.id.miembro7);


        bPreguntas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Informacion.this, PreguntasFrecuentes.class);
                startActivity(intent);
            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}

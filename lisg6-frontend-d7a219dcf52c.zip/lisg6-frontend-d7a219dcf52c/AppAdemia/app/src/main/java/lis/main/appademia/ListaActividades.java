package lis.main.appademia;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import lis.main.appademia.adapter.DatosActividad;
import lis.main.appademia.adapter.DatosNivel;

public class ListaActividades extends AppCompatActivity {

    Button boton;
    TextView actividadSeleccionada, sinActividad;
    ListView listViewActividades;

    DatosNivel nivelSeleccionado;
    private List<DatosActividad> listaDatosActividades;
    private ArrayAdapter<DatosActividad> adapterActividades;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_actividades);

        actividadSeleccionada = (TextView) findViewById(R.id.Text1);
        sinActividad = (TextView) findViewById(R.id.sinActividad);
        boton = (Button) findViewById(R.id.Button1);

        Intent intent = getIntent();
        nivelSeleccionado = (DatosNivel) intent.getParcelableExtra("nivelSeleccionado");
        if (nivelSeleccionado == null) {
            setTitle(getText(R.string.ningunNivel).toString());
        } else {
            setTitle(nivelSeleccionado.toString());
            if (nivelSeleccionado.getNumeroActividades() == 0) {
                String sin = ":(\n\n"+getText(R.string.parece)+" \n " +
                        nivelSeleccionado.toString() + " \n"+getText(R.string.sinActividad);
                sinActividad.setText(sin);
                sinActividad.setVisibility(View.VISIBLE);
            } else {
                sinActividad.setVisibility(View.GONE);
            }
        }

        listViewActividades = (ListView) this.findViewById(R.id.listaActividades);
        listaDatosActividades = new ArrayList<DatosActividad>();
        adapterActividades = new ActividadesAdapter<DatosActividad>(this, listaDatosActividades);
        listViewActividades.setAdapter(adapterActividades);
        llenarListaDeActividades();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        boton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                if (nivelSeleccionado.getNumeroActividades() == 0) { finish();}

                int numChecked = 0;
                ArrayList<DatosActividad> actividadesSeleccionadas  = new ArrayList<DatosActividad>();
                for (DatosActividad i : listaDatosActividades){
                    if (i.isChecked()){
                        numChecked++;
                        actividadesSeleccionadas.add(i);
                    }
                }
                if (numChecked == 0){
                    actividadSeleccionada.setText(R.string.seleccioneActividad);
                    return;
                }

                Intent myIntent = new Intent(ListaActividades.this, ListaGrupos.class);
                myIntent.putParcelableArrayListExtra("actividadesSeleccionadas",actividadesSeleccionadas);
                myIntent.putExtra("nivelSeleccionado", nivelSeleccionado);
                ListaActividades.this.startActivity(myIntent);
            }
        });
    }

    private void llenarListaDeActividades(){
        adapterActividades.clear();
        for (DatosActividad i : nivelSeleccionado.getActividades()) {
            adapterActividades.add(i);
        }
        adapterActividades.notifyDataSetChanged();
    }


    private class ActividadesAdapter<C> extends ArrayAdapter<DatosActividad> {
        List<DatosActividad> listaFilaActividades;

        public ActividadesAdapter(@NonNull Context context, @NonNull List<DatosActividad> actividades) {
            super(context, R.layout.row_checkbox, actividades);
            this.listaFilaActividades = actividades;
        }

        @NonNull
        @Override
        public View getView(int position, View convertView, @NonNull ViewGroup container) {
            DatosActividad fila = getItem(position);

            if (convertView == null) {
                convertView = getLayoutInflater().inflate(R.layout.row_checkbox,
                        container, false);
            }

            TextView nombreActividad = (TextView) convertView.findViewById(R.id.nombre_actividad);
            nombreActividad.setText(fila.getDescripcion());

            CheckBox check = (CheckBox) convertView.findViewById(R.id.checkbox_actividad);
            check.setChecked(listaFilaActividades.get(position).isChecked());
            final int pos = position;
            check.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v){
                    CheckBox cb = (CheckBox) v;
                    listaFilaActividades.get(pos).setChecked(cb.isChecked());
                }
            });

            return convertView;
        }
    }
}

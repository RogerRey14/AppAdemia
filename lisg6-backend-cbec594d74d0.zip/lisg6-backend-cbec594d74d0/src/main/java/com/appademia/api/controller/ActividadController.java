package com.appademia.api.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.appademia.api.model.Actividad;
import com.appademia.api.repository.ActividadRepository;

@RestController
@RequestMapping("/api")
public class ActividadController {

    @Autowired
    ActividadRepository actividadRepository;

    @GetMapping("/actividades")
    public ResponseEntity<List<Actividad>> getAllActividades(@RequestParam(required = false) String nombre) {
        try {
            List<Actividad> actividades = new ArrayList<Actividad>();

            actividadRepository.findAll().forEach(actividades::add);

            if (actividades.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(actividades, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/actividades/{id}")
    public ResponseEntity<Actividad> getActividadById(@PathVariable("id") long id) {
        Optional<Actividad> actividadData = actividadRepository.findById(id);

        if (actividadData.isPresent()) {
            return new ResponseEntity<>(actividadData.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/actividades/nivelOrganizativo/{nivelOrganizativoId}")
    public ResponseEntity<List<Actividad>> getActividadesByNivelOrganizativoId(
            @PathVariable(value = "nivelOrganizativoId") long nivelOrganizativoId) {

        try {
            List<Actividad> actividades = new ArrayList<Actividad>();

            actividadRepository.findByNivelOrganizativo(nivelOrganizativoId).forEach(actividades::add);

            if (actividades.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(actividades, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/actividades")
    public ResponseEntity<Actividad> createActividad(@RequestBody Actividad actividad) {
        try {
            Actividad _actividad = actividadRepository.save(
                    new Actividad(actividad.getNombre(), actividad.getDescripcion(), actividad.getNivelOrganizativo()));
            return new ResponseEntity<>(_actividad, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
        }
    }

    @PutMapping("/actividades/{id}")
    public ResponseEntity<Actividad> updateActividad(@PathVariable("id") long id, @RequestBody Actividad actividad) {
        Optional<Actividad> actividadData = actividadRepository.findById(id);

        if (actividadData.isPresent()) {
            Actividad _actividad = actividadData.get();
            _actividad.setNombre(actividad.getNombre());
            _actividad.setDescripcion(actividad.getDescripcion());
            _actividad.setNivelOrganizativo(actividad.getNivelOrganizativo());
            return new ResponseEntity<>(actividadRepository.save(_actividad), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/actividades/{id}")
    public ResponseEntity<HttpStatus> deleteActividad(@PathVariable("id") long id) {
        try {
            actividadRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
        }
    }

}
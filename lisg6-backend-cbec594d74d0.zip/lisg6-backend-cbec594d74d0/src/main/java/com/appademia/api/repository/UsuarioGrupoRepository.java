package com.appademia.api.repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.appademia.api.model.UsuarioGrupo;

public interface UsuarioGrupoRepository extends JpaRepository<UsuarioGrupo, Long> {
    List<UsuarioGrupo> findByUsuario(long usuario);
    Optional<UsuarioGrupo> findByUsuarioAndGrupo(long usuario, long grupo);
    List<UsuarioGrupo> findByUsuarioAndBloqueado(long usuario, boolean bloqueado);
    List<UsuarioGrupo> findByUsuarioAndSuscrito(long usuario, boolean suscrito);
    

    List<UsuarioGrupo> findByUsuarioAndBloqueadoAndFechaUltimaModificacionAfter(long usuario, boolean bloqueado, Date fecha);
    List<UsuarioGrupo> findByUsuarioAndSuscritoAndFechaUltimaModificacionAfter(long usuario, boolean suscrito, Date fecha);
}
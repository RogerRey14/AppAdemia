package com.appademia.api.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.appademia.api.RolesUsuarioEnum;
import com.appademia.api.SerieEventos;
import com.appademia.api.model.Evento;
import com.appademia.api.model.NivelOrganizativo;
import com.appademia.api.repository.EventoRepository;

@RestController
@RequestMapping("/api")
public class EventoController {

    Logger logger = LoggerFactory.getLogger(EventoController.class);

    @Autowired
    EventoRepository eventoRepository;

    @ResponseBody
    @GetMapping("/eventos")
    public ResponseEntity<List<Evento>> getAllEventos(@RequestParam(required = false) String nombre) {
        try {
            List<Evento> eventos = new ArrayList<Evento>();

            eventoRepository.findAll().forEach(eventos::add);

            if (eventos.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(eventos, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ResponseBody
    @GetMapping("/eventos/{id}")
    public ResponseEntity<Evento> getEventoById(@PathVariable("id") long id) {
        Optional<Evento> eventos = eventoRepository.findById(id);

        if (eventos.isPresent()) {
            return new ResponseEntity<>(eventos.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @ResponseBody
    @GetMapping("/eventos/actividad/{actividadId}")
    public ResponseEntity<List<Evento>> getEventosByActividadId(@PathVariable("actividadId") long actividadId) {
        
        try {
            List<Evento> eventos = new ArrayList<Evento>();

            eventoRepository.findByActividadId(actividadId)
                    .forEach(eventos::add);

            if (eventos.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(eventos, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/eventos")
    public ResponseEntity<Evento> createEvento(@RequestBody Evento evento) {
        try {
            Evento _evento = eventoRepository.save(new Evento(evento.getGrupo(), evento.getLugar(),
                    evento.getDescripcion(), evento.getFechaInicio(), evento.getFechaFin(), evento.getHoraInicio(),
                    evento.getHoraFin(), evento.getEsRecordatorio()));
            return new ResponseEntity<>(_evento, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
        }
    }

    @PostMapping("/eventos/serie")
    public ResponseEntity<List<Evento>> createSerieEventos(@RequestBody SerieEventos serieEventos) {
        try {
            List<Evento> eventos = serieEventos.crearSerieEventos();

            List<Evento> _eventos = eventoRepository.saveAll(eventos);

            return new ResponseEntity<>(_eventos, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
        }
    }

    @PutMapping("/eventos/{id}")
    public ResponseEntity<Evento> updateEvento(@PathVariable("id") long id, @RequestBody Evento evento) {
        Optional<Evento> eventoData = eventoRepository.findById(id);

        if (eventoData.isPresent()) {
            Evento _evento = eventoData.get();
            _evento.setGrupo(evento.getGrupo());
            _evento.setLugar(evento.getLugar());
            _evento.setDescripcion(evento.getDescripcion());
            _evento.setFechaInicio(evento.getFechaInicio());
            _evento.setFechaFin(evento.getFechaFin());
            _evento.setHoraInicio(evento.getHoraInicio());
            _evento.setHoraFin(evento.getHoraFin());
            _evento.setEsRecordatorio(evento.getEsRecordatorio());
            return new ResponseEntity<>(eventoRepository.save(_evento), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/eventos/{id}")
    public ResponseEntity<HttpStatus> deleteEvento(@PathVariable("id") long id) {
        try {
            eventoRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
        }
    }

}
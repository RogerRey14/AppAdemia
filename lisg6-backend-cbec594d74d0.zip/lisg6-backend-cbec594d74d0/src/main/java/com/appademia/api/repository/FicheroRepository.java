package com.appademia.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.appademia.api.model.Fichero;

public interface FicheroRepository extends JpaRepository<Fichero, Long> {
    List<Fichero> findByNota(long nota);
}
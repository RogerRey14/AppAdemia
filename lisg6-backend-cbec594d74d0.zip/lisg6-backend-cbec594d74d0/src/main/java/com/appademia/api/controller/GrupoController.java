package com.appademia.api.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.appademia.api.model.Grupo;
import com.appademia.api.model.NivelOrganizativoUsuario;
import com.appademia.api.model.UsuarioGrupo;
import com.appademia.api.repository.GrupoRepository;

@RestController
@RequestMapping("/api")
public class GrupoController {

    @Autowired
    GrupoRepository grupoRepository;

    @GetMapping("/grupos")
    public ResponseEntity<List<Grupo>> getAllGrupos(@RequestParam(required = false) String nombre) {
        try {
            List<Grupo> grupos = new ArrayList<Grupo>();

            grupoRepository.findAll().forEach(grupos::add);

            if (grupos.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(grupos, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/grupos/{id}")
    public ResponseEntity<Grupo> getGrupoById(@PathVariable("id") long id) {
        Optional<Grupo> grupoData = grupoRepository.findById(id);

        if (grupoData.isPresent()) {
            return new ResponseEntity<>(grupoData.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/grupos/categoria/{categoriaId}")
    public ResponseEntity<List<Grupo>> getGruposByCategoriaId(@PathVariable(value = "categoriaId") long categoriaId) {

        try {
            List<Grupo> grupos = new ArrayList<Grupo>();

            grupoRepository.findByCategoria(categoriaId).forEach(grupos::add);

            if (grupos.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(grupos, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/grupos")
    public ResponseEntity<Grupo> createGrupo(@RequestBody Grupo grupo) {
        try {
            Grupo _grupo = grupoRepository.save(new Grupo(grupo.getNombre(), grupo.getDescripcion(),
                    grupo.getPassword(), grupo.getCategoria(), grupo.isSilenciado(), grupo.isPublico()));
            return new ResponseEntity<>(_grupo, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
        }
    }

    @PutMapping("/grupos/{id}")
    public ResponseEntity<Grupo> updateGrupo(@PathVariable("id") long id, @RequestBody Grupo grupo) {
        Optional<Grupo> grupoData = grupoRepository.findById(id);

        if (grupoData.isPresent()) {
            Grupo _grupo = grupoData.get();
            _grupo.setNombre(grupo.getNombre());
            _grupo.setDescripcion(grupo.getDescripcion());
            _grupo.setPassword(grupo.getPassword());
            _grupo.setCategoria(grupo.getCategoria());
            _grupo.setSilenciado(grupo.isSilenciado());
            _grupo.setPublico(grupo.isPublico());
            return new ResponseEntity<>(grupoRepository.save(_grupo), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/grupos/{id}")
    public ResponseEntity<HttpStatus> deleteGrupo(@PathVariable("id") long id) {
        try {
            grupoRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
        }
    }
    
    
    @GetMapping("/grupos/usuario/{id}/suscrito")
    public ResponseEntity<List<Grupo>> getGruposSuscritosUsuario(
            @PathVariable("id") long id) {
        try {
            List<Grupo> gruposData = new ArrayList<Grupo>();

            grupoRepository.findByUsuarioSuscrito(id, true).forEach(gruposData::add);

            if (gruposData.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(gruposData, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    
    @GetMapping("/grupos/usuario/{id}/bloqueado")
    public ResponseEntity<List<Grupo>> getGruposBloqueadoUsuario(
            @PathVariable("id") long id) {
        try {
            List<Grupo> gruposData = new ArrayList<Grupo>();

            grupoRepository.findByUsuarioBloqueado(id, true).forEach(gruposData::add);

            if (gruposData.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(gruposData, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
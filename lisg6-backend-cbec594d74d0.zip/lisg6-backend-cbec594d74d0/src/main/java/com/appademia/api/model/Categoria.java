package com.appademia.api.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Categoria extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String nombre;
    private String descripcion;
    private long actividad;

    @OneToMany(mappedBy = "parentCategoria")
    private Set<Grupo> grupos = new HashSet<>();

    @ManyToOne
    @JoinColumn(name = "actividad", insertable = false, updatable = false)
    private Actividad parentActividad;

    public Categoria() {
    }

    public Categoria(String nombre, String descripcion, long actividad) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.actividad = actividad;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public long getActividad() {
        return actividad;
    }

    public void setActividad(long actividad) {
        this.actividad = actividad;
    }

    @Override
    public String toString() {
        return "Categoria [id=" + id + ", nombre=" + nombre + ", descripcion=" + descripcion + ", actividad="
                + actividad + ", grupos=" + grupos + "]";
    }

}
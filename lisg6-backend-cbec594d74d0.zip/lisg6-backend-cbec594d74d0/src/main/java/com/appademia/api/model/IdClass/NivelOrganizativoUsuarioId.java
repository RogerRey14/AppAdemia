package com.appademia.api.model.IdClass;

import java.io.Serializable;

public class NivelOrganizativoUsuarioId implements Serializable {
    
    private long nivelOrganizativo;
    private long usuario;
    
    public NivelOrganizativoUsuarioId(){
        
    }
    
    public NivelOrganizativoUsuarioId(long nivelOrganizativo, long usuario) {
        this.nivelOrganizativo = nivelOrganizativo;
        this.usuario = usuario;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (nivelOrganizativo ^ (nivelOrganizativo >>> 32));
        result = prime * result + (int) (usuario ^ (usuario >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        NivelOrganizativoUsuarioId other = (NivelOrganizativoUsuarioId) obj;
        if (nivelOrganizativo != other.nivelOrganizativo)
            return false;
        if (usuario != other.usuario)
            return false;
        return true;
    }
    
    
    
    
}
package com.appademia.api.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.appademia.api.model.Calendario;
import com.appademia.api.model.Nota;

public interface NotaRepository extends JpaRepository<Nota, Long> {
    List<Nota> findByCreador(long creador);
    
    @Query(value = "SELECT * FROM Nota n "
            + "WHERE n.esPublica = 1 AND n.evento in (SELECT e.ID "
                            + "FROM Evento e, Grupo g "
                            + "WHERE e.grupo = g.ID AND g.ID in (SELECT ug.grupo "
                                    + "FROM UsuarioGrupo ug "
                                    + "WHERE ug.suscrito = 1 AND ug.usuario = ?1))", nativeQuery = true)
    List<Nota> findByUsuarioSuscrito(long usuario);

    @Query(value = "SELECT * FROM Nota n "
            + "WHERE n.esPublica = 1 AND n.fecha_ultima_modificacion >= ?2 AND n.evento in (SELECT e.ID "
                            + "FROM Evento e, Grupo g "
                            + "WHERE e.grupo = g.ID AND g.ID in (SELECT ug.grupo "
                                    + "FROM UsuarioGrupo ug "
                                    + "WHERE ug.suscrito = 1 AND ug.usuario = ?1))", nativeQuery = true)
    List<Nota> findByUsuarioSuscritoAndFechaUltimaModificacionAfter(long idUsuario, Date fecha);

    List<Nota> findByCreadorAndFechaUltimaModificacionAfter(long idUsuario, Date fecha);
}
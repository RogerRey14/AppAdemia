package com.appademia.api.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.appademia.api.RolesUsuarioEnum;
import com.appademia.api.model.ActividadUsuario;
import com.appademia.api.model.Grupo;
import com.appademia.api.model.NivelOrganizativoUsuario;
import com.appademia.api.model.RolUsuario;
import com.appademia.api.model.Usuario;
import com.appademia.api.model.UsuarioGrupo;
import com.appademia.api.repository.ActividadUsuarioRepository;
import com.appademia.api.repository.GrupoRepository;
import com.appademia.api.repository.NivelOrganizativoUsuarioRepository;
import com.appademia.api.repository.RolUsuarioRepository;
import com.appademia.api.repository.UsuarioGrupoRepository;
import com.appademia.api.repository.UsuarioRepository;

@RestController
@RequestMapping("/api")
public class UsuarioController {

    @Autowired
    UsuarioRepository usuarioRepository;
    @Autowired
    UsuarioGrupoRepository usuarioGrupoRepository;
    @Autowired
    ActividadUsuarioRepository actividadUsuarioRepository;
    @Autowired
    NivelOrganizativoUsuarioRepository nivelOrganizativoUsuarioRepository;
    @Autowired
    RolUsuarioRepository rolUsuarioRepository;
    @Autowired
    GrupoRepository grupoRepository;

    @GetMapping("/usuarios")
    public ResponseEntity<List<Usuario>> getAllUsuarios() {
        try {
            List<Usuario> usuarios = new ArrayList<Usuario>();

            usuarioRepository.findAll().forEach(usuarios::add);

            if (usuarios.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(usuarios, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/usuarios/email/{email}")
    public ResponseEntity<Usuario> getUsuarioByEmail(@PathVariable("email") String email) {
        Optional<Usuario> usuarioData = usuarioRepository.findByEmail(email);

        if (usuarioData.isPresent()) {
            return new ResponseEntity<>(usuarioData.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/usuarios/{id}")
    public ResponseEntity<Usuario> getUsuarioById(@PathVariable("id") long id) {
        Optional<Usuario> usuarioData = usuarioRepository.findById(id);

        if (usuarioData.isPresent()) {
            return new ResponseEntity<>(usuarioData.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/usuarios/actividades/roles")
    public ResponseEntity<List<ActividadUsuario>> getActividadesUsuariosRoles() {
        try {
            List<ActividadUsuario> actividadUsuarios = new ArrayList<ActividadUsuario>();

            actividadUsuarioRepository.findAll().forEach(actividadUsuarios::add);

            if (actividadUsuarios.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(actividadUsuarios, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/usuarios/{id}/actividades/roles")
    public ResponseEntity<List<ActividadUsuario>> getActividadesUsuariosRoles(@PathVariable("id") long id) {
        try {
            List<ActividadUsuario> actividadUsuarios = new ArrayList<ActividadUsuario>();

            actividadUsuarioRepository.findByUsuario(id).forEach(actividadUsuarios::add);

            if (actividadUsuarios.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(actividadUsuarios, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/usuarios/niveles/roles")
    public ResponseEntity<List<NivelOrganizativoUsuario>> getNivelesOrganizativosUsuariosRoles() {
        try {
            List<NivelOrganizativoUsuario> nivelOrganizativoUsuarios = new ArrayList<NivelOrganizativoUsuario>();

            nivelOrganizativoUsuarioRepository.findAll().forEach(nivelOrganizativoUsuarios::add);

            if (nivelOrganizativoUsuarios.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(nivelOrganizativoUsuarios, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/usuarios/{id}/niveles/roles")
    public ResponseEntity<List<NivelOrganizativoUsuario>> getNivelesOrganizativosUsuariosRoles(
            @PathVariable("id") long id) {
        try {
            List<NivelOrganizativoUsuario> nivelOrganizativoUsuarios = new ArrayList<NivelOrganizativoUsuario>();

            nivelOrganizativoUsuarioRepository.findByUsuario(id).forEach(nivelOrganizativoUsuarios::add);

            if (nivelOrganizativoUsuarios.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(nivelOrganizativoUsuarios, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/usuarios/roles")
    public ResponseEntity<List<RolUsuario>> getRolesUsuario() {
        try {
            List<RolUsuario> rolesUsuarioData = new ArrayList<RolUsuario>();

            rolUsuarioRepository.findAll().forEach(rolesUsuarioData::add);

            if (rolesUsuarioData.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(rolesUsuarioData, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/usuarios/{id}/grupos/suscrito")
    public ResponseEntity<List<UsuarioGrupo>> getUsuarioGrupoSuscrito(@PathVariable("id") long id) {
        try {
            List<UsuarioGrupo> rolesUsuarioData = new ArrayList<UsuarioGrupo>();

            usuarioGrupoRepository.findByUsuarioAndSuscrito(id, true).forEach(rolesUsuarioData::add);

            if (rolesUsuarioData.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(rolesUsuarioData, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/usuarios/{id}/grupos/bloqueado")
    public ResponseEntity<List<UsuarioGrupo>> getUsuarioGrupoBloqueado(@PathVariable("id") long id) {
        try {
            List<UsuarioGrupo> rolesUsuarioData = new ArrayList<UsuarioGrupo>();

            usuarioGrupoRepository.findByUsuarioAndBloqueado(id, true).forEach(rolesUsuarioData::add);

            if (rolesUsuarioData.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(rolesUsuarioData, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/usuarios")
    public ResponseEntity<Usuario> createUsuario(@RequestBody Usuario usuario) {
        try {
            Usuario _usuario = usuarioRepository.save(new Usuario(usuario.getEmail(), usuario.getPassword(),
                    usuario.getNombre(), usuario.isDesactivado()));
            return new ResponseEntity<>(_usuario, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
        }
    }

    @PutMapping("/usuarios/{id}")
    public ResponseEntity<Usuario> updateUsuario(@PathVariable("id") long id, @RequestBody Usuario usuario) {
        Optional<Usuario> usuarioData = usuarioRepository.findById(id);

        if (usuarioData.isPresent()) {
            Usuario _usuario = usuarioData.get();
            _usuario.setEmail(usuario.getEmail());
            _usuario.setPassword(usuario.getPassword());
            _usuario.setNombre(usuario.getNombre());
            _usuario.setDesactivado(usuario.isDesactivado());
            return new ResponseEntity<>(usuarioRepository.save(_usuario), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/usuarios/{id}/desactivar")
    public ResponseEntity<Usuario> desactivarUsuario(@PathVariable("id") long id) {
        Optional<Usuario> usuarioData = usuarioRepository.findById(id);

        if (usuarioData.isPresent()) {
            Usuario _usuario = usuarioData.get();
            _usuario.setDesactivado(true);
            return new ResponseEntity<>(usuarioRepository.save(_usuario), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/usuarios/{id}/activar")
    public ResponseEntity<Usuario> activarUsuario(@PathVariable("id") long id) {
        Optional<Usuario> usuarioData = usuarioRepository.findById(id);

        if (usuarioData.isPresent()) {
            Usuario _usuario = usuarioData.get();
            _usuario.setDesactivado(false);
            return new ResponseEntity<>(usuarioRepository.save(_usuario), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/usuarios/{idUsuario}/moderador/actividad/{idActividad}/promover")
    public ResponseEntity<HttpStatus> promoverUsuarioModeradorActividad(@PathVariable("idUsuario") long idUsuario,
            @PathVariable("idActividad") long idActividad) {
        Optional<ActividadUsuario> actividadUsuarioData = actividadUsuarioRepository
                .findByUsuarioAndActividad(idUsuario, idActividad);

        if (actividadUsuarioData.isPresent()) {
            ActividadUsuario _actividadUsuario = actividadUsuarioData.get();
            _actividadUsuario.setRolUsuario(RolesUsuarioEnum.MODERADOR.getValue());
            actividadUsuarioRepository.save(_actividadUsuario);
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            try {
                actividadUsuarioRepository
                        .save(new ActividadUsuario(idActividad, idUsuario, RolesUsuarioEnum.MODERADOR.getValue(), false));
                return new ResponseEntity<>(HttpStatus.CREATED);
            } catch (Exception e) {
                return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
            }
        }
    }

    @PutMapping("/usuarios/{idUsuario}/moderador/actividad/{idActividad}/revocar")
    public ResponseEntity<HttpStatus> revocarUsuarioModeradorActividad(@PathVariable("idUsuario") long idUsuario,
            @PathVariable("idActividad") long idActividad) {
        Optional<ActividadUsuario> actividadUsuarioData = actividadUsuarioRepository
                .findByUsuarioAndActividad(idUsuario, idActividad);

        if (actividadUsuarioData.isPresent()) {
            ActividadUsuario _actividadUsuario = actividadUsuarioData.get();
            _actividadUsuario.setRolUsuario(RolesUsuarioEnum.REGISTRADO.getValue());
            actividadUsuarioRepository.save(_actividadUsuario);
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            try {
                actividadUsuarioRepository
                        .save(new ActividadUsuario(idActividad, idUsuario, RolesUsuarioEnum.REGISTRADO.getValue(), false));
                return new ResponseEntity<>(HttpStatus.CREATED);
            } catch (Exception e) {
                return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
            }
        }
    }

    @PutMapping("/usuarios/{idUsuario}/administrador/nivelOrganizativo/{idNivelOrganizativo}/revocar")
    public ResponseEntity<HttpStatus> revocarUsuarioAdministradorNivelOrganizativo(
            @PathVariable("idUsuario") long idUsuario, @PathVariable("idNivelOrganizativo") long idNivelOrganizativo) {
        Optional<NivelOrganizativoUsuario> nivelOrganizativoUsuarioData = nivelOrganizativoUsuarioRepository
                .findByUsuarioAndNivelOrganizativo(idUsuario, idNivelOrganizativo);

        if (nivelOrganizativoUsuarioData.isPresent()) {
            NivelOrganizativoUsuario _nivelOrganizativoUsuario = nivelOrganizativoUsuarioData.get();
            _nivelOrganizativoUsuario.setRolUsuario(RolesUsuarioEnum.REGISTRADO.getValue());
            nivelOrganizativoUsuarioRepository.save(_nivelOrganizativoUsuario);
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            try {
                nivelOrganizativoUsuarioRepository.save(
                        new NivelOrganizativoUsuario(idNivelOrganizativo, idUsuario, RolesUsuarioEnum.REGISTRADO.getValue()));
                return new ResponseEntity<>(HttpStatus.CREATED);
            } catch (Exception e) {
                return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
            }
        }
    }

    @PutMapping("/usuarios/{idUsuario}/administrador/nivelOrganizativo/{idNivelOrganizativo}/promover")
    public ResponseEntity<HttpStatus> promoverUsuarioAdministradorNivelOrganizativo(
            @PathVariable("idUsuario") long idUsuario, @PathVariable("idNivelOrganizativo") long idNivelOrganizativo) {
        Optional<NivelOrganizativoUsuario> nivelOrganizativoUsuarioData = nivelOrganizativoUsuarioRepository
                .findByUsuarioAndNivelOrganizativo(idUsuario, idNivelOrganizativo);

        if (nivelOrganizativoUsuarioData.isPresent()) {
            NivelOrganizativoUsuario _nivelOrganizativoUsuario = nivelOrganizativoUsuarioData.get();
            _nivelOrganizativoUsuario.setRolUsuario(RolesUsuarioEnum.ADMINISTRADOR.getValue());
            nivelOrganizativoUsuarioRepository.save(_nivelOrganizativoUsuario);
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            try {
                nivelOrganizativoUsuarioRepository.save(new NivelOrganizativoUsuario(idNivelOrganizativo, idUsuario,
                        RolesUsuarioEnum.ADMINISTRADOR.getValue()));
                return new ResponseEntity<>(HttpStatus.CREATED);
            } catch (Exception e) {
                return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
            }
        }
    }

    @PutMapping("/usuarios/{idUsuario}/actividad/{idActividad}/bloquear")
    public ResponseEntity<HttpStatus> bloquearUsuarioActividad(@PathVariable("idUsuario") long idUsuario,
            @PathVariable("idActividad") long idActividad) {
        Optional<ActividadUsuario> actividadUsuarioData = actividadUsuarioRepository
                .findByUsuarioAndActividad(idUsuario, idActividad);

        if (actividadUsuarioData.isPresent()) {
            ActividadUsuario _actividadUsuario = actividadUsuarioData.get();
            _actividadUsuario.setBloqueado(true);
            actividadUsuarioRepository.save(_actividadUsuario);
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            try {
                actividadUsuarioRepository.save(new ActividadUsuario(idActividad, idUsuario,
                        RolesUsuarioEnum.REGISTRADO.getValue(), true));
                return new ResponseEntity<>(HttpStatus.CREATED);
            } catch (Exception e) {
                return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
            }
        }
    }

    @PutMapping("/usuarios/{idUsuario}/actividad/{idActividad}/desbloquear")
    public ResponseEntity<HttpStatus> desbloquearUsuarioActividad(@PathVariable("idUsuario") long idUsuario,
            @PathVariable("idActividad") long idActividad) {
        Optional<ActividadUsuario> actividadUsuarioData = actividadUsuarioRepository
                .findByUsuarioAndActividad(idUsuario, idActividad);

        if (actividadUsuarioData.isPresent()) {
            ActividadUsuario _actividadUsuario = actividadUsuarioData.get();
            _actividadUsuario.setBloqueado(false);
            actividadUsuarioRepository.save(_actividadUsuario);
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            try {
                actividadUsuarioRepository.save(new ActividadUsuario(idActividad, idUsuario,
                        RolesUsuarioEnum.REGISTRADO.getValue(), false));
                return new ResponseEntity<>(HttpStatus.CREATED);
            } catch (Exception e) {
                return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
            }
        }
    }
    
    @PutMapping("/usuarios/{idUsuario}/grupo/{idGrupo}/bloquear")
    public ResponseEntity<HttpStatus> bloquearUsuarioGrupo(@PathVariable("idGrupo") long idGrupo,
            @PathVariable("idUsuario") long idUsuario) {
        Optional<UsuarioGrupo> usuarioGrupoData = usuarioGrupoRepository
                .findByUsuarioAndGrupo(idUsuario, idGrupo);

        if (usuarioGrupoData.isPresent()) {
            UsuarioGrupo _usuarioGrupo = usuarioGrupoData.get();
            _usuarioGrupo.setBloqueado(true);
            usuarioGrupoRepository.save(_usuarioGrupo);
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            try {
                usuarioGrupoRepository.save(new UsuarioGrupo(idUsuario, idGrupo,
                        false, true));
                return new ResponseEntity<>(HttpStatus.CREATED);
            } catch (Exception e) {
                return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
            }
        }
    }

    @PutMapping("/usuarios/{idUsuario}/grupo/{idGrupo}/desbloquear")
    public ResponseEntity<HttpStatus> desbloquearUsuarioGrupo(@PathVariable("idGrupo") long idGrupo,
            @PathVariable("idUsuario") long idUsuario) {
        Optional<UsuarioGrupo> usuarioGrupoData = usuarioGrupoRepository
                .findByUsuarioAndGrupo(idUsuario, idGrupo);

        if (usuarioGrupoData.isPresent()) {
            UsuarioGrupo _usuarioGrupo = usuarioGrupoData.get();
            _usuarioGrupo.setBloqueado(false);
            usuarioGrupoRepository.save(_usuarioGrupo);
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            try {
                usuarioGrupoRepository.save(new UsuarioGrupo(idUsuario, idGrupo,
                        false, false));
                return new ResponseEntity<>(HttpStatus.CREATED);
            } catch (Exception e) {
                return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
            }
        }
    }
    
    @PutMapping("/usuarios/{idUsuario}/grupo/{idGrupo}/suscribir")
    public ResponseEntity<HttpStatus> suscribirUsuarioGrupo(@PathVariable("idGrupo") long idGrupo,
            @PathVariable("idUsuario") long idUsuario) {
        Optional<UsuarioGrupo> usuarioGrupoData = usuarioGrupoRepository
                .findByUsuarioAndGrupo(idUsuario, idGrupo);

        if (usuarioGrupoData.isPresent()) {
            UsuarioGrupo _usuarioGrupo = usuarioGrupoData.get();
            _usuarioGrupo.setSuscrito(true);
            usuarioGrupoRepository.save(_usuarioGrupo);
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            try {
                usuarioGrupoRepository.save(new UsuarioGrupo(idUsuario, idGrupo,
                        true, false));
                return new ResponseEntity<>(HttpStatus.CREATED);
            } catch (Exception e) {
                return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
            }
        }
    }
    
    @PostMapping("/usuarios/{idUsuario}/grupo/{idGrupo}/suscribir/password")
    public ResponseEntity<HttpStatus> suscribirUsuarioGrupoPassword(@PathVariable("idGrupo") long idGrupo,
            @PathVariable("idUsuario") long idUsuario, @RequestBody Grupo grupo) {
        Optional<UsuarioGrupo> usuarioGrupoData = usuarioGrupoRepository
                .findByUsuarioAndGrupo(idUsuario, idGrupo);
        Optional<Grupo> grupoData = grupoRepository.findById(idGrupo);

        if (grupoData.isPresent()) {
            UsuarioGrupo _usuarioGrupo = usuarioGrupoData.get();
            Grupo _grupo = grupoData.get();
            
            if (grupo.getPassword() != null && _grupo.getPassword() != null
                    && grupo.getPassword().equals(_grupo.getPassword())) {
                
                if (usuarioGrupoData.isPresent()) {                    
                    _usuarioGrupo.setSuscrito(true);
                    usuarioGrupoRepository.save(_usuarioGrupo);
                    return new ResponseEntity<>(HttpStatus.OK);
                    
                }else {
                    try {
                        usuarioGrupoRepository.save(new UsuarioGrupo(idUsuario, idGrupo,
                                true, false));
                        return new ResponseEntity<>(HttpStatus.CREATED);
                    } catch (Exception e) {
                        return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
                    }
                }
            }
        }
        
        return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
    }

    @PutMapping("/usuarios/{idUsuario}/grupo/{idGrupo}/desuscribir")
    public ResponseEntity<HttpStatus> desuscribirUsuarioGrupo(@PathVariable("idGrupo") long idGrupo,
            @PathVariable("idUsuario") long idUsuario) {
        Optional<UsuarioGrupo> usuarioGrupoData = usuarioGrupoRepository
                .findByUsuarioAndGrupo(idUsuario, idGrupo);

        if (usuarioGrupoData.isPresent()) {
            UsuarioGrupo _usuarioGrupo = usuarioGrupoData.get();
            _usuarioGrupo.setSuscrito(false);
            usuarioGrupoRepository.save(_usuarioGrupo);
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            try {
                usuarioGrupoRepository.save(new UsuarioGrupo(idUsuario, idGrupo,
                        false, false));
                return new ResponseEntity<>(HttpStatus.CREATED);
            } catch (Exception e) {
                return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
            }
        }
    }

    @DeleteMapping("/usuarios/{id}")
    public ResponseEntity<HttpStatus> deleteUsuario(@PathVariable("id") long id) {
        try {
            usuarioRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<HttpStatus> usuarioLogin(@RequestBody Usuario usuario) {
        Optional<Usuario> usuarioData = usuarioRepository.findByEmail(usuario.getEmail());

        if (usuarioData.isPresent()) {
            Usuario _usuario = usuarioData.get();
            if (_usuario.isDesactivado()) {
                return new ResponseEntity<>(HttpStatus.LOCKED);
            }

            if (usuario.getPassword() != null && _usuario.getPassword() != null
                    && usuario.getPassword().equals(_usuario.getPassword())) {
                return new ResponseEntity<>(HttpStatus.OK);
            }
        }
        return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
    }

}
package com.appademia.api.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.appademia.api.model.IdClass.CalendarioEventoId;


@Entity
@IdClass(CalendarioEventoId.class)
public class CalendarioEvento extends Auditable implements Serializable  {

    @Id
    private long calendario;
    @Id
    private long evento;
    
    public CalendarioEvento() {
        
    }
    
    public CalendarioEvento( long calendario, long evento) {
        this.calendario = calendario;
        this.evento = evento;
    }

    public long getCalendario() {
        return calendario;
    }

    public void setCalendario(long calendario) {
        this.calendario = calendario;
    }

    public long getEvento() {
        return evento;
    }

    public void setEvento(long evento) {
        this.evento = evento;
    }

    @Override
    public String toString() {
        return "CalendarioEvento [calendario=" + calendario + ", evento=" + evento + "]";
    }

     
    
}
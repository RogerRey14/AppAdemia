package com.appademia.api.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.appademia.api.model.Actividad;
import com.appademia.api.model.Calendario;

public interface ActividadRepository extends JpaRepository<Actividad, Long> {
    List<Actividad> findByNivelOrganizativo(long nivelOrganizativoId);

    List<Actividad> findByFechaUltimaModificacionAfter(Date fecha);
}
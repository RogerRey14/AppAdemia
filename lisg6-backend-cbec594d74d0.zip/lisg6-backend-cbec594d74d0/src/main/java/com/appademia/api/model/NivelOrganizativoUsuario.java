package com.appademia.api.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.appademia.api.model.IdClass.NivelOrganizativoUsuarioId;

@Entity
@IdClass(NivelOrganizativoUsuarioId.class)
public class NivelOrganizativoUsuario extends Auditable implements Serializable  {

    @Id
    private long nivelOrganizativo;
    @Id
    private long usuario;
    private long rolUsuario;
    
    public NivelOrganizativoUsuario() {
        
    }
    
    public NivelOrganizativoUsuario( long nivelOrganizativo, long usuario, long rolUsuario) {
        this.nivelOrganizativo = nivelOrganizativo;
        this.usuario = usuario;
        this.rolUsuario = rolUsuario;
    }

    public long getNivelOrganizativo() {
        return nivelOrganizativo;
    }

    public void setNivelOrganizativo(long nivelOrganizativo) {
        this.nivelOrganizativo = nivelOrganizativo;
    }

    public long getUsuario() {
        return usuario;
    }

    public void setUsuario(long usuario) {
        this.usuario = usuario;
    }

    public long getRolUsuario() {
        return rolUsuario;
    }

    public void setRolUsuario(long rolUsuario) {
        this.rolUsuario = rolUsuario;
    }

    @Override
    public String toString() {
        return "NivelOrganizativoUsuario [nivelOrganizativo=" + nivelOrganizativo + ", usuario=" + usuario
                + ", rolUsuario=" + rolUsuario + "]";
    }

   
    
}
package com.appademia.api.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.appademia.api.model.ActividadUsuario;


public interface ActividadUsuarioRepository extends JpaRepository<ActividadUsuario, Long> {
    Optional<ActividadUsuario> findByUsuarioAndActividad(long usuario, long actividad);
    List<ActividadUsuario> findByUsuario(long usuario);
}
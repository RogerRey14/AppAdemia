package com.appademia.api.model;

import java.sql.Time;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Nota extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String titulo;
    private String texto;

    @Temporal(TemporalType.DATE)
    private Date fecha;
    private Time hora;
    
    private boolean esPublica;
    private Long evento;
    private Long creador;   


    @OneToMany(mappedBy = "parentNota")
    private Set<Fichero> ficheros = new HashSet<>();
    
    public Nota() {
    }    
    
    public Nota(String titulo, String texto, Date fecha, Time hora, boolean esPublica, Long evento, Long creador) {
        this.titulo = titulo;
        this.texto = texto;
        this.fecha = fecha;
        this.hora = hora;
        this.esPublica = esPublica;
        this.evento = evento;
        this.creador = creador;
    }
    
    public long getId() {
        return id;
    }
    
    public void setId(long id) {
        this.id = id;
    }
    
    public String getTitulo() {
        return titulo;
    }
    
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
    public String getTexto() {
        return texto;
    }
    
    public void setTexto(String texto) {
        this.texto = texto;
    }
    
    public Date getFecha() {
        return fecha;
    }
    
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    
    public Time getHora() {
        return hora;
    }
    
    public void setHora(Time hora) {
        this.hora = hora;
    }
    
    public boolean isEsPublica() {
        return esPublica;
    }
    
    public void setEsPublica(boolean esPublica) {
        this.esPublica = esPublica;
    }
    
    public Long getEvento() {
        return evento;
    }
    
    public void setEvento(Long evento) {
        this.evento = evento;
    }
    
    public Long getCreador() {
        return creador;
    }
    
    public void setCreador(Long creador) {
        this.creador = creador;
    }

//    @ManyToOne
//    @JoinColumn(name = "nivelOrganizativo", insertable = false, updatable = false)
//    private Evento evento;
//    
//    @ManyToOne
//    @JoinColumn(name = "nivelOrganizativo", insertable = false, updatable = false)
//    private Usuario usuario;

    
   

}
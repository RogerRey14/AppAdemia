package com.appademia.api.model.IdClass;

import java.io.Serializable;

public class CalendarioEventoId implements Serializable {
    long calendario;
    long evento;
    
    public CalendarioEventoId() {
        
    }
    
    public CalendarioEventoId(long calendario, long evento) {
        this.calendario = calendario;
        this.evento = evento;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (calendario ^ (calendario >>> 32));
        result = prime * result + (int) (evento ^ (evento >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CalendarioEventoId other = (CalendarioEventoId) obj;
        if (calendario != other.calendario)
            return false;
        if (evento != other.evento)
            return false;
        return true;
    }
    

}

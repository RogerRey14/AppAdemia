package com.appademia.api.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
public class Grupo extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    private String nombre;
    private String descripcion;
    private String password;
    private long categoria;
    private boolean silenciado;
    private boolean publico;

    @OneToMany(mappedBy = "parentGrupo")
    private Set<Evento> eventos = new HashSet<>();

    @ManyToOne
    @JoinColumn(name = "categoria", insertable = false, updatable = false)
    private Categoria parentCategoria;

    public Grupo() {
    }

    public Grupo(String nombre, String descripcion, String password, long categoria, boolean silenciado,
            boolean publico) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.password = password;
        this.categoria = categoria;
        this.silenciado = silenciado;
        this.publico = publico;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public long getCategoria() {
        return categoria;
    }

    public void setCategoria(long categoria) {
        this.categoria = categoria;
    }

    public boolean isSilenciado() {
        return silenciado;
    }

    public void setSilenciado(boolean silenciado) {
        this.silenciado = silenciado;
    }

    public boolean isPublico() {
        return publico;
    }

    public void setPublico(boolean publico) {
        this.publico = publico;
    }

    public Set<Evento> getEventos() {
        return eventos;
    }

    public void setEventos(Set<Evento> eventos) {
        this.eventos = eventos;
    }

    @Override
    public String toString() {
        return "Grupo [id=" + id + ", nombre=" + nombre + ", descripcion=" + descripcion + ", password=" + password
                + ", categoria=" + categoria + ", silenciado=" + silenciado + ", publico=" + publico + "]";
    }

}
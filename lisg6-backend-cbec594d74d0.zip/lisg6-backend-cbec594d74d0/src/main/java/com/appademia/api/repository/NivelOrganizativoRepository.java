package com.appademia.api.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.appademia.api.model.Calendario;
import com.appademia.api.model.NivelOrganizativo;

public interface NivelOrganizativoRepository extends JpaRepository<NivelOrganizativo, Long> {
    List<NivelOrganizativo> findByNivelPadre(long id);
    
    @Query(value = "SELECT * FROM NivelOrganizativo no "
                 + "WHERE no.ID in (SELECT nou.nivelOrganizativo "
                                 + "FROM NivelOrganizativoUsuario nou "
                                 + "WHERE nou.nivelOrganizativo = no.ID AND nou.usuario = ?1 AND nou.rolUsuario = ?2)", nativeQuery = true)
    List<NivelOrganizativo> findByUsuarioAdministrador(long usaurioId, int rolUsuario);

    List<NivelOrganizativo> findByFechaUltimaModificacionAfter(Date fecha);
}
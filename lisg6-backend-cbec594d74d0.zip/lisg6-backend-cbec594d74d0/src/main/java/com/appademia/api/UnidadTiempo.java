package com.appademia.api;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum UnidadTiempo {
    @JsonProperty("dia")
    DIA,
    @JsonProperty("semana")
    SEMANA,
    @JsonProperty("mes")
    MES
}

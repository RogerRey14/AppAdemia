package com.appademia.api.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.appademia.api.model.Fichero;
import com.appademia.api.model.Nota;
import com.appademia.api.repository.FicheroRepository;
import com.appademia.api.repository.NotaRepository;

@RestController
@RequestMapping("/api")
public class NotaController {

    @Autowired
    NotaRepository notaRepository;
    @Autowired
    FicheroRepository ficheroRepository;
    
    @GetMapping("/notas")
    public ResponseEntity<List<Nota>> getAllNotas() {
        try {
            List<Nota> notas = new ArrayList<Nota>();

            notaRepository.findAll().forEach(notas::add);

            if (notas.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(notas, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/notas/usuario/{id}")
    public ResponseEntity<List<Nota>> getNotasByUsuario(@PathVariable("id") long idUsuario) {
        try {
            List<Nota> notas = new ArrayList<Nota>();

            notaRepository.findByCreador(idUsuario).forEach(notas::add);

            if (notas.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(notas, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }    
    
    @GetMapping("/notas/usuario/{id}/suscrito")
    public ResponseEntity<List<Nota>> getNotasByUsuarioSuscrito(@PathVariable("id") long idUsuario) {
        try {
            List<Nota> notas = new ArrayList<Nota>();

            notaRepository.findByUsuarioSuscrito(idUsuario).forEach(notas::add);

            if (notas.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(notas, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }    
    
    
    @GetMapping("/notas/ficheros")
    public ResponseEntity<List<Fichero>> getAllFicheros() {
        try {
            List<Fichero> ficheros = new ArrayList<Fichero>();

            ficheroRepository.findAll().forEach(ficheros::add);

            if (ficheros.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(ficheros, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/notas/{id}/ficheros")
    public ResponseEntity<List<Fichero>> getFicherosByNota(@PathVariable("id") long idNota) {
        try {
            List<Fichero> ficheros = new ArrayList<Fichero>();

            ficheroRepository.findByNota(idNota).forEach(ficheros::add);

            if (ficheros.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(ficheros, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/notas")
    public ResponseEntity<Nota> createNota(@RequestBody Nota nota) {
        try {
            Nota _nota = notaRepository.save(new Nota(nota.getTitulo(), nota.getTexto(), nota.getFecha(),
                    nota.getHora(), nota.isEsPublica(), nota.getEvento(),nota.getCreador()));
            return new ResponseEntity<>(_nota, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
        }
    }
    
    @PostMapping("/notas/ficheros")
    public ResponseEntity<Fichero> createFichero(@RequestBody Fichero fichero) {
        try {
            Fichero _nota = ficheroRepository.save(new Fichero(fichero.getFichero(), fichero.getNota()));
            return new ResponseEntity<>(_nota, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
        }
    }


    @PutMapping("/notas/{id}")
    public ResponseEntity<Nota> updateNota(@PathVariable("id") long id, @RequestBody Nota nota) {
        Optional<Nota> notaData = notaRepository.findById(id);

        if (notaData.isPresent()) {
            Nota _nota = notaData.get();
            _nota.setTitulo(nota.getTitulo());
            _nota.setTexto(nota.getTexto());
            _nota.setFecha(nota.getFecha());
            _nota.setHora(nota.getHora());
            _nota.setEsPublica(nota.isEsPublica());
            _nota.setCreador(nota.getCreador());
            return new ResponseEntity<>(notaRepository.save(_nota), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    @PutMapping("/notas/ficheros/{id}")
    public ResponseEntity<Fichero> updateFichero(@PathVariable("id") long id, @RequestBody Fichero fichero) {
        Optional<Fichero> ficheroData = ficheroRepository.findById(id);

        if (ficheroData.isPresent()) {
            Fichero _fichero = ficheroData.get();
            _fichero.setFichero(fichero.getFichero());
            _fichero.setNota(fichero.getNota());
            return new ResponseEntity<>(ficheroRepository.save(_fichero), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    @DeleteMapping("/notas/{id}")
    public ResponseEntity<HttpStatus> deleteNota(@PathVariable("id") long id) {
        try {
            notaRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
        }
    }
    
    @DeleteMapping("/notas/ficheros/{id}")
    public ResponseEntity<HttpStatus> deleteFichero(@PathVariable("id") long id) {
        try {
            ficheroRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
        }
    }    

}
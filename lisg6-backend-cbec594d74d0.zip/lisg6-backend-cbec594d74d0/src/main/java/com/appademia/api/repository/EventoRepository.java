package com.appademia.api.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.appademia.api.model.Calendario;
import com.appademia.api.model.Evento;

public interface EventoRepository extends JpaRepository<Evento, Long> {

    @Query(value = "SELECT * FROM evento e"
            + " WHERE e.grupo in (SELECT g.id FROM Grupo g "
                                + "WHERE g.categoria in (SELECT c.id FROM Categoria c WHERE c.actividad = ?1));",
                                nativeQuery = true)
    List<Evento> findByActividadId(long actividadId);

    List<Evento> findByFechaUltimaModificacionAfter(Date fecha);
    
}
package com.appademia.api.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.appademia.api.model.Calendario;
import com.appademia.api.model.Notificacion;

public interface NotificacionRepository extends JpaRepository<Notificacion, Long> {
    
    List<Notificacion> findByGrupo(long id);

    List<Notificacion> findByGrupoAndFechaUltimaModificacionAfter(long id, Date fecha);
}
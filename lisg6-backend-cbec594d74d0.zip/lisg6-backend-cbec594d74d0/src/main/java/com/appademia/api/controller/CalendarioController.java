package com.appademia.api.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.appademia.api.RolesUsuarioEnum;
import com.appademia.api.model.Actividad;
import com.appademia.api.model.Calendario;
import com.appademia.api.model.CalendarioEvento;
import com.appademia.api.model.NivelOrganizativoUsuario;
import com.appademia.api.repository.ActividadRepository;
import com.appademia.api.repository.CalendarioEventoRepository;
import com.appademia.api.repository.CalendarioRepository;

@RestController
@RequestMapping("/api")
public class CalendarioController {

    @Autowired
    CalendarioRepository calendarioRepository;
    @Autowired
    CalendarioEventoRepository calendarioEventoRepository;

    @GetMapping("/calendarios")
    public ResponseEntity<List<Calendario>> getAllCalendarios() {
        try {
            List<Calendario> calendarios = new ArrayList<Calendario>();

            calendarioRepository.findAll().forEach(calendarios::add);

            if (calendarios.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(calendarios, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/calendarios/creador/{id}")
    public ResponseEntity<List<Calendario>> getCalendariosByCreador(@PathVariable("id") long id) {
        try {
            List<Calendario> calendarios = new ArrayList<Calendario>();

            calendarioRepository.findByCreador(id).forEach(calendarios::add);

            if (calendarios.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(calendarios, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/calendarios")
    public ResponseEntity<Calendario> createCalendario(@RequestBody Calendario calendario) {
        try {
            Calendario _calendario = calendarioRepository.save(
                    new Calendario(calendario.getCreador()));
            return new ResponseEntity<>(_calendario, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
        }
    }

    @PutMapping("/calendarios/{id}")
    public ResponseEntity<Calendario> updateCalendario(@PathVariable("id") long id, @RequestBody Calendario calendario) {
        Optional<Calendario> calendarioData = calendarioRepository.findById(id);

        if (calendarioData.isPresent()) {
            Calendario _calendario = calendarioData.get();
            _calendario.setCreador(calendario.getCreador());
            return new ResponseEntity<>(calendarioRepository.save(_calendario), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/calendarios/{id}")
    public ResponseEntity<HttpStatus> deleteCalendario(@PathVariable("id") long id) {
        try {
            calendarioRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
        }
    }
    
    @GetMapping("/calendarios/eventos/creador/{idCreador}")
    public ResponseEntity<List<CalendarioEvento>> getCalendariosEventoByCreador(@PathVariable("idCreador") long idCreador) {
        try {
            List<CalendarioEvento> calendarioEventos = new ArrayList<CalendarioEvento>();

            calendarioEventoRepository.findByCreador(idCreador).forEach(calendarioEventos::add);

            if (calendarioEventos.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(calendarioEventos, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    
    @PutMapping("/calendarios/{idCalendario}/evento/{idEvento}")
    public ResponseEntity<CalendarioEvento> anadirEventoCalendario(@PathVariable("idCalendario") long idCalendario, @PathVariable("idEvento") long idEvento) {
               
        try {
            CalendarioEvento _calendarioEvento = calendarioEventoRepository.save(
                    new CalendarioEvento(idCalendario, idEvento));
            return new ResponseEntity<>(_calendarioEvento, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
        }
    }
    
    @DeleteMapping("/calendarios/{idCalendario}/evento/{idEvento}")
    public ResponseEntity<HttpStatus> deleteCalendario(@PathVariable("idCalendario") long idCalendario, @PathVariable("idEvento") long idEvento) {
        try {
            calendarioEventoRepository.deleteByCalendarioAndEvento(idCalendario, idEvento);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
        }
    }
    
    
    

}
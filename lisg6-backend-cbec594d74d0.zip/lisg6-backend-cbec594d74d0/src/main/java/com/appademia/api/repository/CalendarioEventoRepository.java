package com.appademia.api.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.appademia.api.model.CalendarioEvento;

public interface CalendarioEventoRepository extends JpaRepository<CalendarioEvento, Long> {
    @Modifying
    @Transactional
    @Query("delete from CalendarioEvento where calendario = ?1 and evento = ?2")
    void deleteByCalendarioAndEvento(long calendario, long evento);
    
    @Query(value = "SELECT * FROM CalendarioEvento ce "
            + "WHERE ce.calendario in (SELECT c.ID "
                            + "FROM Calendario c "
                            + "WHERE c.ID = ce.calendario AND c.creador = ?1)", nativeQuery = true)
    List<CalendarioEvento> findByCreador(long creador);
    
    @Query(value = "SELECT * FROM CalendarioEvento ce "
            + "WHERE ce.fecha_ultima_modificacion >= ?2 AND ce.calendario in (SELECT c.ID "
                            + "FROM Calendario c "
                            + "WHERE c.ID = ce.calendario AND c.creador = ?1)", nativeQuery = true)
    List<CalendarioEvento> findByCreadorAndFechaUltimaModificacionAfter(long creador, Date fecha);
}
package com.appademia.api.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.appademia.api.model.Calendario;

public interface CalendarioRepository extends JpaRepository<Calendario, Long> {
    
    List<Calendario> findByCreador(long id);
    List<Calendario> findByCreadorAndFechaUltimaModificacionAfter(long id, Date fecha);
}
package com.appademia.api.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.appademia.api.RolesUsuarioEnum;
import com.appademia.api.model.Actividad;
import com.appademia.api.model.Calendario;
import com.appademia.api.model.CalendarioEvento;
import com.appademia.api.model.NivelOrganizativoUsuario;
import com.appademia.api.model.Notificacion;
import com.appademia.api.repository.ActividadRepository;
import com.appademia.api.repository.CalendarioEventoRepository;
import com.appademia.api.repository.CalendarioRepository;
import com.appademia.api.repository.NotificacionRepository;

@RestController
@RequestMapping("/api")
public class NotificacionController {

    @Autowired
    NotificacionRepository notificacionRepository;

    @GetMapping("/notificaciones")
    public ResponseEntity<List<Notificacion>> getAllNotificaciones() {
        try {
            List<Notificacion> notificaciones = new ArrayList<Notificacion>();

            notificacionRepository.findAll().forEach(notificaciones::add);

            if (notificaciones.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(notificaciones, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/notificaciones/grupos/{id}")
    public ResponseEntity<List<Notificacion>> getNotificacionesByGrupo(@PathVariable("id") long id) {
        try {
            List<Notificacion> calendarios = new ArrayList<Notificacion>();

            notificacionRepository.findByGrupo(id).forEach(calendarios::add);

            if (calendarios.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(calendarios, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/notificaciones")
    public ResponseEntity<Notificacion> createNotificacion(@RequestBody Notificacion notificacion) {
        try {
            Notificacion _notificacion = notificacionRepository.save(
                    new Notificacion(notificacion.getGrupo(), notificacion.getCreador(), notificacion.getTitulo(),
                            notificacion.getTexto(), notificacion.getFecha(), notificacion.getHora()));
            return new ResponseEntity<>(_notificacion, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
        }
    }

    @PutMapping("/notificaciones/{id}")
    public ResponseEntity<Notificacion> updateNotificacion(@PathVariable("id") long id, @RequestBody Notificacion notificacion) {
        Optional<Notificacion> notificacionData = notificacionRepository.findById(id);

        if (notificacionData.isPresent()) {
            Notificacion _notificacion = notificacionData.get();
            _notificacion.setCreador(notificacion.getCreador());
            _notificacion.setGrupo(notificacion.getGrupo());
            _notificacion.setTitulo(notificacion.getTitulo());
            _notificacion.setTexto(notificacion.getTexto());
            _notificacion.setFecha(notificacion.getFecha());
            _notificacion.setHora(notificacion.getHora());
            return new ResponseEntity<>(notificacionRepository.save(_notificacion), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/notificaciones/{id}")
    public ResponseEntity<HttpStatus> deleteNotificacion(@PathVariable("id") long id) {
        try {
            notificacionRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
        }
    }    

}
package com.appademia.api.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class NivelOrganizativo extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String tipo;
    private String nombre;
    private String descripcion;
    private boolean esOficial;
    private Long nivelPadre;

    @OneToMany(mappedBy = "parentNivelOrganizativo")
    private Set<Actividad> actividades = new HashSet<>();

    public NivelOrganizativo() {
    }

    public NivelOrganizativo(String tipo, String nombre, String descripcion, boolean esOficial, Long nivelPadre) {

        this.tipo = tipo;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.esOficial = esOficial;
        this.nivelPadre = nivelPadre;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean isEsOficial() {
        return esOficial;
    }

    public void setEsOficial(boolean esOficial) {
        this.esOficial = esOficial;
    }

    public Long getNivelPadre() {
        return nivelPadre;
    }

    public void setNivelPadre(Long nivelPadre) {
        this.nivelPadre = nivelPadre;
    }

    @Override
    public String toString() {
        return "NivelOrganizativo [id=" + id + ", nombre=" + nombre + ", tipo=" + tipo + ", descripcion=" + descripcion
                + ", esOficial=" + esOficial + ", nivelPadre=" + nivelPadre + "]";
    }

}
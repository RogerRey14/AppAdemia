package com.appademia.api;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.appademia.api.model.Evento;
import com.fasterxml.jackson.annotation.JsonFormat;

public class SerieEventos {
    
    private final int DAYS_IN_WEEK = 7;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date inicioRango;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date finRango;
    private int frecuencia;
    private UnidadTiempo unidadTiempo;   
    private Evento evento;
    
    public SerieEventos(int frecuencia, UnidadTiempo unidadTiempo, Evento evento) {
        this.frecuencia = frecuencia;
        this.unidadTiempo = unidadTiempo;
        this.evento = evento;
    }

    public List<Evento> crearSerieEventos() {
        
        Date fechaActual = inicioRango;
        List<Evento> eventos = new ArrayList<>();
        
        while (fechaActual.before(finRango)){
            Evento e = new Evento(evento.getGrupo(), evento.getLugar(), evento.getDescripcion(), fechaActual, fechaActual, evento.getHoraInicio(),
                    evento.getHoraFin(), evento.getEsRecordatorio());
            eventos.add(e);
            

            Calendar c = Calendar.getInstance();
            c.setTime(fechaActual);
            
            switch(unidadTiempo) {
                case DIA:
                    c.add(Calendar.DATE, frecuencia);
                    break;
                case MES:
                    c.add(Calendar.MONTH, frecuencia);
                    break;
                case SEMANA:
                    c.add(Calendar.DATE, frecuencia * DAYS_IN_WEEK);
                    break;
                default:
                    break;            
            } 
            
            fechaActual = c.getTime();
        }        
        
        return eventos;           
    }



    public int getFrecuencia() {
        return frecuencia;
    }




    public void setFrecuencia(int frecuencia) {
        this.frecuencia = frecuencia;
    }




    public UnidadTiempo getUnidadTiempo() {
        return unidadTiempo;
    }




    public void setUnidadTiempo(UnidadTiempo unidadTiempo) {
        this.unidadTiempo = unidadTiempo;
    }

    @Override
    public String toString() {
        return "SerieEventos [DAYS_IN_WEEK=" + DAYS_IN_WEEK + ", inicioRango=" + inicioRango + ", finRango=" + finRango
                + ", frecuencia=" + frecuencia + ", unidadTiempo=" + unidadTiempo + ", evento=" + evento + "]";
    }
    
    

}

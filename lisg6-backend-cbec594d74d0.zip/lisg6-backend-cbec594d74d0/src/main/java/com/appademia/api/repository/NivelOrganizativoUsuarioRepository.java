package com.appademia.api.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.appademia.api.model.NivelOrganizativoUsuario;

public interface NivelOrganizativoUsuarioRepository extends JpaRepository<NivelOrganizativoUsuario, Long> {
    Optional<NivelOrganizativoUsuario> findByUsuarioAndNivelOrganizativo(long usuario, long nivelOrganizativo);
    List<NivelOrganizativoUsuario> findByUsuario(long usuario);
}
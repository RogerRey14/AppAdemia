package com.appademia.api.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.appademia.api.model.IdClass.UsuarioGrupoId;

@Entity
@IdClass(UsuarioGrupoId.class)
public class UsuarioGrupo extends Auditable implements Serializable {

    @Id
    private long usuario;
    @Id
    private long grupo;
    private boolean suscrito;
    private boolean bloqueado;
    
    public UsuarioGrupo() {
        
    }
    
    public UsuarioGrupo( long usuario, long grupo, boolean suscrito, boolean bloqueado) {
        this.usuario = usuario;
        this.grupo = grupo;
        this.suscrito = suscrito;
        this.bloqueado = bloqueado;
    }

    public long getUsuario() {
        return usuario;
    }

    public void setUsuario(long usuario) {
        this.usuario = usuario;
    }

    public long getGrupo() {
        return grupo;
    }

    public void setGrupo(long grupo) {
        this.grupo = grupo;
    }

    public boolean isSuscrito() {
        return suscrito;
    }

    public void setSuscrito(boolean suscrito) {
        this.suscrito = suscrito;
    }

    public boolean isBloqueado() {
        return bloqueado;
    }

    public void setBloqueado(boolean bloqueado) {
        this.bloqueado = bloqueado;
    }

    @Override
    public String toString() {
        return "UsuarioGrupo [usuario=" + usuario + ", grupo=" + grupo + ", suscrito=" + suscrito
                + ", bloqueado=" + bloqueado + "]";
    }
       
    
}
package com.appademia.api;

public enum RolesUsuarioEnum {
    REGISTRADO(1),
    MODERADOR(2),
    ADMINISTRADOR(3),
    INVITADO(4);
    
    private final int value;

    RolesUsuarioEnum(final int newValue) {
        value = newValue;
    }

    public int getValue() { return value; }
}

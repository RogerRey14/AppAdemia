package com.appademia.api.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.appademia.api.RolesUsuarioEnum;
import com.appademia.api.model.Actividad;
import com.appademia.api.model.Calendario;
import com.appademia.api.model.CalendarioEvento;
import com.appademia.api.model.Categoria;
import com.appademia.api.model.Evento;
import com.appademia.api.model.Grupo;
import com.appademia.api.model.NivelOrganizativo;
import com.appademia.api.model.NivelOrganizativoUsuario;
import com.appademia.api.model.Nota;
import com.appademia.api.model.Notificacion;
import com.appademia.api.model.UsuarioGrupo;
import com.appademia.api.repository.ActividadRepository;
import com.appademia.api.repository.CalendarioEventoRepository;
import com.appademia.api.repository.CalendarioRepository;
import com.appademia.api.repository.CategoriaRepository;
import com.appademia.api.repository.EventoRepository;
import com.appademia.api.repository.GrupoRepository;
import com.appademia.api.repository.NivelOrganizativoRepository;
import com.appademia.api.repository.NotaRepository;
import com.appademia.api.repository.NotificacionRepository;
import com.appademia.api.repository.UsuarioGrupoRepository;

@RestController
@RequestMapping("/api")
public class UpdateController {

    @Autowired
    CalendarioRepository calendarioRepository;
    @Autowired
    CalendarioEventoRepository calendarioEventoRepository;
    @Autowired
    NivelOrganizativoRepository nivelOrganizativoRepository;
    @Autowired
    GrupoRepository grupoRepository;
    @Autowired
    EventoRepository eventoRepository;
    @Autowired
    CategoriaRepository categoriaRepository;
    @Autowired
    ActividadRepository actividadRepository;
    @Autowired
    NotificacionRepository notificacionRepository;
    @Autowired
    NotaRepository notaRepository;
    @Autowired
    UsuarioGrupoRepository usuarioGrupoRepository;

    @GetMapping("/calendarios/creador/{id}/fechaModificacion/{fecha}")
    public ResponseEntity<List<Calendario>> getCalendariosByCreador(@PathVariable("id") long id, @PathVariable("fecha") @DateTimeFormat(pattern="yyyy-MM-dd_HH:mm:ss") Date fecha) {
        try {
            List<Calendario> calendarios = new ArrayList<Calendario>();

            calendarioRepository.findByCreadorAndFechaUltimaModificacionAfter(id, fecha).forEach(calendarios::add);

            if (calendarios.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(calendarios, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

   
    @GetMapping("/calendarios/eventos/creador/{idCreador}/fechaModificacion/{fecha}")
    public ResponseEntity<List<CalendarioEvento>> getCalendariosEventoByCreador(@PathVariable("idCreador") long idCreador, @PathVariable("fecha") @DateTimeFormat(pattern="yyyy-MM-dd_HH:mm:ss") Date fecha) {
        try {
            List<CalendarioEvento> calendarioEventos = new ArrayList<CalendarioEvento>();

            calendarioEventoRepository.findByCreadorAndFechaUltimaModificacionAfter(idCreador, fecha).forEach(calendarioEventos::add);

            if (calendarioEventos.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(calendarioEventos, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/niveles/fechaModificacion/{fecha}")
    public ResponseEntity<List<NivelOrganizativo>> getAllNivelesOrganizativos(@PathVariable("fecha") @DateTimeFormat(pattern="yyyy-MM-dd_HH:mm:ss") Date fecha) {
        try {
            List<NivelOrganizativo> nivelesOrganizativos = new ArrayList<NivelOrganizativo>();

            nivelOrganizativoRepository.findByFechaUltimaModificacionAfter(fecha).forEach(nivelesOrganizativos::add);

            if (nivelesOrganizativos.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(nivelesOrganizativos, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/actividades/fechaModificacion/{fecha}")
    public ResponseEntity<List<Actividad>> getAllActividades(@RequestParam(required = false) String nombre, @PathVariable("fecha") @DateTimeFormat(pattern="yyyy-MM-dd_HH:mm:ss") Date fecha) {
        try {
            List<Actividad> actividades = new ArrayList<Actividad>();

            actividadRepository.findByFechaUltimaModificacionAfter(fecha).forEach(actividades::add);

            if (actividades.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(actividades, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/categorias/fechaModificacion/{fecha}")
    public ResponseEntity<List<Categoria>> getAllCategorias(@RequestParam(required = false) String nombre, @PathVariable("fecha") @DateTimeFormat(pattern="yyyy-MM-dd_HH:mm:ss") Date fecha) {
        try {
            List<Categoria> categorias = new ArrayList<Categoria>();

            categoriaRepository.findByFechaUltimaModificacionAfter(fecha).forEach(categorias::add);

            if (categorias.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(categorias, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/grupos/fechaModificacion/{fecha}")
    public ResponseEntity<List<Grupo>> getAllGrupos(@RequestParam(required = false) String nombre, @PathVariable("fecha") @DateTimeFormat(pattern="yyyy-MM-dd_HH:mm:ss") Date fecha) {
        try {
            List<Grupo> grupos = new ArrayList<Grupo>();

            grupoRepository.findByFechaUltimaModificacionAfter(fecha).forEach(grupos::add);

            if (grupos.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(grupos, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @ResponseBody
    @GetMapping("/eventos/fechaModificacion/{fecha}")
    public ResponseEntity<List<Evento>> getAllEventos(@RequestParam(required = false) String nombre, @PathVariable("fecha") @DateTimeFormat(pattern="yyyy-MM-dd_HH:mm:ss") Date fecha) {
        try {
            List<Evento> eventos = new ArrayList<Evento>();

            eventoRepository.findByFechaUltimaModificacionAfter(fecha).forEach(eventos::add);

            if (eventos.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(eventos, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/notas/usuario/{id}/fechaModificacion/{fecha}")
    public ResponseEntity<List<Nota>> getNotasByUsuario(@PathVariable("id") long idUsuario, @PathVariable("fecha") @DateTimeFormat(pattern="yyyy-MM-dd_HH:mm:ss") Date fecha) {
        try {
            List<Nota> notas = new ArrayList<Nota>();

            notaRepository.findByCreadorAndFechaUltimaModificacionAfter(idUsuario, fecha).forEach(notas::add);

            if (notas.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(notas, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/notas/usuario/{id}/suscrito/fechaModificacion/{fecha}")
    public ResponseEntity<List<Nota>> getNotasByUsuarioSuscrito(@PathVariable("id") long idUsuario, @PathVariable("fecha") @DateTimeFormat(pattern="yyyy-MM-dd_HH:mm:ss") Date fecha) {
        try {
            List<Nota> notas = new ArrayList<Nota>();

            notaRepository.findByUsuarioSuscritoAndFechaUltimaModificacionAfter(idUsuario, fecha).forEach(notas::add);

            if (notas.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(notas, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }   
    
    @GetMapping("/notificaciones/grupos/{id}/fechaModificacion/{fecha}")
    public ResponseEntity<List<Notificacion>> getNotificacionesByGrupo(@PathVariable("id") long id, @PathVariable("fecha") @DateTimeFormat(pattern="yyyy-MM-dd_HH:mm:ss") Date fecha) {
        try {
            List<Notificacion> calendarios = new ArrayList<Notificacion>();

            notificacionRepository.findByGrupoAndFechaUltimaModificacionAfter(id, fecha).forEach(calendarios::add);

            if (calendarios.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(calendarios, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/grupos/usuario/{id}/suscrito/fechaModificacion/{fecha}")
    public ResponseEntity<List<Grupo>> getGruposSuscritosUsuario(
            @PathVariable("id") long id, @PathVariable("fecha") @DateTimeFormat(pattern="yyyy-MM-dd_HH:mm:ss") Date fecha) {
        try {
            List<Grupo> gruposData = new ArrayList<Grupo>();

            grupoRepository.findByUsuarioSuscritoAndFechaUltimaModificacionAfter(id, true, fecha).forEach(gruposData::add);

            if (gruposData.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(gruposData, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    
    @GetMapping("/grupos/usuario/{id}/bloqueado/fechaModificacion/{fecha}")
    public ResponseEntity<List<Grupo>> getGruposBloqueadoUsuario(
            @PathVariable("id") long id, @PathVariable("fecha") @DateTimeFormat(pattern="yyyy-MM-dd_HH:mm:ss") Date fecha) {
        try {
            List<Grupo> gruposData = new ArrayList<Grupo>();

            grupoRepository.findByUsuarioBloqueadoAndFechaUltimaModificacionAfter(id, true, fecha).forEach(gruposData::add);

            if (gruposData.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(gruposData, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/usuarios/{id}/grupos/suscrito/fechaModificacion/{fecha}")
    public ResponseEntity<List<UsuarioGrupo>> getUsuarioGrupoSuscrito(@PathVariable("id") long id, @PathVariable("fecha") @DateTimeFormat(pattern="yyyy-MM-dd_HH:mm:ss") Date fecha) {
        try {
            List<UsuarioGrupo> rolesUsuarioData = new ArrayList<UsuarioGrupo>();

            usuarioGrupoRepository.findByUsuarioAndSuscritoAndFechaUltimaModificacionAfter(id, true, fecha).forEach(rolesUsuarioData::add);

            if (rolesUsuarioData.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(rolesUsuarioData, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    @GetMapping("/usuarios/{id}/grupos/bloqueado/fechaModificacion/{fecha}")
    public ResponseEntity<List<UsuarioGrupo>> getUsuarioGrupoBloqueado(@PathVariable("id") long id, @PathVariable("fecha") @DateTimeFormat(pattern="yyyy-MM-dd_HH:mm:ss") Date fecha) {
        try {
            List<UsuarioGrupo> rolesUsuarioData = new ArrayList<UsuarioGrupo>();

            usuarioGrupoRepository.findByUsuarioAndBloqueadoAndFechaUltimaModificacionAfter(id, true, fecha).forEach(rolesUsuarioData::add);

            if (rolesUsuarioData.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(rolesUsuarioData, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    

}
package com.appademia.api.model;

import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.MappedSuperclass;

import java.util.Date;

@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public abstract class Auditable {
    @LastModifiedDate
    @Column(name = "fecha_ultima_modificacion")
    private Date fechaUltimaModificacion;

    public Date getFechaUltimaModificacion() {
        return fechaUltimaModificacion;
    }
}
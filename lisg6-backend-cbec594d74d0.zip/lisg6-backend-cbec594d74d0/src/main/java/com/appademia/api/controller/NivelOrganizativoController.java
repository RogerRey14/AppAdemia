package com.appademia.api.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.appademia.api.RolesUsuarioEnum;
import com.appademia.api.model.NivelOrganizativo;
import com.appademia.api.repository.NivelOrganizativoRepository;

@RestController
@RequestMapping("/api")
public class NivelOrganizativoController {

    @Autowired
    NivelOrganizativoRepository nivelOrganizativoRepository;

    @GetMapping("/niveles")
    public ResponseEntity<List<NivelOrganizativo>> getAllNivelesOrganizativos() {
        try {
            List<NivelOrganizativo> nivelesOrganizativos = new ArrayList<NivelOrganizativo>();

            nivelOrganizativoRepository.findAll().forEach(nivelesOrganizativos::add);

            if (nivelesOrganizativos.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(nivelesOrganizativos, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/niveles/{id}")
    public ResponseEntity<NivelOrganizativo> getNivelOrganizativoById(@PathVariable("id") long id) {
        Optional<NivelOrganizativo> nivelOrganizativoData = nivelOrganizativoRepository.findById(id);

        if (nivelOrganizativoData.isPresent()) {
            return new ResponseEntity<>(nivelOrganizativoData.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/niveles/hijos/{nivelId}")
    public ResponseEntity<List<NivelOrganizativo>> getNivelesHijosByNivel(
            @PathVariable(value = "nivelId") long nivelId) {

        try {
            List<NivelOrganizativo> nivelesOrganizativos = new ArrayList<NivelOrganizativo>();

            nivelOrganizativoRepository.findByNivelPadre(nivelId).forEach(nivelesOrganizativos::add);

            if (nivelesOrganizativos.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(nivelesOrganizativos, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/niveles/admin/{nivelOrganizativoId}")
    public ResponseEntity<List<NivelOrganizativo>> getNivelesByNivelOrganizativoAdministrador(
            @PathVariable(value = "nivelOrganizativoId") long usaurioId) {

        try {
            List<NivelOrganizativo> nivelesOrganizativos = new ArrayList<NivelOrganizativo>();

            nivelOrganizativoRepository.findByUsuarioAdministrador(usaurioId, RolesUsuarioEnum.ADMINISTRADOR.getValue())
                    .forEach(nivelesOrganizativos::add);

            if (nivelesOrganizativos.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(nivelesOrganizativos, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/niveles")
    public ResponseEntity<NivelOrganizativo> createNivelOrganizativo(@RequestBody NivelOrganizativo nivelOrganizativo) {
        try {
            NivelOrganizativo _nivelOrganizativo = nivelOrganizativoRepository.save(new NivelOrganizativo(
                    nivelOrganizativo.getTipo(), nivelOrganizativo.getNombre(), nivelOrganizativo.getDescripcion(),
                    nivelOrganizativo.isEsOficial(), nivelOrganizativo.getNivelPadre()));
            return new ResponseEntity<>(_nivelOrganizativo, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
        }
    }

    @PutMapping("/niveles/{id}")
    public ResponseEntity<NivelOrganizativo> updateNivelOrganizativo(@PathVariable("id") long id,
            @RequestBody NivelOrganizativo nivelOrganizativo) {
        Optional<NivelOrganizativo> nivelOrganizativoData = nivelOrganizativoRepository.findById(id);

        if (nivelOrganizativoData.isPresent()) {
            NivelOrganizativo _nivelOrganizativo = nivelOrganizativoData.get();
            _nivelOrganizativo.setTipo(nivelOrganizativo.getTipo());
            _nivelOrganizativo.setNombre(nivelOrganizativo.getNombre());
            _nivelOrganizativo.setDescripcion(nivelOrganizativo.getDescripcion());
            _nivelOrganizativo.setEsOficial(nivelOrganizativo.isEsOficial());
            _nivelOrganizativo.setNivelPadre(nivelOrganizativo.getNivelPadre());
            return new ResponseEntity<>(nivelOrganizativoRepository.save(_nivelOrganizativo), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/niveles/{id}")
    public ResponseEntity<HttpStatus> deleteNivelOrganizativo(@PathVariable("id") long id) {
        try {
            nivelOrganizativoRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
        }
    }

}
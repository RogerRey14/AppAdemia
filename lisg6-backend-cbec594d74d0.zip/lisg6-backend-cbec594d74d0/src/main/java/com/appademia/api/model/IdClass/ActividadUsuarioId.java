package com.appademia.api.model.IdClass;

import java.io.Serializable;

public class ActividadUsuarioId implements Serializable {
    
    private long actividad;
    private long usuario;
    
    public ActividadUsuarioId() {
        
    }
    
    public ActividadUsuarioId(long actividad, long usuario) {
        this.actividad = actividad;
        this.usuario = usuario;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (actividad ^ (actividad >>> 32));
        result = prime * result + (int) (usuario ^ (usuario >>> 32));
        return result;
    }
    
    @Override    
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ActividadUsuarioId other = (ActividadUsuarioId) obj;
        if (actividad != other.actividad)
            return false;
        if (usuario != other.usuario)
            return false;
        return true;
    }
}
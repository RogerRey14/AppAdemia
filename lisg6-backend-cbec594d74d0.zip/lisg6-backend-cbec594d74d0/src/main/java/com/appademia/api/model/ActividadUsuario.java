package com.appademia.api.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;

import com.appademia.api.model.IdClass.ActividadUsuarioId;

@Entity
@IdClass(ActividadUsuarioId.class)
public class ActividadUsuario extends Auditable implements Serializable  {

    @Id
    private long actividad;
    @Id
    private long usuario;
    @Id
    private long rolUsuario;
    private boolean bloqueado;
    
    public ActividadUsuario() {
        
    }
    
    public ActividadUsuario( long actividad, long usuario, long rolUsuario, boolean bloqueado) {
        this.actividad = actividad;
        this.usuario = usuario;
        this.rolUsuario = rolUsuario;
        this.bloqueado = bloqueado;
    }

    public long getActividad() {
        return actividad;
    }

    public void setActividad(long actividad) {
        this.actividad = actividad;
    }

    public long getUsuario() {
        return usuario;
    }

    public void setUsuario(long usuario) {
        this.usuario = usuario;
    }

    public long getRolUsuario() {
        return rolUsuario;
    }

    public void setRolUsuario(long rolUsuario) {
        this.rolUsuario = rolUsuario;
    }

    public boolean isBloqueado() {
        return bloqueado;
    }

    public void setBloqueado(boolean bloqueado) {
        this.bloqueado = bloqueado;
    }

    @Override
    public String toString() {
        return "ActividadUsuario [actividad=" + actividad + ", usuario=" + usuario + ", rolUsuario="
                + rolUsuario + ", bloqueado=" + bloqueado + "]";
    }
    
}
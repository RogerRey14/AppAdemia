package com.appademia.api.model.IdClass;

import java.io.Serializable;

public class UsuarioGrupoId implements Serializable {
    long grupo;
    long usuario;
    
    public UsuarioGrupoId() {
        
    }
    
    public UsuarioGrupoId(long grupo, long usuario) {
        this.grupo = grupo;
        this.usuario = usuario;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (grupo ^ (grupo >>> 32));
        result = prime * result + (int) (usuario ^ (usuario >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        UsuarioGrupoId other = (UsuarioGrupoId) obj;
        if (grupo != other.grupo)
            return false;
        if (usuario != other.usuario)
            return false;
        return true;
    }
    

}

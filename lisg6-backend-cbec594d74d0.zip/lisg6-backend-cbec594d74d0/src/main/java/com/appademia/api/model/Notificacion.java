package com.appademia.api.model;

import java.sql.Time;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Notificacion extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private long grupo;
    private long creador;
    private String titulo;
    private String texto;
    
    @Temporal(TemporalType.DATE)
    private Date fecha;
    private Time hora;

    public Notificacion() {
    }

    public Notificacion(long grupo, long creador, String titulo, String texto, Date fecha, Time hora) {
        this.grupo = grupo;
        this.creador = creador;
        this.titulo = titulo;
        this.texto = texto;
        this.fecha = fecha;
        this.hora = hora;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getGrupo() {
        return grupo;
    }

    public void setGrupo(long grupo) {
        this.grupo = grupo;
    }

    public long getCreador() {
        return creador;
    }

    public void setCreador(long creador) {
        this.creador = creador;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Time getHora() {
        return hora;
    }

    public void setHora(Time hora) {
        this.hora = hora;
    }

    @Override
    public String toString() {
        return "Notificacion [id=" + id + ", grupo=" + grupo + ", creador=" + creador + ", titulo=" + titulo
                + ", texto=" + texto + ", fecha=" + fecha + ", hora=" + hora + "]";
    }   
    
}
package com.appademia.api.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.appademia.api.model.Calendario;
import com.appademia.api.model.Grupo;

public interface GrupoRepository extends JpaRepository<Grupo, Long> {
    List<Grupo> findByCategoria(long categoriaId); 
    
    @Query(value = "SELECT * FROM Grupo g "
            + "WHERE g.ID in (SELECT ug.grupo "
                + "FROM UsuarioGrupo ug "
                + "WHERE ug.grupo = g.ID AND ug.usuario = ?1 AND ug.suscrito = ?2)", nativeQuery = true)
    List<Grupo> findByUsuarioSuscrito(long categoriaId, boolean suscrito);
        
    @Query(value = "SELECT * FROM Grupo g "
            + "WHERE g.ID in (SELECT ug.grupo "
                + "FROM UsuarioGrupo ug "
                + "WHERE ug.grupo = g.ID AND ug.usuario = ?1 AND ug.bloqueado = ?2)", nativeQuery = true)
    List<Grupo> findByUsuarioBloqueado(long categoriaId, boolean bloqueado);

    List<Grupo> findByFechaUltimaModificacionAfter(Date fecha);

    
    @Query(value = "SELECT * FROM Grupo g "
            + "WHERE g.fecha_ultima_modificacion >= ?3 AND g.ID in (SELECT ug.grupo "
                + "FROM UsuarioGrupo ug "
                + "WHERE ug.grupo = g.ID AND ug.usuario = ?1 AND ug.suscrito = ?2)", nativeQuery = true)
    List<Grupo> findByUsuarioSuscritoAndFechaUltimaModificacionAfter(long id, boolean suscrito, Date fecha);
    

    @Query(value = "SELECT * FROM Grupo g "
            + "WHERE g.fecha_ultima_modificacion >= ?3 AND g.ID in (SELECT ug.grupo "
                + "FROM UsuarioGrupo ug "
                + "WHERE ug.grupo = g.ID AND ug.usuario = ?1 AND ug.bloqueado = ?2)", nativeQuery = true)
    List<Grupo> findByUsuarioBloqueadoAndFechaUltimaModificacionAfter(long id, boolean suscrito, Date fecha);
}
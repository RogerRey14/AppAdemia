package com.appademia.api.model;

import java.sql.Time;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Fichero extends Auditable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Lob
    @Column(name = "fichero", columnDefinition="BLOB")
    private byte[] fichero;
    
    private long nota;    
    
    
    @ManyToOne
    @JoinColumn(name = "nota", insertable = false, updatable = false)
    private Nota parentNota;
    
    
    public Fichero() {
    }

    public Fichero(byte[] fichero, long nota) {
        this.fichero = fichero;
        this.nota = nota;
    }


    public long getId() {
        return id;
    }


    public void setId(long id) {
        this.id = id;
    }


    public byte[] getFichero() {
        return fichero;
    }


    public void setFichero(byte[] fichero) {
        this.fichero = fichero;
    }


    public long getNota() {
        return nota;
    }


    public void setNota(long nota) {
        this.nota = nota;
    }       
    

}
package com.appademia.api.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.appademia.api.model.RolUsuario;
import com.appademia.api.model.Usuario;

public interface RolUsuarioRepository extends JpaRepository<RolUsuario, Long> {
}